// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This is the main header file a user should include.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_H_
#define GMOCK_INCLUDE_GMOCK_GMOCK_H_

// This file implements the following syntax:
//
//   ON_CALL(mock_object.Method(...))
//     .With(...) ?
//     .WillByDefault(...);
//
// where With() is optional and WillByDefault() must appear exactly
// once.
//
//   EXPECT_CALL(mock_object.Method(...))
//     .With(...) ?
//     .Times(...) ?
//     .InSequence(...) *
//     .WillOnce(...) *
//     .WillRepeatedly(...) ?
//     .RetiresOnSaturation() ? ;
//
// where all clauses are optional and WillOnce() can be repeated.

// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file implements some commonly used actions.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_ACTIONS_H_
#define GMOCK_INCLUDE_GMOCK_GMOCK_ACTIONS_H_

#ifndef _WIN32_WCE
# include <errno.h>
#endif

#include <algorithm>
#include <string>

// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file defines some utilities useful for implementing Google
// Mock.  They are subject to change without notice, so please DO NOT
// USE THEM IN USER CODE.

#ifndef GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_INTERNAL_UTILS_H_
#define GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_INTERNAL_UTILS_H_

#include <stdio.h>
#include <ostream>  // NOLINT
#include <string>

// This file was GENERATED by command:
//     pump.py gmock-generated-internal-utils.h.pump
// DO NOT EDIT BY HAND!!!

// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file contains template meta-programming utility classes needed
// for implementing Google Mock.

#ifndef GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_GENERATED_INTERNAL_UTILS_H_
#define GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_GENERATED_INTERNAL_UTILS_H_

// Copyright 2008, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: vadimb@google.com (Vadim Berman)
//
// Low-level types and utilities for porting Google Mock to various
// platforms.  They are subject to change without notice.  DO NOT USE
// THEM IN USER CODE.

#ifndef GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_PORT_H_
#define GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_PORT_H_

#include <assert.h>
#include <stdlib.h>
#include <iostream>

// Most of the types needed for porting Google Mock are also required
// for Google Test and are defined in gtest-port.h.
#include "gtest/gtest.h"

// To avoid conditional compilation everywhere, we make it
// gmock-port.h's responsibility to #include the header implementing
// tr1/tuple.  gmock-port.h does this via gtest-port.h, which is
// guaranteed to pull in the tuple header.

// For MS Visual C++, check the compiler version. At least VS 2003 is
// required to compile Google Mock.
#if defined(_MSC_VER) && _MSC_VER < 1310
# error "At least Visual C++ 2003 (7.1) is required to compile Google Mock."
#endif

// Macro for referencing flags.  This is public as we want the user to
// use this syntax to reference Google Mock flags.
#define GMOCK_FLAG(name) FLAGS_gmock_##name

// Macros for declaring flags.
#define GMOCK_DECLARE_bool_(name) extern GTEST_API_ bool GMOCK_FLAG(name)
#define GMOCK_DECLARE_int32_(name) \
    extern GTEST_API_ ::testing::internal::Int32 GMOCK_FLAG(name)
#define GMOCK_DECLARE_string_(name) \
    extern GTEST_API_ ::std::string GMOCK_FLAG(name)

// Macros for defining flags.
#define GMOCK_DEFINE_bool_(name, default_val, doc) \
    GTEST_API_ bool GMOCK_FLAG(name) = (default_val)
#define GMOCK_DEFINE_int32_(name, default_val, doc) \
    GTEST_API_ ::testing::internal::Int32 GMOCK_FLAG(name) = (default_val)
#define GMOCK_DEFINE_string_(name, default_val, doc) \
    GTEST_API_ ::std::string GMOCK_FLAG(name) = (default_val)

#endif  // GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_PORT_H_

namespace testing {

template <typename T>
class Matcher;

namespace internal {

// An IgnoredValue object can be implicitly constructed from ANY value.
// This is used in implementing the IgnoreResult(a) action.
class IgnoredValue {
 public:
  // This constructor template allows any value to be implicitly
  // converted to IgnoredValue.  The object has no data member and
  // doesn't try to remember anything about the argument.  We
  // deliberately omit the 'explicit' keyword in order to allow the
  // conversion to be implicit.
  template <typename T>
  IgnoredValue(const T& /* ignored */) {}  // NOLINT(runtime/explicit)
};

// MatcherTuple<T>::type is a tuple type where each field is a Matcher
// for the corresponding field in tuple type T.
template <typename Tuple>
struct MatcherTuple;

template <>
struct MatcherTuple< ::std::tr1::tuple<> > {
  typedef ::std::tr1::tuple< > type;
};

template <typename A1>
struct MatcherTuple< ::std::tr1::tuple<A1> > {
  typedef ::std::tr1::tuple<Matcher<A1> > type;
};

template <typename A1, typename A2>
struct MatcherTuple< ::std::tr1::tuple<A1, A2> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2> > type;
};

template <typename A1, typename A2, typename A3>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3> > type;
};

template <typename A1, typename A2, typename A3, typename A4>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3, A4> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3>,
      Matcher<A4> > type;
};

template <typename A1, typename A2, typename A3, typename A4, typename A5>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3, A4, A5> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3>, Matcher<A4>,
      Matcher<A5> > type;
};

template <typename A1, typename A2, typename A3, typename A4, typename A5,
    typename A6>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3, A4, A5, A6> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3>, Matcher<A4>,
      Matcher<A5>, Matcher<A6> > type;
};

template <typename A1, typename A2, typename A3, typename A4, typename A5,
    typename A6, typename A7>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3>, Matcher<A4>,
      Matcher<A5>, Matcher<A6>, Matcher<A7> > type;
};

template <typename A1, typename A2, typename A3, typename A4, typename A5,
    typename A6, typename A7, typename A8>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3>, Matcher<A4>,
      Matcher<A5>, Matcher<A6>, Matcher<A7>, Matcher<A8> > type;
};

template <typename A1, typename A2, typename A3, typename A4, typename A5,
    typename A6, typename A7, typename A8, typename A9>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8, A9> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3>, Matcher<A4>,
      Matcher<A5>, Matcher<A6>, Matcher<A7>, Matcher<A8>, Matcher<A9> > type;
};

template <typename A1, typename A2, typename A3, typename A4, typename A5,
    typename A6, typename A7, typename A8, typename A9, typename A10>
struct MatcherTuple< ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8, A9,
    A10> > {
  typedef ::std::tr1::tuple<Matcher<A1>, Matcher<A2>, Matcher<A3>, Matcher<A4>,
      Matcher<A5>, Matcher<A6>, Matcher<A7>, Matcher<A8>, Matcher<A9>,
      Matcher<A10> > type;
};

// Template struct Function<F>, where F must be a function type, contains
// the following typedefs:
//
//   Result:               the function's return type.
//   ArgumentN:            the type of the N-th argument, where N starts with 1.
//   ArgumentTuple:        the tuple type consisting of all parameters of F.
//   ArgumentMatcherTuple: the tuple type consisting of Matchers for all
//                         parameters of F.
//   MakeResultVoid:       the function type obtained by substituting void
//                         for the return type of F.
//   MakeResultIgnoredValue:
//                         the function type obtained by substituting Something
//                         for the return type of F.
template <typename F>
struct Function;

template <typename R>
struct Function<R()> {
  typedef R Result;
  typedef ::std::tr1::tuple<> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid();
  typedef IgnoredValue MakeResultIgnoredValue();
};

template <typename R, typename A1>
struct Function<R(A1)>
    : Function<R()> {
  typedef A1 Argument1;
  typedef ::std::tr1::tuple<A1> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1);
  typedef IgnoredValue MakeResultIgnoredValue(A1);
};

template <typename R, typename A1, typename A2>
struct Function<R(A1, A2)>
    : Function<R(A1)> {
  typedef A2 Argument2;
  typedef ::std::tr1::tuple<A1, A2> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2);
};

template <typename R, typename A1, typename A2, typename A3>
struct Function<R(A1, A2, A3)>
    : Function<R(A1, A2)> {
  typedef A3 Argument3;
  typedef ::std::tr1::tuple<A1, A2, A3> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3);
};

template <typename R, typename A1, typename A2, typename A3, typename A4>
struct Function<R(A1, A2, A3, A4)>
    : Function<R(A1, A2, A3)> {
  typedef A4 Argument4;
  typedef ::std::tr1::tuple<A1, A2, A3, A4> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3, A4);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3, A4);
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5>
struct Function<R(A1, A2, A3, A4, A5)>
    : Function<R(A1, A2, A3, A4)> {
  typedef A5 Argument5;
  typedef ::std::tr1::tuple<A1, A2, A3, A4, A5> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3, A4, A5);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3, A4, A5);
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6>
struct Function<R(A1, A2, A3, A4, A5, A6)>
    : Function<R(A1, A2, A3, A4, A5)> {
  typedef A6 Argument6;
  typedef ::std::tr1::tuple<A1, A2, A3, A4, A5, A6> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3, A4, A5, A6);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3, A4, A5, A6);
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7>
struct Function<R(A1, A2, A3, A4, A5, A6, A7)>
    : Function<R(A1, A2, A3, A4, A5, A6)> {
  typedef A7 Argument7;
  typedef ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3, A4, A5, A6, A7);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3, A4, A5, A6, A7);
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7, typename A8>
struct Function<R(A1, A2, A3, A4, A5, A6, A7, A8)>
    : Function<R(A1, A2, A3, A4, A5, A6, A7)> {
  typedef A8 Argument8;
  typedef ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3, A4, A5, A6, A7, A8);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3, A4, A5, A6, A7, A8);
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7, typename A8, typename A9>
struct Function<R(A1, A2, A3, A4, A5, A6, A7, A8, A9)>
    : Function<R(A1, A2, A3, A4, A5, A6, A7, A8)> {
  typedef A9 Argument9;
  typedef ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8, A9> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3, A4, A5, A6, A7, A8, A9);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3, A4, A5, A6, A7, A8,
      A9);
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7, typename A8, typename A9,
    typename A10>
struct Function<R(A1, A2, A3, A4, A5, A6, A7, A8, A9, A10)>
    : Function<R(A1, A2, A3, A4, A5, A6, A7, A8, A9)> {
  typedef A10 Argument10;
  typedef ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8, A9,
      A10> ArgumentTuple;
  typedef typename MatcherTuple<ArgumentTuple>::type ArgumentMatcherTuple;
  typedef void MakeResultVoid(A1, A2, A3, A4, A5, A6, A7, A8, A9, A10);
  typedef IgnoredValue MakeResultIgnoredValue(A1, A2, A3, A4, A5, A6, A7, A8,
      A9, A10);
};

}  // namespace internal

}  // namespace testing

#endif  // GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_GENERATED_INTERNAL_UTILS_H_

namespace testing {
namespace internal {

// Converts an identifier name to a space-separated list of lower-case
// words.  Each maximum substring of the form [A-Za-z][a-z]*|\d+ is
// treated as one word.  For example, both "FooBar123" and
// "foo_bar_123" are converted to "foo bar 123".
GTEST_API_ string ConvertIdentifierNameToWords(const char* id_name);

// PointeeOf<Pointer>::type is the type of a value pointed to by a
// Pointer, which can be either a smart pointer or a raw pointer.  The
// following default implementation is for the case where Pointer is a
// smart pointer.
template <typename Pointer>
struct PointeeOf {
  // Smart pointer classes define type element_type as the type of
  // their pointees.
  typedef typename Pointer::element_type type;
};
// This specialization is for the raw pointer case.
template <typename T>
struct PointeeOf<T*> { typedef T type; };  // NOLINT

// GetRawPointer(p) returns the raw pointer underlying p when p is a
// smart pointer, or returns p itself when p is already a raw pointer.
// The following default implementation is for the smart pointer case.
template <typename Pointer>
inline const typename Pointer::element_type* GetRawPointer(const Pointer& p) {
  return p.get();
}
// This overloaded version is for the raw pointer case.
template <typename Element>
inline Element* GetRawPointer(Element* p) { return p; }

// This comparator allows linked_ptr to be stored in sets.
template <typename T>
struct LinkedPtrLessThan {
  bool operator()(const ::testing::internal::linked_ptr<T>& lhs,
                  const ::testing::internal::linked_ptr<T>& rhs) const {
    return lhs.get() < rhs.get();
  }
};

// Symbian compilation can be done with wchar_t being either a native
// type or a typedef.  Using Google Mock with OpenC without wchar_t
// should require the definition of _STLP_NO_WCHAR_T.
//
// MSVC treats wchar_t as a native type usually, but treats it as the
// same as unsigned short when the compiler option /Zc:wchar_t- is
// specified.  It defines _NATIVE_WCHAR_T_DEFINED symbol when wchar_t
// is a native type.
#if (GTEST_OS_SYMBIAN && defined(_STLP_NO_WCHAR_T)) || \
    (defined(_MSC_VER) && !defined(_NATIVE_WCHAR_T_DEFINED))
// wchar_t is a typedef.
#else
# define GMOCK_WCHAR_T_IS_NATIVE_ 1
#endif

// signed wchar_t and unsigned wchar_t are NOT in the C++ standard.
// Using them is a bad practice and not portable.  So DON'T use them.
//
// Still, Google Mock is designed to work even if the user uses signed
// wchar_t or unsigned wchar_t (obviously, assuming the compiler
// supports them).
//
// To gcc,
//   wchar_t == signed wchar_t != unsigned wchar_t == unsigned int
#ifdef __GNUC__
// signed/unsigned wchar_t are valid types.
# define GMOCK_HAS_SIGNED_WCHAR_T_ 1
#endif

// In what follows, we use the term "kind" to indicate whether a type
// is bool, an integer type (excluding bool), a floating-point type,
// or none of them.  This categorization is useful for determining
// when a matcher argument type can be safely converted to another
// type in the implementation of SafeMatcherCast.
enum TypeKind {
  kBool, kInteger, kFloatingPoint, kOther
};

// KindOf<T>::value is the kind of type T.
template <typename T> struct KindOf {
  enum { value = kOther };  // The default kind.
};

// This macro declares that the kind of 'type' is 'kind'.
#define GMOCK_DECLARE_KIND_(type, kind) \
  template <> struct KindOf<type> { enum { value = kind }; }

GMOCK_DECLARE_KIND_(bool, kBool);

// All standard integer types.
GMOCK_DECLARE_KIND_(char, kInteger);
GMOCK_DECLARE_KIND_(signed char, kInteger);
GMOCK_DECLARE_KIND_(unsigned char, kInteger);
GMOCK_DECLARE_KIND_(short, kInteger);  // NOLINT
GMOCK_DECLARE_KIND_(unsigned short, kInteger);  // NOLINT
GMOCK_DECLARE_KIND_(int, kInteger);
GMOCK_DECLARE_KIND_(unsigned int, kInteger);
GMOCK_DECLARE_KIND_(long, kInteger);  // NOLINT
GMOCK_DECLARE_KIND_(unsigned long, kInteger);  // NOLINT

#if GMOCK_WCHAR_T_IS_NATIVE_
GMOCK_DECLARE_KIND_(wchar_t, kInteger);
#endif

// Non-standard integer types.
GMOCK_DECLARE_KIND_(Int64, kInteger);
GMOCK_DECLARE_KIND_(UInt64, kInteger);

// All standard floating-point types.
GMOCK_DECLARE_KIND_(float, kFloatingPoint);
GMOCK_DECLARE_KIND_(double, kFloatingPoint);
GMOCK_DECLARE_KIND_(long double, kFloatingPoint);

#undef GMOCK_DECLARE_KIND_

// Evaluates to the kind of 'type'.
#define GMOCK_KIND_OF_(type) \
  static_cast< ::testing::internal::TypeKind>( \
      ::testing::internal::KindOf<type>::value)

// Evaluates to true iff integer type T is signed.
#define GMOCK_IS_SIGNED_(T) (static_cast<T>(-1) < 0)

// LosslessArithmeticConvertibleImpl<kFromKind, From, kToKind, To>::value
// is true iff arithmetic type From can be losslessly converted to
// arithmetic type To.
//
// It's the user's responsibility to ensure that both From and To are
// raw (i.e. has no CV modifier, is not a pointer, and is not a
// reference) built-in arithmetic types, kFromKind is the kind of
// From, and kToKind is the kind of To; the value is
// implementation-defined when the above pre-condition is violated.
template <TypeKind kFromKind, typename From, TypeKind kToKind, typename To>
struct LosslessArithmeticConvertibleImpl : public false_type {};

// Converting bool to bool is lossless.
template <>
struct LosslessArithmeticConvertibleImpl<kBool, bool, kBool, bool>
    : public true_type {};  // NOLINT

// Converting bool to any integer type is lossless.
template <typename To>
struct LosslessArithmeticConvertibleImpl<kBool, bool, kInteger, To>
    : public true_type {};  // NOLINT

// Converting bool to any floating-point type is lossless.
template <typename To>
struct LosslessArithmeticConvertibleImpl<kBool, bool, kFloatingPoint, To>
    : public true_type {};  // NOLINT

// Converting an integer to bool is lossy.
template <typename From>
struct LosslessArithmeticConvertibleImpl<kInteger, From, kBool, bool>
    : public false_type {};  // NOLINT

// Converting an integer to another non-bool integer is lossless iff
// the target type's range encloses the source type's range.
template <typename From, typename To>
struct LosslessArithmeticConvertibleImpl<kInteger, From, kInteger, To>
    : public bool_constant<
      // When converting from a smaller size to a larger size, we are
      // fine as long as we are not converting from signed to unsigned.
      ((sizeof(From) < sizeof(To)) &&
       (!GMOCK_IS_SIGNED_(From) || GMOCK_IS_SIGNED_(To))) ||
      // When converting between the same size, the signedness must match.
      ((sizeof(From) == sizeof(To)) &&
       (GMOCK_IS_SIGNED_(From) == GMOCK_IS_SIGNED_(To)))> {};  // NOLINT

#undef GMOCK_IS_SIGNED_

// Converting an integer to a floating-point type may be lossy, since
// the format of a floating-point number is implementation-defined.
template <typename From, typename To>
struct LosslessArithmeticConvertibleImpl<kInteger, From, kFloatingPoint, To>
    : public false_type {};  // NOLINT

// Converting a floating-point to bool is lossy.
template <typename From>
struct LosslessArithmeticConvertibleImpl<kFloatingPoint, From, kBool, bool>
    : public false_type {};  // NOLINT

// Converting a floating-point to an integer is lossy.
template <typename From, typename To>
struct LosslessArithmeticConvertibleImpl<kFloatingPoint, From, kInteger, To>
    : public false_type {};  // NOLINT

// Converting a floating-point to another floating-point is lossless
// iff the target type is at least as big as the source type.
template <typename From, typename To>
struct LosslessArithmeticConvertibleImpl<
  kFloatingPoint, From, kFloatingPoint, To>
    : public bool_constant<sizeof(From) <= sizeof(To)> {};  // NOLINT

// LosslessArithmeticConvertible<From, To>::value is true iff arithmetic
// type From can be losslessly converted to arithmetic type To.
//
// It's the user's responsibility to ensure that both From and To are
// raw (i.e. has no CV modifier, is not a pointer, and is not a
// reference) built-in arithmetic types; the value is
// implementation-defined when the above pre-condition is violated.
template <typename From, typename To>
struct LosslessArithmeticConvertible
    : public LosslessArithmeticConvertibleImpl<
  GMOCK_KIND_OF_(From), From, GMOCK_KIND_OF_(To), To> {};  // NOLINT

// This interface knows how to report a Google Mock failure (either
// non-fatal or fatal).
class FailureReporterInterface {
 public:
  // The type of a failure (either non-fatal or fatal).
  enum FailureType {
    kNonfatal, kFatal
  };

  virtual ~FailureReporterInterface() {}

  // Reports a failure that occurred at the given source file location.
  virtual void ReportFailure(FailureType type, const char* file, int line,
                             const string& message) = 0;
};

// Returns the failure reporter used by Google Mock.
GTEST_API_ FailureReporterInterface* GetFailureReporter();

// Asserts that condition is true; aborts the process with the given
// message if condition is false.  We cannot use LOG(FATAL) or CHECK()
// as Google Mock might be used to mock the log sink itself.  We
// inline this function to prevent it from showing up in the stack
// trace.
inline void Assert(bool condition, const char* file, int line,
                   const string& msg) {
  if (!condition) {
    GetFailureReporter()->ReportFailure(FailureReporterInterface::kFatal,
                                        file, line, msg);
  }
}
inline void Assert(bool condition, const char* file, int line) {
  Assert(condition, file, line, "Assertion failed.");
}

// Verifies that condition is true; generates a non-fatal failure if
// condition is false.
inline void Expect(bool condition, const char* file, int line,
                   const string& msg) {
  if (!condition) {
    GetFailureReporter()->ReportFailure(FailureReporterInterface::kNonfatal,
                                        file, line, msg);
  }
}
inline void Expect(bool condition, const char* file, int line) {
  Expect(condition, file, line, "Expectation failed.");
}

// Severity level of a log.
enum LogSeverity {
  kInfo = 0,
  kWarning = 1
};

// Valid values for the --gmock_verbose flag.

// All logs (informational and warnings) are printed.
const char kInfoVerbosity[] = "info";
// Only warnings are printed.
const char kWarningVerbosity[] = "warning";
// No logs are printed.
const char kErrorVerbosity[] = "error";

// Returns true iff a log with the given severity is visible according
// to the --gmock_verbose flag.
GTEST_API_ bool LogIsVisible(LogSeverity severity);

// Prints the given message to stdout iff 'severity' >= the level
// specified by the --gmock_verbose flag.  If stack_frames_to_skip >=
// 0, also prints the stack trace excluding the top
// stack_frames_to_skip frames.  In opt mode, any positive
// stack_frames_to_skip is treated as 0, since we don't know which
// function calls will be inlined by the compiler and need to be
// conservative.
GTEST_API_ void Log(LogSeverity severity,
                    const string& message,
                    int stack_frames_to_skip);

// TODO(wan@google.com): group all type utilities together.

// Type traits.

// is_reference<T>::value is non-zero iff T is a reference type.
template <typename T> struct is_reference : public false_type {};
template <typename T> struct is_reference<T&> : public true_type {};

// type_equals<T1, T2>::value is non-zero iff T1 and T2 are the same type.
template <typename T1, typename T2> struct type_equals : public false_type {};
template <typename T> struct type_equals<T, T> : public true_type {};

// remove_reference<T>::type removes the reference from type T, if any.
template <typename T> struct remove_reference { typedef T type; };  // NOLINT
template <typename T> struct remove_reference<T&> { typedef T type; }; // NOLINT

// DecayArray<T>::type turns an array type U[N] to const U* and preserves
// other types.  Useful for saving a copy of a function argument.
template <typename T> struct DecayArray { typedef T type; };  // NOLINT
template <typename T, size_t N> struct DecayArray<T[N]> {
  typedef const T* type;
};
// Sometimes people use arrays whose size is not available at the use site
// (e.g. extern const char kNamePrefix[]).  This specialization covers that
// case.
template <typename T> struct DecayArray<T[]> {
  typedef const T* type;
};

// Invalid<T>() returns an invalid value of type T.  This is useful
// when a value of type T is needed for compilation, but the statement
// will not really be executed (or we don't care if the statement
// crashes).
template <typename T>
inline T Invalid() {
  return const_cast<typename remove_reference<T>::type&>(
      *static_cast<volatile typename remove_reference<T>::type*>(NULL));
}
template <>
inline void Invalid<void>() {}

// Given a raw type (i.e. having no top-level reference or const
// modifier) RawContainer that's either an STL-style container or a
// native array, class StlContainerView<RawContainer> has the
// following members:
//
//   - type is a type that provides an STL-style container view to
//     (i.e. implements the STL container concept for) RawContainer;
//   - const_reference is a type that provides a reference to a const
//     RawContainer;
//   - ConstReference(raw_container) returns a const reference to an STL-style
//     container view to raw_container, which is a RawContainer.
//   - Copy(raw_container) returns an STL-style container view of a
//     copy of raw_container, which is a RawContainer.
//
// This generic version is used when RawContainer itself is already an
// STL-style container.
template <class RawContainer>
class StlContainerView {
 public:
  typedef RawContainer type;
  typedef const type& const_reference;

  static const_reference ConstReference(const RawContainer& container) {
    // Ensures that RawContainer is not a const type.
    testing::StaticAssertTypeEq<RawContainer,
        GTEST_REMOVE_CONST_(RawContainer)>();
    return container;
  }
  static type Copy(const RawContainer& container) { return container; }
};

// This specialization is used when RawContainer is a native array type.
template <typename Element, size_t N>
class StlContainerView<Element[N]> {
 public:
  typedef GTEST_REMOVE_CONST_(Element) RawElement;
  typedef internal::NativeArray<RawElement> type;
  // NativeArray<T> can represent a native array either by value or by
  // reference (selected by a constructor argument), so 'const type'
  // can be used to reference a const native array.  We cannot
  // 'typedef const type& const_reference' here, as that would mean
  // ConstReference() has to return a reference to a local variable.
  typedef const type const_reference;

  static const_reference ConstReference(const Element (&array)[N]) {
    // Ensures that Element is not a const type.
    testing::StaticAssertTypeEq<Element, RawElement>();
#if GTEST_OS_SYMBIAN
    // The Nokia Symbian compiler confuses itself in template instantiation
    // for this call without the cast to Element*:
    // function call '[testing::internal::NativeArray<char *>].NativeArray(
    //     {lval} const char *[4], long, testing::internal::RelationToSource)'
    //     does not match
    // 'testing::internal::NativeArray<char *>::NativeArray(
    //     char *const *, unsigned int, testing::internal::RelationToSource)'
    // (instantiating: 'testing::internal::ContainsMatcherImpl
    //     <const char * (&)[4]>::Matches(const char * (&)[4]) const')
    // (instantiating: 'testing::internal::StlContainerView<char *[4]>::
    //     ConstReference(const char * (&)[4])')
    // (and though the N parameter type is mismatched in the above explicit
    // conversion of it doesn't help - only the conversion of the array).
    return type(const_cast<Element*>(&array[0]), N, kReference);
#else
    return type(array, N, kReference);
#endif  // GTEST_OS_SYMBIAN
  }
  static type Copy(const Element (&array)[N]) {
#if GTEST_OS_SYMBIAN
    return type(const_cast<Element*>(&array[0]), N, kCopy);
#else
    return type(array, N, kCopy);
#endif  // GTEST_OS_SYMBIAN
  }
};

// This specialization is used when RawContainer is a native array
// represented as a (pointer, size) tuple.
template <typename ElementPointer, typename Size>
class StlContainerView< ::std::tr1::tuple<ElementPointer, Size> > {
 public:
  typedef GTEST_REMOVE_CONST_(
      typename internal::PointeeOf<ElementPointer>::type) RawElement;
  typedef internal::NativeArray<RawElement> type;
  typedef const type const_reference;

  static const_reference ConstReference(
      const ::std::tr1::tuple<ElementPointer, Size>& array) {
    using ::std::tr1::get;
    return type(get<0>(array), get<1>(array), kReference);
  }
  static type Copy(const ::std::tr1::tuple<ElementPointer, Size>& array) {
    using ::std::tr1::get;
    return type(get<0>(array), get<1>(array), kCopy);
  }
};

// The following specialization prevents the user from instantiating
// StlContainer with a reference type.
template <typename T> class StlContainerView<T&>;

// A type transform to remove constness from the first part of a pair.
// Pairs like that are used as the value_type of associative containers,
// and this transform produces a similar but assignable pair.
template <typename T>
struct RemoveConstFromKey {
  typedef T type;
};

// Partially specialized to remove constness from std::pair<const K, V>.
template <typename K, typename V>
struct RemoveConstFromKey<std::pair<const K, V> > {
  typedef std::pair<K, V> type;
};

// Mapping from booleans to types. Similar to boost::bool_<kValue> and
// std::integral_constant<bool, kValue>.
template <bool kValue>
struct BooleanConstant {};

}  // namespace internal
}  // namespace testing

#endif  // GMOCK_INCLUDE_GMOCK_INTERNAL_GMOCK_INTERNAL_UTILS_H_

namespace testing {

// To implement an action Foo, define:
//   1. a class FooAction that implements the ActionInterface interface, and
//   2. a factory function that creates an Action object from a
//      const FooAction*.
//
// The two-level delegation design follows that of Matcher, providing
// consistency for extension developers.  It also eases ownership
// management as Action objects can now be copied like plain values.

namespace internal {

template <typename F1, typename F2>
class ActionAdaptor;

// BuiltInDefaultValue<T>::Get() returns the "built-in" default
// value for type T, which is NULL when T is a pointer type, 0 when T
// is a numeric type, false when T is bool, or "" when T is string or
// std::string.  For any other type T, this value is undefined and the
// function will abort the process.
template <typename T>
class BuiltInDefaultValue {
 public:
  // This function returns true iff type T has a built-in default value.
  static bool Exists() { return false; }
  static T Get() {
    Assert(false, __FILE__, __LINE__,
           "Default action undefined for the function return type.");
    return internal::Invalid<T>();
    // The above statement will never be reached, but is required in
    // order for this function to compile.
  }
};

// This partial specialization says that we use the same built-in
// default value for T and const T.
template <typename T>
class BuiltInDefaultValue<const T> {
 public:
  static bool Exists() { return BuiltInDefaultValue<T>::Exists(); }
  static T Get() { return BuiltInDefaultValue<T>::Get(); }
};

// This partial specialization defines the default values for pointer
// types.
template <typename T>
class BuiltInDefaultValue<T*> {
 public:
  static bool Exists() { return true; }
  static T* Get() { return NULL; }
};

// The following specializations define the default values for
// specific types we care about.
#define GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(type, value) \
  template <> \
  class BuiltInDefaultValue<type> { \
   public: \
    static bool Exists() { return true; } \
    static type Get() { return value; } \
  }

GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(void, );  // NOLINT
#if GTEST_HAS_GLOBAL_STRING
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(::string, "");
#endif  // GTEST_HAS_GLOBAL_STRING
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(::std::string, "");
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(bool, false);
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(unsigned char, '\0');
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(signed char, '\0');
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(char, '\0');

// There's no need for a default action for signed wchar_t, as that
// type is the same as wchar_t for gcc, and invalid for MSVC.
//
// There's also no need for a default action for unsigned wchar_t, as
// that type is the same as unsigned int for gcc, and invalid for
// MSVC.
#if GMOCK_WCHAR_T_IS_NATIVE_
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(wchar_t, 0U);  // NOLINT
#endif

GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(unsigned short, 0U);  // NOLINT
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(signed short, 0);     // NOLINT
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(unsigned int, 0U);
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(signed int, 0);
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(unsigned long, 0UL);  // NOLINT
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(signed long, 0L);     // NOLINT
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(UInt64, 0);
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(Int64, 0);
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(float, 0);
GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_(double, 0);

#undef GMOCK_DEFINE_DEFAULT_ACTION_FOR_RETURN_TYPE_

}  // namespace internal

// When an unexpected function call is encountered, Google Mock will
// let it return a default value if the user has specified one for its
// return type, or if the return type has a built-in default value;
// otherwise Google Mock won't know what value to return and will have
// to abort the process.
//
// The DefaultValue<T> class allows a user to specify the
// default value for a type T that is both copyable and publicly
// destructible (i.e. anything that can be used as a function return
// type).  The usage is:
//
//   // Sets the default value for type T to be foo.
//   DefaultValue<T>::Set(foo);
template <typename T>
class DefaultValue {
 public:
  // Sets the default value for type T; requires T to be
  // copy-constructable and have a public destructor.
  static void Set(T x) {
    delete value_;
    value_ = new T(x);
  }

  // Unsets the default value for type T.
  static void Clear() {
    delete value_;
    value_ = NULL;
  }

  // Returns true iff the user has set the default value for type T.
  static bool IsSet() { return value_ != NULL; }

  // Returns true if T has a default return value set by the user or there
  // exists a built-in default value.
  static bool Exists() {
    return IsSet() || internal::BuiltInDefaultValue<T>::Exists();
  }

  // Returns the default value for type T if the user has set one;
  // otherwise returns the built-in default value if there is one;
  // otherwise aborts the process.
  static T Get() {
    return value_ == NULL ?
        internal::BuiltInDefaultValue<T>::Get() : *value_;
  }

 private:
  static const T* value_;
};

// This partial specialization allows a user to set default values for
// reference types.
template <typename T>
class DefaultValue<T&> {
 public:
  // Sets the default value for type T&.
  static void Set(T& x) {  // NOLINT
    address_ = &x;
  }

  // Unsets the default value for type T&.
  static void Clear() {
    address_ = NULL;
  }

  // Returns true iff the user has set the default value for type T&.
  static bool IsSet() { return address_ != NULL; }

  // Returns true if T has a default return value set by the user or there
  // exists a built-in default value.
  static bool Exists() {
    return IsSet() || internal::BuiltInDefaultValue<T&>::Exists();
  }

  // Returns the default value for type T& if the user has set one;
  // otherwise returns the built-in default value if there is one;
  // otherwise aborts the process.
  static T& Get() {
    return address_ == NULL ?
        internal::BuiltInDefaultValue<T&>::Get() : *address_;
  }

 private:
  static T* address_;
};

// This specialization allows DefaultValue<void>::Get() to
// compile.
template <>
class DefaultValue<void> {
 public:
  static bool Exists() { return true; }
  static void Get() {}
};

// Points to the user-set default value for type T.
template <typename T>
const T* DefaultValue<T>::value_ = NULL;

// Points to the user-set default value for type T&.
template <typename T>
T* DefaultValue<T&>::address_ = NULL;

// Implement this interface to define an action for function type F.
template <typename F>
class ActionInterface {
 public:
  typedef typename internal::Function<F>::Result Result;
  typedef typename internal::Function<F>::ArgumentTuple ArgumentTuple;

  ActionInterface() {}
  virtual ~ActionInterface() {}

  // Performs the action.  This method is not const, as in general an
  // action can have side effects and be stateful.  For example, a
  // get-the-next-element-from-the-collection action will need to
  // remember the current element.
  virtual Result Perform(const ArgumentTuple& args) = 0;

 private:
  GTEST_DISALLOW_COPY_AND_ASSIGN_(ActionInterface);
};

// An Action<F> is a copyable and IMMUTABLE (except by assignment)
// object that represents an action to be taken when a mock function
// of type F is called.  The implementation of Action<T> is just a
// linked_ptr to const ActionInterface<T>, so copying is fairly cheap.
// Don't inherit from Action!
//
// You can view an object implementing ActionInterface<F> as a
// concrete action (including its current state), and an Action<F>
// object as a handle to it.
template <typename F>
class Action {
 public:
  typedef typename internal::Function<F>::Result Result;
  typedef typename internal::Function<F>::ArgumentTuple ArgumentTuple;

  // Constructs a null Action.  Needed for storing Action objects in
  // STL containers.
  Action() : impl_(NULL) {}

  // Constructs an Action from its implementation.  A NULL impl is
  // used to represent the "do-default" action.
  explicit Action(ActionInterface<F>* impl) : impl_(impl) {}

  // Copy constructor.
  Action(const Action& action) : impl_(action.impl_) {}

  // This constructor allows us to turn an Action<Func> object into an
  // Action<F>, as long as F's arguments can be implicitly converted
  // to Func's and Func's return type can be implicitly converted to
  // F's.
  template <typename Func>
  explicit Action(const Action<Func>& action);

  // Returns true iff this is the DoDefault() action.
  bool IsDoDefault() const { return impl_.get() == NULL; }

  // Performs the action.  Note that this method is const even though
  // the corresponding method in ActionInterface is not.  The reason
  // is that a const Action<F> means that it cannot be re-bound to
  // another concrete action, not that the concrete action it binds to
  // cannot change state.  (Think of the difference between a const
  // pointer and a pointer to const.)
  Result Perform(const ArgumentTuple& args) const {
    internal::Assert(
        !IsDoDefault(), __FILE__, __LINE__,
        "You are using DoDefault() inside a composite action like "
        "DoAll() or WithArgs().  This is not supported for technical "
        "reasons.  Please instead spell out the default action, or "
        "assign the default action to an Action variable and use "
        "the variable in various places.");
    return impl_->Perform(args);
  }

 private:
  template <typename F1, typename F2>
  friend class internal::ActionAdaptor;

  internal::linked_ptr<ActionInterface<F> > impl_;
};

// The PolymorphicAction class template makes it easy to implement a
// polymorphic action (i.e. an action that can be used in mock
// functions of than one type, e.g. Return()).
//
// To define a polymorphic action, a user first provides a COPYABLE
// implementation class that has a Perform() method template:
//
//   class FooAction {
//    public:
//     template <typename Result, typename ArgumentTuple>
//     Result Perform(const ArgumentTuple& args) const {
//       // Processes the arguments and returns a result, using
//       // tr1::get<N>(args) to get the N-th (0-based) argument in the tuple.
//     }
//     ...
//   };
//
// Then the user creates the polymorphic action using
// MakePolymorphicAction(object) where object has type FooAction.  See
// the definition of Return(void) and SetArgumentPointee<N>(value) for
// complete examples.
template <typename Impl>
class PolymorphicAction {
 public:
  explicit PolymorphicAction(const Impl& impl) : impl_(impl) {}

  template <typename F>
  operator Action<F>() const {
    return Action<F>(new MonomorphicImpl<F>(impl_));
  }

 private:
  template <typename F>
  class MonomorphicImpl : public ActionInterface<F> {
   public:
    typedef typename internal::Function<F>::Result Result;
    typedef typename internal::Function<F>::ArgumentTuple ArgumentTuple;

    explicit MonomorphicImpl(const Impl& impl) : impl_(impl) {}

    virtual Result Perform(const ArgumentTuple& args) {
      return impl_.template Perform<Result>(args);
    }

   private:
    Impl impl_;

    GTEST_DISALLOW_ASSIGN_(MonomorphicImpl);
  };

  Impl impl_;

  GTEST_DISALLOW_ASSIGN_(PolymorphicAction);
};

// Creates an Action from its implementation and returns it.  The
// created Action object owns the implementation.
template <typename F>
Action<F> MakeAction(ActionInterface<F>* impl) {
  return Action<F>(impl);
}

// Creates a polymorphic action from its implementation.  This is
// easier to use than the PolymorphicAction<Impl> constructor as it
// doesn't require you to explicitly write the template argument, e.g.
//
//   MakePolymorphicAction(foo);
// vs
//   PolymorphicAction<TypeOfFoo>(foo);
template <typename Impl>
inline PolymorphicAction<Impl> MakePolymorphicAction(const Impl& impl) {
  return PolymorphicAction<Impl>(impl);
}

namespace internal {

// Allows an Action<F2> object to pose as an Action<F1>, as long as F2
// and F1 are compatible.
template <typename F1, typename F2>
class ActionAdaptor : public ActionInterface<F1> {
 public:
  typedef typename internal::Function<F1>::Result Result;
  typedef typename internal::Function<F1>::ArgumentTuple ArgumentTuple;

  explicit ActionAdaptor(const Action<F2>& from) : impl_(from.impl_) {}

  virtual Result Perform(const ArgumentTuple& args) {
    return impl_->Perform(args);
  }

 private:
  const internal::linked_ptr<ActionInterface<F2> > impl_;

  GTEST_DISALLOW_ASSIGN_(ActionAdaptor);
};

// Implements the polymorphic Return(x) action, which can be used in
// any function that returns the type of x, regardless of the argument
// types.
//
// Note: The value passed into Return must be converted into
// Function<F>::Result when this action is cast to Action<F> rather than
// when that action is performed. This is important in scenarios like
//
// MOCK_METHOD1(Method, T(U));
// ...
// {
//   Foo foo;
//   X x(&foo);
//   EXPECT_CALL(mock, Method(_)).WillOnce(Return(x));
// }
//
// In the example above the variable x holds reference to foo which leaves
// scope and gets destroyed.  If copying X just copies a reference to foo,
// that copy will be left with a hanging reference.  If conversion to T
// makes a copy of foo, the above code is safe. To support that scenario, we
// need to make sure that the type conversion happens inside the EXPECT_CALL
// statement, and conversion of the result of Return to Action<T(U)> is a
// good place for that.
//
template <typename R>
class ReturnAction {
 public:
  // Constructs a ReturnAction object from the value to be returned.
  // 'value' is passed by value instead of by const reference in order
  // to allow Return("string literal") to compile.
  explicit ReturnAction(R value) : value_(value) {}

  // This template type conversion operator allows Return(x) to be
  // used in ANY function that returns x's type.
  template <typename F>
  operator Action<F>() const {
    // Assert statement belongs here because this is the best place to verify
    // conditions on F. It produces the clearest error messages
    // in most compilers.
    // Impl really belongs in this scope as a local class but can't
    // because MSVC produces duplicate symbols in different translation units
    // in this case. Until MS fixes that bug we put Impl into the class scope
    // and put the typedef both here (for use in assert statement) and
    // in the Impl class. But both definitions must be the same.
    typedef typename Function<F>::Result Result;
    GTEST_COMPILE_ASSERT_(
        !internal::is_reference<Result>::value,
        use_ReturnRef_instead_of_Return_to_return_a_reference);
    return Action<F>(new Impl<F>(value_));
  }

 private:
  // Implements the Return(x) action for a particular function type F.
  template <typename F>
  class Impl : public ActionInterface<F> {
   public:
    typedef typename Function<F>::Result Result;
    typedef typename Function<F>::ArgumentTuple ArgumentTuple;

    // The implicit cast is necessary when Result has more than one
    // single-argument constructor (e.g. Result is std::vector<int>) and R
    // has a type conversion operator template.  In that case, value_(value)
    // won't compile as the compiler doesn't known which constructor of
    // Result to call.  ImplicitCast_ forces the compiler to convert R to
    // Result without considering explicit constructors, thus resolving the
    // ambiguity. value_ is then initialized using its copy constructor.
    explicit Impl(R value)
        : value_(::testing::internal::ImplicitCast_<Result>(value)) {}

    virtual Result Perform(const ArgumentTuple&) { return value_; }

   private:
    GTEST_COMPILE_ASSERT_(!internal::is_reference<Result>::value,
                          Result_cannot_be_a_reference_type);
    Result value_;

    GTEST_DISALLOW_ASSIGN_(Impl);
  };

  R value_;

  GTEST_DISALLOW_ASSIGN_(ReturnAction);
};

// Implements the ReturnNull() action.
class ReturnNullAction {
 public:
  // Allows ReturnNull() to be used in any pointer-returning function.
  template <typename Result, typename ArgumentTuple>
  static Result Perform(const ArgumentTuple&) {
    GTEST_COMPILE_ASSERT_(internal::is_pointer<Result>::value,
                          ReturnNull_can_be_used_to_return_a_pointer_only);
    return NULL;
  }
};

// Implements the Return() action.
class ReturnVoidAction {
 public:
  // Allows Return() to be used in any void-returning function.
  template <typename Result, typename ArgumentTuple>
  static void Perform(const ArgumentTuple&) {
    CompileAssertTypesEqual<void, Result>();
  }
};

// Implements the polymorphic ReturnRef(x) action, which can be used
// in any function that returns a reference to the type of x,
// regardless of the argument types.
template <typename T>
class ReturnRefAction {
 public:
  // Constructs a ReturnRefAction object from the reference to be returned.
  explicit ReturnRefAction(T& ref) : ref_(ref) {}  // NOLINT

  // This template type conversion operator allows ReturnRef(x) to be
  // used in ANY function that returns a reference to x's type.
  template <typename F>
  operator Action<F>() const {
    typedef typename Function<F>::Result Result;
    // Asserts that the function return type is a reference.  This
    // catches the user error of using ReturnRef(x) when Return(x)
    // should be used, and generates some helpful error message.
    GTEST_COMPILE_ASSERT_(internal::is_reference<Result>::value,
                          use_Return_instead_of_ReturnRef_to_return_a_value);
    return Action<F>(new Impl<F>(ref_));
  }

 private:
  // Implements the ReturnRef(x) action for a particular function type F.
  template <typename F>
  class Impl : public ActionInterface<F> {
   public:
    typedef typename Function<F>::Result Result;
    typedef typename Function<F>::ArgumentTuple ArgumentTuple;

    explicit Impl(T& ref) : ref_(ref) {}  // NOLINT

    virtual Result Perform(const ArgumentTuple&) {
      return ref_;
    }

   private:
    T& ref_;

    GTEST_DISALLOW_ASSIGN_(Impl);
  };

  T& ref_;

  GTEST_DISALLOW_ASSIGN_(ReturnRefAction);
};

// Implements the polymorphic ReturnRefOfCopy(x) action, which can be
// used in any function that returns a reference to the type of x,
// regardless of the argument types.
template <typename T>
class ReturnRefOfCopyAction {
 public:
  // Constructs a ReturnRefOfCopyAction object from the reference to
  // be returned.
  explicit ReturnRefOfCopyAction(const T& value) : value_(value) {}  // NOLINT

  // This template type conversion operator allows ReturnRefOfCopy(x) to be
  // used in ANY function that returns a reference to x's type.
  template <typename F>
  operator Action<F>() const {
    typedef typename Function<F>::Result Result;
    // Asserts that the function return type is a reference.  This
    // catches the user error of using ReturnRefOfCopy(x) when Return(x)
    // should be used, and generates some helpful error message.
    GTEST_COMPILE_ASSERT_(
        internal::is_reference<Result>::value,
        use_Return_instead_of_ReturnRefOfCopy_to_return_a_value);
    return Action<F>(new Impl<F>(value_));
  }

 private:
  // Implements the ReturnRefOfCopy(x) action for a particular function type F.
  template <typename F>
  class Impl : public ActionInterface<F> {
   public:
    typedef typename Function<F>::Result Result;
    typedef typename Function<F>::ArgumentTuple ArgumentTuple;

    explicit Impl(const T& value) : value_(value) {}  // NOLINT

    virtual Result Perform(const ArgumentTuple&) {
      return value_;
    }

   private:
    T value_;

    GTEST_DISALLOW_ASSIGN_(Impl);
  };

  const T value_;

  GTEST_DISALLOW_ASSIGN_(ReturnRefOfCopyAction);
};

// Implements the polymorphic DoDefault() action.
class DoDefaultAction {
 public:
  // This template type conversion operator allows DoDefault() to be
  // used in any function.
  template <typename F>
  operator Action<F>() const { return Action<F>(NULL); }
};

// Implements the Assign action to set a given pointer referent to a
// particular value.
template <typename T1, typename T2>
class AssignAction {
 public:
  AssignAction(T1* ptr, T2 value) : ptr_(ptr), value_(value) {}

  template <typename Result, typename ArgumentTuple>
  void Perform(const ArgumentTuple& /* args */) const {
    *ptr_ = value_;
  }

 private:
  T1* const ptr_;
  const T2 value_;

  GTEST_DISALLOW_ASSIGN_(AssignAction);
};

#if !GTEST_OS_WINDOWS_MOBILE

// Implements the SetErrnoAndReturn action to simulate return from
// various system calls and libc functions.
template <typename T>
class SetErrnoAndReturnAction {
 public:
  SetErrnoAndReturnAction(int errno_value, T result)
      : errno_(errno_value),
        result_(result) {}
  template <typename Result, typename ArgumentTuple>
  Result Perform(const ArgumentTuple& /* args */) const {
    errno = errno_;
    return result_;
  }

 private:
  const int errno_;
  const T result_;

  GTEST_DISALLOW_ASSIGN_(SetErrnoAndReturnAction);
};

#endif  // !GTEST_OS_WINDOWS_MOBILE

// Implements the SetArgumentPointee<N>(x) action for any function
// whose N-th argument (0-based) is a pointer to x's type.  The
// template parameter kIsProto is true iff type A is ProtocolMessage,
// proto2::Message, or a sub-class of those.
template <size_t N, typename A, bool kIsProto>
class SetArgumentPointeeAction {
 public:
  // Constructs an action that sets the variable pointed to by the
  // N-th function argument to 'value'.
  explicit SetArgumentPointeeAction(const A& value) : value_(value) {}

  template <typename Result, typename ArgumentTuple>
  void Perform(const ArgumentTuple& args) const {
    CompileAssertTypesEqual<void, Result>();
    *::std::tr1::get<N>(args) = value_;
  }

 private:
  const A value_;

  GTEST_DISALLOW_ASSIGN_(SetArgumentPointeeAction);
};

template <size_t N, typename Proto>
class SetArgumentPointeeAction<N, Proto, true> {
 public:
  // Constructs an action that sets the variable pointed to by the
  // N-th function argument to 'proto'.  Both ProtocolMessage and
  // proto2::Message have the CopyFrom() method, so the same
  // implementation works for both.
  explicit SetArgumentPointeeAction(const Proto& proto) : proto_(new Proto) {
    proto_->CopyFrom(proto);
  }

  template <typename Result, typename ArgumentTuple>
  void Perform(const ArgumentTuple& args) const {
    CompileAssertTypesEqual<void, Result>();
    ::std::tr1::get<N>(args)->CopyFrom(*proto_);
  }

 private:
  const internal::linked_ptr<Proto> proto_;

  GTEST_DISALLOW_ASSIGN_(SetArgumentPointeeAction);
};

// Implements the InvokeWithoutArgs(f) action.  The template argument
// FunctionImpl is the implementation type of f, which can be either a
// function pointer or a functor.  InvokeWithoutArgs(f) can be used as an
// Action<F> as long as f's type is compatible with F (i.e. f can be
// assigned to a tr1::function<F>).
template <typename FunctionImpl>
class InvokeWithoutArgsAction {
 public:
  // The c'tor makes a copy of function_impl (either a function
  // pointer or a functor).
  explicit InvokeWithoutArgsAction(FunctionImpl function_impl)
      : function_impl_(function_impl) {}

  // Allows InvokeWithoutArgs(f) to be used as any action whose type is
  // compatible with f.
  template <typename Result, typename ArgumentTuple>
  Result Perform(const ArgumentTuple&) { return function_impl_(); }

 private:
  FunctionImpl function_impl_;

  GTEST_DISALLOW_ASSIGN_(InvokeWithoutArgsAction);
};

// Implements the InvokeWithoutArgs(object_ptr, &Class::Method) action.
template <class Class, typename MethodPtr>
class InvokeMethodWithoutArgsAction {
 public:
  InvokeMethodWithoutArgsAction(Class* obj_ptr, MethodPtr method_ptr)
      : obj_ptr_(obj_ptr), method_ptr_(method_ptr) {}

  template <typename Result, typename ArgumentTuple>
  Result Perform(const ArgumentTuple&) const {
    return (obj_ptr_->*method_ptr_)();
  }

 private:
  Class* const obj_ptr_;
  const MethodPtr method_ptr_;

  GTEST_DISALLOW_ASSIGN_(InvokeMethodWithoutArgsAction);
};

// Implements the IgnoreResult(action) action.
template <typename A>
class IgnoreResultAction {
 public:
  explicit IgnoreResultAction(const A& action) : action_(action) {}

  template <typename F>
  operator Action<F>() const {
    // Assert statement belongs here because this is the best place to verify
    // conditions on F. It produces the clearest error messages
    // in most compilers.
    // Impl really belongs in this scope as a local class but can't
    // because MSVC produces duplicate symbols in different translation units
    // in this case. Until MS fixes that bug we put Impl into the class scope
    // and put the typedef both here (for use in assert statement) and
    // in the Impl class. But both definitions must be the same.
    typedef typename internal::Function<F>::Result Result;

    // Asserts at compile time that F returns void.
    CompileAssertTypesEqual<void, Result>();

    return Action<F>(new Impl<F>(action_));
  }

 private:
  template <typename F>
  class Impl : public ActionInterface<F> {
   public:
    typedef typename internal::Function<F>::Result Result;
    typedef typename internal::Function<F>::ArgumentTuple ArgumentTuple;

    explicit Impl(const A& action) : action_(action) {}

    virtual void Perform(const ArgumentTuple& args) {
      // Performs the action and ignores its result.
      action_.Perform(args);
    }

   private:
    // Type OriginalFunction is the same as F except that its return
    // type is IgnoredValue.
    typedef typename internal::Function<F>::MakeResultIgnoredValue
        OriginalFunction;

    const Action<OriginalFunction> action_;

    GTEST_DISALLOW_ASSIGN_(Impl);
  };

  const A action_;

  GTEST_DISALLOW_ASSIGN_(IgnoreResultAction);
};

// A ReferenceWrapper<T> object represents a reference to type T,
// which can be either const or not.  It can be explicitly converted
// from, and implicitly converted to, a T&.  Unlike a reference,
// ReferenceWrapper<T> can be copied and can survive template type
// inference.  This is used to support by-reference arguments in the
// InvokeArgument<N>(...) action.  The idea was from "reference
// wrappers" in tr1, which we don't have in our source tree yet.
template <typename T>
class ReferenceWrapper {
 public:
  // Constructs a ReferenceWrapper<T> object from a T&.
  explicit ReferenceWrapper(T& l_value) : pointer_(&l_value) {}  // NOLINT

  // Allows a ReferenceWrapper<T> object to be implicitly converted to
  // a T&.
  operator T&() const { return *pointer_; }
 private:
  T* pointer_;
};

// Allows the expression ByRef(x) to be printed as a reference to x.
template <typename T>
void PrintTo(const ReferenceWrapper<T>& ref, ::std::ostream* os) {
  T& value = ref;
  UniversalPrinter<T&>::Print(value, os);
}

// Does two actions sequentially.  Used for implementing the DoAll(a1,
// a2, ...) action.
template <typename Action1, typename Action2>
class DoBothAction {
 public:
  DoBothAction(Action1 action1, Action2 action2)
      : action1_(action1), action2_(action2) {}

  // This template type conversion operator allows DoAll(a1, ..., a_n)
  // to be used in ANY function of compatible type.
  template <typename F>
  operator Action<F>() const {
    return Action<F>(new Impl<F>(action1_, action2_));
  }

 private:
  // Implements the DoAll(...) action for a particular function type F.
  template <typename F>
  class Impl : public ActionInterface<F> {
   public:
    typedef typename Function<F>::Result Result;
    typedef typename Function<F>::ArgumentTuple ArgumentTuple;
    typedef typename Function<F>::MakeResultVoid VoidResult;

    Impl(const Action<VoidResult>& action1, const Action<F>& action2)
        : action1_(action1), action2_(action2) {}

    virtual Result Perform(const ArgumentTuple& args) {
      action1_.Perform(args);
      return action2_.Perform(args);
    }

   private:
    const Action<VoidResult> action1_;
    const Action<F> action2_;

    GTEST_DISALLOW_ASSIGN_(Impl);
  };

  Action1 action1_;
  Action2 action2_;

  GTEST_DISALLOW_ASSIGN_(DoBothAction);
};

}  // namespace internal

// An Unused object can be implicitly constructed from ANY value.
// This is handy when defining actions that ignore some or all of the
// mock function arguments.  For example, given
//
//   MOCK_METHOD3(Foo, double(const string& label, double x, double y));
//   MOCK_METHOD3(Bar, double(int index, double x, double y));
//
// instead of
//
//   double DistanceToOriginWithLabel(const string& label, double x, double y) {
//     return sqrt(x*x + y*y);
//   }
//   double DistanceToOriginWithIndex(int index, double x, double y) {
//     return sqrt(x*x + y*y);
//   }
//   ...
//   EXEPCT_CALL(mock, Foo("abc", _, _))
//       .WillOnce(Invoke(DistanceToOriginWithLabel));
//   EXEPCT_CALL(mock, Bar(5, _, _))
//       .WillOnce(Invoke(DistanceToOriginWithIndex));
//
// you could write
//
//   // We can declare any uninteresting argument as Unused.
//   double DistanceToOrigin(Unused, double x, double y) {
//     return sqrt(x*x + y*y);
//   }
//   ...
//   EXEPCT_CALL(mock, Foo("abc", _, _)).WillOnce(Invoke(DistanceToOrigin));
//   EXEPCT_CALL(mock, Bar(5, _, _)).WillOnce(Invoke(DistanceToOrigin));
typedef internal::IgnoredValue Unused;

// This constructor allows us to turn an Action<From> object into an
// Action<To>, as long as To's arguments can be implicitly converted
// to From's and From's return type cann be implicitly converted to
// To's.
template <typename To>
template <typename From>
Action<To>::Action(const Action<From>& from)
    : impl_(new internal::ActionAdaptor<To, From>(from)) {}

// Creates an action that returns 'value'.  'value' is passed by value
// instead of const reference - otherwise Return("string literal")
// will trigger a compiler error about using array as initializer.
template <typename R>
internal::ReturnAction<R> Return(R value) {
  return internal::ReturnAction<R>(value);
}

// Creates an action that returns NULL.
inline PolymorphicAction<internal::ReturnNullAction> ReturnNull() {
  return MakePolymorphicAction(internal::ReturnNullAction());
}

// Creates an action that returns from a void function.
inline PolymorphicAction<internal::ReturnVoidAction> Return() {
  return MakePolymorphicAction(internal::ReturnVoidAction());
}

// Creates an action that returns the reference to a variable.
template <typename R>
inline internal::ReturnRefAction<R> ReturnRef(R& x) {  // NOLINT
  return internal::ReturnRefAction<R>(x);
}

// Creates an action that returns the reference to a copy of the
// argument.  The copy is created when the action is constructed and
// lives as long as the action.
template <typename R>
inline internal::ReturnRefOfCopyAction<R> ReturnRefOfCopy(const R& x) {
  return internal::ReturnRefOfCopyAction<R>(x);
}

// Creates an action that does the default action for the give mock function.
inline internal::DoDefaultAction DoDefault() {
  return internal::DoDefaultAction();
}

// Creates an action that sets the variable pointed by the N-th
// (0-based) function argument to 'value'.
template <size_t N, typename T>
PolymorphicAction<
  internal::SetArgumentPointeeAction<
    N, T, internal::IsAProtocolMessage<T>::value> >
SetArgPointee(const T& x) {
  return MakePolymorphicAction(internal::SetArgumentPointeeAction<
      N, T, internal::IsAProtocolMessage<T>::value>(x));
}

#if !((GTEST_GCC_VER_ && GTEST_GCC_VER_ < 40000) || GTEST_OS_SYMBIAN)
// This overload allows SetArgPointee() to accept a string literal.
// GCC prior to the version 4.0 and Symbian C++ compiler cannot distinguish
// this overload from the templated version and emit a compile error.
template <size_t N>
PolymorphicAction<
  internal::SetArgumentPointeeAction<N, const char*, false> >
SetArgPointee(const char* p) {
  return MakePolymorphicAction(internal::SetArgumentPointeeAction<
      N, const char*, false>(p));
}

template <size_t N>
PolymorphicAction<
  internal::SetArgumentPointeeAction<N, const wchar_t*, false> >
SetArgPointee(const wchar_t* p) {
  return MakePolymorphicAction(internal::SetArgumentPointeeAction<
      N, const wchar_t*, false>(p));
}
#endif

// The following version is DEPRECATED.
template <size_t N, typename T>
PolymorphicAction<
  internal::SetArgumentPointeeAction<
    N, T, internal::IsAProtocolMessage<T>::value> >
SetArgumentPointee(const T& x) {
  return MakePolymorphicAction(internal::SetArgumentPointeeAction<
      N, T, internal::IsAProtocolMessage<T>::value>(x));
}

// Creates an action that sets a pointer referent to a given value.
template <typename T1, typename T2>
PolymorphicAction<internal::AssignAction<T1, T2> > Assign(T1* ptr, T2 val) {
  return MakePolymorphicAction(internal::AssignAction<T1, T2>(ptr, val));
}

#if !GTEST_OS_WINDOWS_MOBILE

// Creates an action that sets errno and returns the appropriate error.
template <typename T>
PolymorphicAction<internal::SetErrnoAndReturnAction<T> >
SetErrnoAndReturn(int errval, T result) {
  return MakePolymorphicAction(
      internal::SetErrnoAndReturnAction<T>(errval, result));
}

#endif  // !GTEST_OS_WINDOWS_MOBILE

// Various overloads for InvokeWithoutArgs().

// Creates an action that invokes 'function_impl' with no argument.
template <typename FunctionImpl>
PolymorphicAction<internal::InvokeWithoutArgsAction<FunctionImpl> >
InvokeWithoutArgs(FunctionImpl function_impl) {
  return MakePolymorphicAction(
      internal::InvokeWithoutArgsAction<FunctionImpl>(function_impl));
}

// Creates an action that invokes the given method on the given object
// with no argument.
template <class Class, typename MethodPtr>
PolymorphicAction<internal::InvokeMethodWithoutArgsAction<Class, MethodPtr> >
InvokeWithoutArgs(Class* obj_ptr, MethodPtr method_ptr) {
  return MakePolymorphicAction(
      internal::InvokeMethodWithoutArgsAction<Class, MethodPtr>(
          obj_ptr, method_ptr));
}

// Creates an action that performs an_action and throws away its
// result.  In other words, it changes the return type of an_action to
// void.  an_action MUST NOT return void, or the code won't compile.
template <typename A>
inline internal::IgnoreResultAction<A> IgnoreResult(const A& an_action) {
  return internal::IgnoreResultAction<A>(an_action);
}

// Creates a reference wrapper for the given L-value.  If necessary,
// you can explicitly specify the type of the reference.  For example,
// suppose 'derived' is an object of type Derived, ByRef(derived)
// would wrap a Derived&.  If you want to wrap a const Base& instead,
// where Base is a base class of Derived, just write:
//
//   ByRef<const Base>(derived)
template <typename T>
inline internal::ReferenceWrapper<T> ByRef(T& l_value) {  // NOLINT
  return internal::ReferenceWrapper<T>(l_value);
}

}  // namespace testing

#endif  // GMOCK_INCLUDE_GMOCK_GMOCK_ACTIONS_H_
// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file implements some commonly used cardinalities.  More
// cardinalities can be defined by the user implementing the
// CardinalityInterface interface if necessary.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_CARDINALITIES_H_
#define GMOCK_INCLUDE_GMOCK_GMOCK_CARDINALITIES_H_

#include <limits.h>
#include <ostream>  // NOLINT

namespace testing {

// To implement a cardinality Foo, define:
//   1. a class FooCardinality that implements the
//      CardinalityInterface interface, and
//   2. a factory function that creates a Cardinality object from a
//      const FooCardinality*.
//
// The two-level delegation design follows that of Matcher, providing
// consistency for extension developers.  It also eases ownership
// management as Cardinality objects can now be copied like plain values.

// The implementation of a cardinality.
class CardinalityInterface {
 public:
  virtual ~CardinalityInterface() {}

  // Conservative estimate on the lower/upper bound of the number of
  // calls allowed.
  virtual int ConservativeLowerBound() const { return 0; }
  virtual int ConservativeUpperBound() const { return INT_MAX; }

  // Returns true iff call_count calls will satisfy this cardinality.
  virtual bool IsSatisfiedByCallCount(int call_count) const = 0;

  // Returns true iff call_count calls will saturate this cardinality.
  virtual bool IsSaturatedByCallCount(int call_count) const = 0;

  // Describes self to an ostream.
  virtual void DescribeTo(::std::ostream* os) const = 0;
};

// A Cardinality is a copyable and IMMUTABLE (except by assignment)
// object that specifies how many times a mock function is expected to
// be called.  The implementation of Cardinality is just a linked_ptr
// to const CardinalityInterface, so copying is fairly cheap.
// Don't inherit from Cardinality!
class GTEST_API_ Cardinality {
 public:
  // Constructs a null cardinality.  Needed for storing Cardinality
  // objects in STL containers.
  Cardinality() {}

  // Constructs a Cardinality from its implementation.
  explicit Cardinality(const CardinalityInterface* impl) : impl_(impl) {}

  // Conservative estimate on the lower/upper bound of the number of
  // calls allowed.
  int ConservativeLowerBound() const { return impl_->ConservativeLowerBound(); }
  int ConservativeUpperBound() const { return impl_->ConservativeUpperBound(); }

  // Returns true iff call_count calls will satisfy this cardinality.
  bool IsSatisfiedByCallCount(int call_count) const {
    return impl_->IsSatisfiedByCallCount(call_count);
  }

  // Returns true iff call_count calls will saturate this cardinality.
  bool IsSaturatedByCallCount(int call_count) const {
    return impl_->IsSaturatedByCallCount(call_count);
  }

  // Returns true iff call_count calls will over-saturate this
  // cardinality, i.e. exceed the maximum number of allowed calls.
  bool IsOverSaturatedByCallCount(int call_count) const {
    return impl_->IsSaturatedByCallCount(call_count) &&
        !impl_->IsSatisfiedByCallCount(call_count);
  }

  // Describes self to an ostream
  void DescribeTo(::std::ostream* os) const { impl_->DescribeTo(os); }

  // Describes the given actual call count to an ostream.
  static void DescribeActualCallCountTo(int actual_call_count,
                                        ::std::ostream* os);

 private:
  internal::linked_ptr<const CardinalityInterface> impl_;
};

// Creates a cardinality that allows at least n calls.
GTEST_API_ Cardinality AtLeast(int n);

// Creates a cardinality that allows at most n calls.
GTEST_API_ Cardinality AtMost(int n);

// Creates a cardinality that allows any number of calls.
GTEST_API_ Cardinality AnyNumber();

// Creates a cardinality that allows between min and max calls.
GTEST_API_ Cardinality Between(int min, int max);

// Creates a cardinality that allows exactly n calls.
GTEST_API_ Cardinality Exactly(int n);

// Creates a cardinality from its implementation.
inline Cardinality MakeCardinality(const CardinalityInterface* c) {
  return Cardinality(c);
}

}  // namespace testing

#endif  // GMOCK_INCLUDE_GMOCK_GMOCK_CARDINALITIES_H_
// This file was GENERATED by a script.  DO NOT EDIT BY HAND!!!

// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file implements some commonly used variadic actions.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_GENERATED_ACTIONS_H_
#define GMOCK_INCLUDE_GMOCK_GMOCK_GENERATED_ACTIONS_H_


namespace testing {
namespace internal {

// InvokeHelper<F> knows how to unpack an N-tuple and invoke an N-ary
// function or method with the unpacked values, where F is a function
// type that takes N arguments.
template <typename Result, typename ArgumentTuple>
class InvokeHelper;

template <typename R>
class InvokeHelper<R, ::std::tr1::tuple<> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<>&) {
    return function();
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<>&) {
    return (obj_ptr->*method_ptr)();
  }
};

template <typename R, typename A1>
class InvokeHelper<R, ::std::tr1::tuple<A1> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1>& args) {
    using ::std::tr1::get;
    return function(get<0>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args));
  }
};

template <typename R, typename A1, typename A2>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2,
      A3>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3, typename A4>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3, A4> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2, A3,
      A4>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args), get<3>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3, A4>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args),
        get<3>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3, A4, A5> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2, A3, A4,
      A5>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3, A4, A5>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args),
        get<3>(args), get<4>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3, A4, A5, A6> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2, A3, A4,
      A5, A6>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3, A4, A5, A6>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args),
        get<3>(args), get<4>(args), get<5>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2, A3, A4,
      A5, A6, A7>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args), get<6>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3, A4, A5, A6,
                            A7>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args),
        get<3>(args), get<4>(args), get<5>(args), get<6>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7, typename A8>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2, A3, A4,
      A5, A6, A7, A8>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args), get<6>(args), get<7>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7,
                            A8>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args),
        get<3>(args), get<4>(args), get<5>(args), get<6>(args), get<7>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7, typename A8, typename A9>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8, A9> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2, A3, A4,
      A5, A6, A7, A8, A9>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args), get<6>(args), get<7>(args), get<8>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8,
                            A9>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args),
        get<3>(args), get<4>(args), get<5>(args), get<6>(args), get<7>(args),
        get<8>(args));
  }
};

template <typename R, typename A1, typename A2, typename A3, typename A4,
    typename A5, typename A6, typename A7, typename A8, typename A9,
    typename A10>
class InvokeHelper<R, ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8, A9,
    A10> > {
 public:
  template <typename Function>
  static R Invoke(Function function, const ::std::tr1::tuple<A1, A2, A3, A4,
      A5, A6, A7, A8, A9, A10>& args) {
    using ::std::tr1::get;
    return function(get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args), get<6>(args), get<7>(args), get<8>(args),
        get<9>(args));
  }

  template <class Class, typename MethodPtr>
  static R InvokeMethod(Class* obj_ptr,
                        MethodPtr method_ptr,
                        const ::std::tr1::tuple<A1, A2, A3, A4, A5, A6, A7, A8,
                            A9, A10>& args) {
    using ::std::tr1::get;
    return (obj_ptr->*method_ptr)(get<0>(args), get<1>(args), get<2>(args),
        get<3>(args), get<4>(args), get<5>(args), get<6>(args), get<7>(args),
        get<8>(args), get<9>(args));
  }
};

// CallableHelper has static methods for invoking "callables",
// i.e. function pointers and functors.  It uses overloading to
// provide a uniform interface for invoking different kinds of
// callables.  In particular, you can use:
//
//   CallableHelper<R>::Call(callable, a1, a2, ..., an)
//
// to invoke an n-ary callable, where R is its return type.  If an
// argument, say a2, needs to be passed by reference, you should write
// ByRef(a2) instead of a2 in the above expression.
template <typename R>
class CallableHelper {
 public:
  // Calls a nullary callable.
  template <typename Function>
  static R Call(Function function) { return function(); }

  // Calls a unary callable.

  // We deliberately pass a1 by value instead of const reference here
  // in case it is a C-string literal.  If we had declared the
  // parameter as 'const A1& a1' and write Call(function, "Hi"), the
  // compiler would've thought A1 is 'char[3]', which causes trouble
  // when you need to copy a value of type A1.  By declaring the
  // parameter as 'A1 a1', the compiler will correctly infer that A1
  // is 'const char*' when it sees Call(function, "Hi").
  //
  // Since this function is defined inline, the compiler can get rid
  // of the copying of the arguments.  Therefore the performance won't
  // be hurt.
  template <typename Function, typename A1>
  static R Call(Function function, A1 a1) { return function(a1); }

  // Calls a binary callable.
  template <typename Function, typename A1, typename A2>
  static R Call(Function function, A1 a1, A2 a2) {
    return function(a1, a2);
  }

  // Calls a ternary callable.
  template <typename Function, typename A1, typename A2, typename A3>
  static R Call(Function function, A1 a1, A2 a2, A3 a3) {
    return function(a1, a2, a3);
  }

  // Calls a 4-ary callable.
  template <typename Function, typename A1, typename A2, typename A3,
      typename A4>
  static R Call(Function function, A1 a1, A2 a2, A3 a3, A4 a4) {
    return function(a1, a2, a3, a4);
  }

  // Calls a 5-ary callable.
  template <typename Function, typename A1, typename A2, typename A3,
      typename A4, typename A5>
  static R Call(Function function, A1 a1, A2 a2, A3 a3, A4 a4, A5 a5) {
    return function(a1, a2, a3, a4, a5);
  }

  // Calls a 6-ary callable.
  template <typename Function, typename A1, typename A2, typename A3,
      typename A4, typename A5, typename A6>
  static R Call(Function function, A1 a1, A2 a2, A3 a3, A4 a4, A5 a5, A6 a6) {
    return function(a1, a2, a3, a4, a5, a6);
  }

  // Calls a 7-ary callable.
  template <typename Function, typename A1, typename A2, typename A3,
      typename A4, typename A5, typename A6, typename A7>
  static R Call(Function function, A1 a1, A2 a2, A3 a3, A4 a4, A5 a5, A6 a6,
      A7 a7) {
    return function(a1, a2, a3, a4, a5, a6, a7);
  }

  // Calls a 8-ary callable.
  template <typename Function, typename A1, typename A2, typename A3,
      typename A4, typename A5, typename A6, typename A7, typename A8>
  static R Call(Function function, A1 a1, A2 a2, A3 a3, A4 a4, A5 a5, A6 a6,
      A7 a7, A8 a8) {
    return function(a1, a2, a3, a4, a5, a6, a7, a8);
  }

  // Calls a 9-ary callable.
  template <typename Function, typename A1, typename A2, typename A3,
      typename A4, typename A5, typename A6, typename A7, typename A8,
      typename A9>
  static R Call(Function function, A1 a1, A2 a2, A3 a3, A4 a4, A5 a5, A6 a6,
      A7 a7, A8 a8, A9 a9) {
    return function(a1, a2, a3, a4, a5, a6, a7, a8, a9);
  }

  // Calls a 10-ary callable.
  template <typename Function, typename A1, typename A2, typename A3,
      typename A4, typename A5, typename A6, typename A7, typename A8,
      typename A9, typename A10>
  static R Call(Function function, A1 a1, A2 a2, A3 a3, A4 a4, A5 a5, A6 a6,
      A7 a7, A8 a8, A9 a9, A10 a10) {
    return function(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10);
  }
};  // class CallableHelper

// An INTERNAL macro for extracting the type of a tuple field.  It's
// subject to change without notice - DO NOT USE IN USER CODE!
#define GMOCK_FIELD_(Tuple, N) \
    typename ::std::tr1::tuple_element<N, Tuple>::type

// SelectArgs<Result, ArgumentTuple, k1, k2, ..., k_n>::type is the
// type of an n-ary function whose i-th (1-based) argument type is the
// k{i}-th (0-based) field of ArgumentTuple, which must be a tuple
// type, and whose return type is Result.  For example,
//   SelectArgs<int, ::std::tr1::tuple<bool, char, double, long>, 0, 3>::type
// is int(bool, long).
//
// SelectArgs<Result, ArgumentTuple, k1, k2, ..., k_n>::Select(args)
// returns the selected fields (k1, k2, ..., k_n) of args as a tuple.
// For example,
//   SelectArgs<int, ::std::tr1::tuple<bool, char, double>, 2, 0>::Select(
//       ::std::tr1::make_tuple(true, 'a', 2.5))
// returns ::std::tr1::tuple (2.5, true).
//
// The numbers in list k1, k2, ..., k_n must be >= 0, where n can be
// in the range [0, 10].  Duplicates are allowed and they don't have
// to be in an ascending or descending order.

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3,
    int k4, int k5, int k6, int k7, int k8, int k9, int k10>
class SelectArgs {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3),
      GMOCK_FIELD_(ArgumentTuple, k4), GMOCK_FIELD_(ArgumentTuple, k5),
      GMOCK_FIELD_(ArgumentTuple, k6), GMOCK_FIELD_(ArgumentTuple, k7),
      GMOCK_FIELD_(ArgumentTuple, k8), GMOCK_FIELD_(ArgumentTuple, k9),
      GMOCK_FIELD_(ArgumentTuple, k10));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args),
        get<k4>(args), get<k5>(args), get<k6>(args), get<k7>(args),
        get<k8>(args), get<k9>(args), get<k10>(args));
  }
};

template <typename Result, typename ArgumentTuple>
class SelectArgs<Result, ArgumentTuple,
                 -1, -1, -1, -1, -1, -1, -1, -1, -1, -1> {
 public:
  typedef Result type();
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& /* args */) {
    using ::std::tr1::get;
    return SelectedArgs();
  }
};

template <typename Result, typename ArgumentTuple, int k1>
class SelectArgs<Result, ArgumentTuple,
                 k1, -1, -1, -1, -1, -1, -1, -1, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, -1, -1, -1, -1, -1, -1, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, k3, -1, -1, -1, -1, -1, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3,
    int k4>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, k3, k4, -1, -1, -1, -1, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3),
      GMOCK_FIELD_(ArgumentTuple, k4));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args),
        get<k4>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3,
    int k4, int k5>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, k3, k4, k5, -1, -1, -1, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3),
      GMOCK_FIELD_(ArgumentTuple, k4), GMOCK_FIELD_(ArgumentTuple, k5));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args),
        get<k4>(args), get<k5>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3,
    int k4, int k5, int k6>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, k3, k4, k5, k6, -1, -1, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3),
      GMOCK_FIELD_(ArgumentTuple, k4), GMOCK_FIELD_(ArgumentTuple, k5),
      GMOCK_FIELD_(ArgumentTuple, k6));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args),
        get<k4>(args), get<k5>(args), get<k6>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3,
    int k4, int k5, int k6, int k7>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, k3, k4, k5, k6, k7, -1, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3),
      GMOCK_FIELD_(ArgumentTuple, k4), GMOCK_FIELD_(ArgumentTuple, k5),
      GMOCK_FIELD_(ArgumentTuple, k6), GMOCK_FIELD_(ArgumentTuple, k7));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args),
        get<k4>(args), get<k5>(args), get<k6>(args), get<k7>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3,
    int k4, int k5, int k6, int k7, int k8>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, k3, k4, k5, k6, k7, k8, -1, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3),
      GMOCK_FIELD_(ArgumentTuple, k4), GMOCK_FIELD_(ArgumentTuple, k5),
      GMOCK_FIELD_(ArgumentTuple, k6), GMOCK_FIELD_(ArgumentTuple, k7),
      GMOCK_FIELD_(ArgumentTuple, k8));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args),
        get<k4>(args), get<k5>(args), get<k6>(args), get<k7>(args),
        get<k8>(args));
  }
};

template <typename Result, typename ArgumentTuple, int k1, int k2, int k3,
    int k4, int k5, int k6, int k7, int k8, int k9>
class SelectArgs<Result, ArgumentTuple,
                 k1, k2, k3, k4, k5, k6, k7, k8, k9, -1> {
 public:
  typedef Result type(GMOCK_FIELD_(ArgumentTuple, k1),
      GMOCK_FIELD_(ArgumentTuple, k2), GMOCK_FIELD_(ArgumentTuple, k3),
      GMOCK_FIELD_(ArgumentTuple, k4), GMOCK_FIELD_(ArgumentTuple, k5),
      GMOCK_FIELD_(ArgumentTuple, k6), GMOCK_FIELD_(ArgumentTuple, k7),
      GMOCK_FIELD_(ArgumentTuple, k8), GMOCK_FIELD_(ArgumentTuple, k9));
  typedef typename Function<type>::ArgumentTuple SelectedArgs;
  static SelectedArgs Select(const ArgumentTuple& args) {
    using ::std::tr1::get;
    return SelectedArgs(get<k1>(args), get<k2>(args), get<k3>(args),
        get<k4>(args), get<k5>(args), get<k6>(args), get<k7>(args),
        get<k8>(args), get<k9>(args));
  }
};

#undef GMOCK_FIELD_

// Implements the WithArgs action.
template <typename InnerAction, int k1 = -1, int k2 = -1, int k3 = -1,
    int k4 = -1, int k5 = -1, int k6 = -1, int k7 = -1, int k8 = -1,
    int k9 = -1, int k10 = -1>
class WithArgsAction {
 public:
  explicit WithArgsAction(const InnerAction& action) : action_(action) {}

  template <typename F>
  operator Action<F>() const { return MakeAction(new Impl<F>(action_)); }

 private:
  template <typename F>
  class Impl : public ActionInterface<F> {
   public:
    typedef typename Function<F>::Result Result;
    typedef typename Function<F>::ArgumentTuple ArgumentTuple;

    explicit Impl(const InnerAction& action) : action_(action) {}

    virtual Result Perform(const ArgumentTuple& args) {
      return action_.Perform(SelectArgs<Result, ArgumentTuple, k1, k2, k3, k4,
          k5, k6, k7, k8, k9, k10>::Select(args));
    }

   private:
    typedef typename SelectArgs<Result, ArgumentTuple,
        k1, k2, k3, k4, k5, k6, k7, k8, k9, k10>::type InnerFunctionType;

    Action<InnerFunctionType> action_;
  };

  const InnerAction action_;

  GTEST_DISALLOW_ASSIGN_(WithArgsAction);
};

// A macro from the ACTION* family (defined later in this file)
// defines an action that can be used in a mock function.  Typically,
// these actions only care about a subset of the arguments of the mock
// function.  For example, if such an action only uses the second
// argument, it can be used in any mock function that takes >= 2
// arguments where the type of the second argument is compatible.
//
// Therefore, the action implementation must be prepared to take more
// arguments than it needs.  The ExcessiveArg type is used to
// represent those excessive arguments.  In order to keep the compiler
// error messages tractable, we define it in the testing namespace
// instead of testing::internal.  However, this is an INTERNAL TYPE
// and subject to change without notice, so a user MUST NOT USE THIS
// TYPE DIRECTLY.
struct ExcessiveArg {};

// A helper class needed for implementing the ACTION* macros.
template <typename Result, class Impl>
class ActionHelper {
 public:
  static Result Perform(Impl* impl, const ::std::tr1::tuple<>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<>(args, ExcessiveArg(),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0>(args, get<0>(args),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1>(args, get<0>(args),
        get<1>(args), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2>(args, get<0>(args),
        get<1>(args), get<2>(args), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2, typename A3>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2,
      A3>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2, A3>(args, get<0>(args),
        get<1>(args), get<2>(args), get<3>(args), ExcessiveArg(),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2, typename A3, typename A4>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2, A3,
      A4>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2, A3, A4>(args,
        get<0>(args), get<1>(args), get<2>(args), get<3>(args), get<4>(args),
        ExcessiveArg(), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2, typename A3, typename A4,
      typename A5>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2, A3, A4,
      A5>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2, A3, A4, A5>(args,
        get<0>(args), get<1>(args), get<2>(args), get<3>(args), get<4>(args),
        get<5>(args), ExcessiveArg(), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2, typename A3, typename A4,
      typename A5, typename A6>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2, A3, A4,
      A5, A6>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2, A3, A4, A5, A6>(args,
        get<0>(args), get<1>(args), get<2>(args), get<3>(args), get<4>(args),
        get<5>(args), get<6>(args), ExcessiveArg(), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2, typename A3, typename A4,
      typename A5, typename A6, typename A7>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2, A3, A4,
      A5, A6, A7>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2, A3, A4, A5, A6,
        A7>(args, get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args), get<6>(args), get<7>(args), ExcessiveArg(),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2, typename A3, typename A4,
      typename A5, typename A6, typename A7, typename A8>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2, A3, A4,
      A5, A6, A7, A8>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2, A3, A4, A5, A6, A7,
        A8>(args, get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args), get<6>(args), get<7>(args), get<8>(args),
        ExcessiveArg());
  }

  template <typename A0, typename A1, typename A2, typename A3, typename A4,
      typename A5, typename A6, typename A7, typename A8, typename A9>
  static Result Perform(Impl* impl, const ::std::tr1::tuple<A0, A1, A2, A3, A4,
      A5, A6, A7, A8, A9>& args) {
    using ::std::tr1::get;
    return impl->template gmock_PerformImpl<A0, A1, A2, A3, A4, A5, A6, A7, A8,
        A9>(args, get<0>(args), get<1>(args), get<2>(args), get<3>(args),
        get<4>(args), get<5>(args), get<6>(args), get<7>(args), get<8>(args),
        get<9>(args));
  }
};

}  // namespace internal

// Various overloads for Invoke().

// WithArgs<N1, N2, ..., Nk>(an_action) creates an action that passes
// the selected arguments of the mock function to an_action and
// performs it.  It serves as an adaptor between actions with
// different argument lists.  C++ doesn't support default arguments for
// function templates, so we have to overload it.
template <int k1, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1>(action);
}

template <int k1, int k2, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2>(action);
}

template <int k1, int k2, int k3, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3>(action);
}

template <int k1, int k2, int k3, int k4, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3, k4>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3, k4>(action);
}

template <int k1, int k2, int k3, int k4, int k5, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5>(action);
}

template <int k1, int k2, int k3, int k4, int k5, int k6, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6>(action);
}

template <int k1, int k2, int k3, int k4, int k5, int k6, int k7,
    typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6, k7>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6,
      k7>(action);
}

template <int k1, int k2, int k3, int k4, int k5, int k6, int k7, int k8,
    typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6, k7, k8>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6, k7,
      k8>(action);
}

template <int k1, int k2, int k3, int k4, int k5, int k6, int k7, int k8,
    int k9, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6, k7, k8, k9>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6, k7, k8,
      k9>(action);
}

template <int k1, int k2, int k3, int k4, int k5, int k6, int k7, int k8,
    int k9, int k10, typename InnerAction>
inline internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6, k7, k8,
    k9, k10>
WithArgs(const InnerAction& action) {
  return internal::WithArgsAction<InnerAction, k1, k2, k3, k4, k5, k6, k7, k8,
      k9, k10>(action);
}

// Creates an action that does actions a1, a2, ..., sequentially in
// each invocation.
template <typename Action1, typename Action2>
inline internal::DoBothAction<Action1, Action2>
DoAll(Action1 a1, Action2 a2) {
  return internal::DoBothAction<Action1, Action2>(a1, a2);
}

template <typename Action1, typename Action2, typename Action3>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    Action3> >
DoAll(Action1 a1, Action2 a2, Action3 a3) {
  return DoAll(a1, DoAll(a2, a3));
}

template <typename Action1, typename Action2, typename Action3,
    typename Action4>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    internal::DoBothAction<Action3, Action4> > >
DoAll(Action1 a1, Action2 a2, Action3 a3, Action4 a4) {
  return DoAll(a1, DoAll(a2, a3, a4));
}

template <typename Action1, typename Action2, typename Action3,
    typename Action4, typename Action5>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    internal::DoBothAction<Action3, internal::DoBothAction<Action4,
    Action5> > > >
DoAll(Action1 a1, Action2 a2, Action3 a3, Action4 a4, Action5 a5) {
  return DoAll(a1, DoAll(a2, a3, a4, a5));
}

template <typename Action1, typename Action2, typename Action3,
    typename Action4, typename Action5, typename Action6>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    internal::DoBothAction<Action3, internal::DoBothAction<Action4,
    internal::DoBothAction<Action5, Action6> > > > >
DoAll(Action1 a1, Action2 a2, Action3 a3, Action4 a4, Action5 a5, Action6 a6) {
  return DoAll(a1, DoAll(a2, a3, a4, a5, a6));
}

template <typename Action1, typename Action2, typename Action3,
    typename Action4, typename Action5, typename Action6, typename Action7>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    internal::DoBothAction<Action3, internal::DoBothAction<Action4,
    internal::DoBothAction<Action5, internal::DoBothAction<Action6,
    Action7> > > > > >
DoAll(Action1 a1, Action2 a2, Action3 a3, Action4 a4, Action5 a5, Action6 a6,
    Action7 a7) {
  return DoAll(a1, DoAll(a2, a3, a4, a5, a6, a7));
}

template <typename Action1, typename Action2, typename Action3,
    typename Action4, typename Action5, typename Action6, typename Action7,
    typename Action8>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    internal::DoBothAction<Action3, internal::DoBothAction<Action4,
    internal::DoBothAction<Action5, internal::DoBothAction<Action6,
    internal::DoBothAction<Action7, Action8> > > > > > >
DoAll(Action1 a1, Action2 a2, Action3 a3, Action4 a4, Action5 a5, Action6 a6,
    Action7 a7, Action8 a8) {
  return DoAll(a1, DoAll(a2, a3, a4, a5, a6, a7, a8));
}

template <typename Action1, typename Action2, typename Action3,
    typename Action4, typename Action5, typename Action6, typename Action7,
    typename Action8, typename Action9>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    internal::DoBothAction<Action3, internal::DoBothAction<Action4,
    internal::DoBothAction<Action5, internal::DoBothAction<Action6,
    internal::DoBothAction<Action7, internal::DoBothAction<Action8,
    Action9> > > > > > > >
DoAll(Action1 a1, Action2 a2, Action3 a3, Action4 a4, Action5 a5, Action6 a6,
    Action7 a7, Action8 a8, Action9 a9) {
  return DoAll(a1, DoAll(a2, a3, a4, a5, a6, a7, a8, a9));
}

template <typename Action1, typename Action2, typename Action3,
    typename Action4, typename Action5, typename Action6, typename Action7,
    typename Action8, typename Action9, typename Action10>
inline internal::DoBothAction<Action1, internal::DoBothAction<Action2,
    internal::DoBothAction<Action3, internal::DoBothAction<Action4,
    internal::DoBothAction<Action5, internal::DoBothAction<Action6,
    internal::DoBothAction<Action7, internal::DoBothAction<Action8,
    internal::DoBothAction<Action9, Action10> > > > > > > > >
DoAll(Action1 a1, Action2 a2, Action3 a3, Action4 a4, Action5 a5, Action6 a6,
    Action7 a7, Action8 a8, Action9 a9, Action10 a10) {
  return DoAll(a1, DoAll(a2, a3, a4, a5, a6, a7, a8, a9, a10));
}

}  // namespace testing

// The ACTION* family of macros can be used in a namespace scope to
// define custom actions easily.  The syntax:
//
//   ACTION(name) { statements; }
//
// will define an action with the given name that executes the
// statements.  The value returned by the statements will be used as
// the return value of the action.  Inside the statements, you can
// refer to the K-th (0-based) argument of the mock function by
// 'argK', and refer to its type by 'argK_type'.  For example:
//
//   ACTION(IncrementArg1) {
//     arg1_type temp = arg1;
//     return ++(*temp);
//   }
//
// allows you to write
//
//   ...WillOnce(IncrementArg1());
//
// You can also refer to the entire argument tuple and its type by
// 'args' and 'args_type', and refer to the mock function type and its
// return type by 'function_type' and 'return_type'.
//
// Note that you don't need to specify the types of the mock function
// arguments.  However rest assured that your code is still type-safe:
// you'll get a compiler error if *arg1 doesn't support the ++
// operator, or if the type of ++(*arg1) isn't compatible with the
// mock function's return type, for example.
//
// Sometimes you'll want to parameterize the action.   For that you can use
// another macro:
//
//   ACTION_P(name, param_name) { statements; }
//
// For example:
//
//   ACTION_P(Add, n) { return arg0 + n; }
//
// will allow you to write:
//
//   ...WillOnce(Add(5));
//
// Note that you don't need to provide the type of the parameter
// either.  If you need to reference the type of a parameter named
// 'foo', you can write 'foo_type'.  For example, in the body of
// ACTION_P(Add, n) above, you can write 'n_type' to refer to the type
// of 'n'.
//
// We also provide ACTION_P2, ACTION_P3, ..., up to ACTION_P10 to support
// multi-parameter actions.
//
// For the purpose of typing, you can view
//
//   ACTION_Pk(Foo, p1, ..., pk) { ... }
//
// as shorthand for
//
//   template <typename p1_type, ..., typename pk_type>
//   FooActionPk<p1_type, ..., pk_type> Foo(p1_type p1, ..., pk_type pk) { ... }
//
// In particular, you can provide the template type arguments
// explicitly when invoking Foo(), as in Foo<long, bool>(5, false);
// although usually you can rely on the compiler to infer the types
// for you automatically.  You can assign the result of expression
// Foo(p1, ..., pk) to a variable of type FooActionPk<p1_type, ...,
// pk_type>.  This can be useful when composing actions.
//
// You can also overload actions with different numbers of parameters:
//
//   ACTION_P(Plus, a) { ... }
//   ACTION_P2(Plus, a, b) { ... }
//
// While it's tempting to always use the ACTION* macros when defining
// a new action, you should also consider implementing ActionInterface
// or using MakePolymorphicAction() instead, especially if you need to
// use the action a lot.  While these approaches require more work,
// they give you more control on the types of the mock function
// arguments and the action parameters, which in general leads to
// better compiler error messages that pay off in the long run.  They
// also allow overloading actions based on parameter types (as opposed
// to just based on the number of parameters).
//
// CAVEAT:
//
// ACTION*() can only be used in a namespace scope.  The reason is
// that C++ doesn't yet allow function-local types to be used to
// instantiate templates.  The up-coming C++0x standard will fix this.
// Once that's done, we'll consider supporting using ACTION*() inside
// a function.
//
// MORE INFORMATION:
//
// To learn more about using these macros, please search for 'ACTION'
// on http://code.google.com/p/googlemock/wiki/CookBook.

// An internal macro needed for implementing ACTION*().
#define GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_\
    const args_type& args GTEST_ATTRIBUTE_UNUSED_, \
    arg0_type arg0 GTEST_ATTRIBUTE_UNUSED_, \
    arg1_type arg1 GTEST_ATTRIBUTE_UNUSED_, \
    arg2_type arg2 GTEST_ATTRIBUTE_UNUSED_, \
    arg3_type arg3 GTEST_ATTRIBUTE_UNUSED_, \
    arg4_type arg4 GTEST_ATTRIBUTE_UNUSED_, \
    arg5_type arg5 GTEST_ATTRIBUTE_UNUSED_, \
    arg6_type arg6 GTEST_ATTRIBUTE_UNUSED_, \
    arg7_type arg7 GTEST_ATTRIBUTE_UNUSED_, \
    arg8_type arg8 GTEST_ATTRIBUTE_UNUSED_, \
    arg9_type arg9 GTEST_ATTRIBUTE_UNUSED_

// Sometimes you want to give an action explicit template parameters
// that cannot be inferred from its value parameters.  ACTION() and
// ACTION_P*() don't support that.  ACTION_TEMPLATE() remedies that
// and can be viewed as an extension to ACTION() and ACTION_P*().
//
// The syntax:
//
//   ACTION_TEMPLATE(ActionName,
//                   HAS_m_TEMPLATE_PARAMS(kind1, name1, ..., kind_m, name_m),
//                   AND_n_VALUE_PARAMS(p1, ..., p_n)) { statements; }
//
// defines an action template that takes m explicit template
// parameters and n value parameters.  name_i is the name of the i-th
// template parameter, and kind_i specifies whether it's a typename,
// an integral constant, or a template.  p_i is the name of the i-th
// value parameter.
//
// Example:
//
//   // DuplicateArg<k, T>(output) converts the k-th argument of the mock
//   // function to type T and copies it to *output.
//   ACTION_TEMPLATE(DuplicateArg,
//                   HAS_2_TEMPLATE_PARAMS(int, k, typename, T),
//                   AND_1_VALUE_PARAMS(output)) {
//     *output = T(std::tr1::get<k>(args));
//   }
//   ...
//     int n;
//     EXPECT_CALL(mock, Foo(_, _))
//         .WillOnce(DuplicateArg<1, unsigned char>(&n));
//
// To create an instance of an action template, write:
//
//   ActionName<t1, ..., t_m>(v1, ..., v_n)
//
// where the ts are the template arguments and the vs are the value
// arguments.  The value argument types are inferred by the compiler.
// If you want to explicitly specify the value argument types, you can
// provide additional template arguments:
//
//   ActionName<t1, ..., t_m, u1, ..., u_k>(v1, ..., v_n)
//
// where u_i is the desired type of v_i.
//
// ACTION_TEMPLATE and ACTION/ACTION_P* can be overloaded on the
// number of value parameters, but not on the number of template
// parameters.  Without the restriction, the meaning of the following
// is unclear:
//
//   OverloadedAction<int, bool>(x);
//
// Are we using a single-template-parameter action where 'bool' refers
// to the type of x, or are we using a two-template-parameter action
// where the compiler is asked to infer the type of x?
//
// Implementation notes:
//
// GMOCK_INTERNAL_*_HAS_m_TEMPLATE_PARAMS and
// GMOCK_INTERNAL_*_AND_n_VALUE_PARAMS are internal macros for
// implementing ACTION_TEMPLATE.  The main trick we use is to create
// new macro invocations when expanding a macro.  For example, we have
//
//   #define ACTION_TEMPLATE(name, template_params, value_params)
//       ... GMOCK_INTERNAL_DECL_##template_params ...
//
// which causes ACTION_TEMPLATE(..., HAS_1_TEMPLATE_PARAMS(typename, T), ...)
// to expand to
//
//       ... GMOCK_INTERNAL_DECL_HAS_1_TEMPLATE_PARAMS(typename, T) ...
//
// Since GMOCK_INTERNAL_DECL_HAS_1_TEMPLATE_PARAMS is a macro, the
// preprocessor will continue to expand it to
//
//       ... typename T ...
//
// This technique conforms to the C++ standard and is portable.  It
// allows us to implement action templates using O(N) code, where N is
// the maximum number of template/value parameters supported.  Without
// using it, we'd have to devote O(N^2) amount of code to implement all
// combinations of m and n.

// Declares the template parameters.
#define GMOCK_INTERNAL_DECL_HAS_1_TEMPLATE_PARAMS(kind0, name0) kind0 name0
#define GMOCK_INTERNAL_DECL_HAS_2_TEMPLATE_PARAMS(kind0, name0, kind1, \
    name1) kind0 name0, kind1 name1
#define GMOCK_INTERNAL_DECL_HAS_3_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2) kind0 name0, kind1 name1, kind2 name2
#define GMOCK_INTERNAL_DECL_HAS_4_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3) kind0 name0, kind1 name1, kind2 name2, \
    kind3 name3
#define GMOCK_INTERNAL_DECL_HAS_5_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4) kind0 name0, kind1 name1, \
    kind2 name2, kind3 name3, kind4 name4
#define GMOCK_INTERNAL_DECL_HAS_6_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5) kind0 name0, \
    kind1 name1, kind2 name2, kind3 name3, kind4 name4, kind5 name5
#define GMOCK_INTERNAL_DECL_HAS_7_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, \
    name6) kind0 name0, kind1 name1, kind2 name2, kind3 name3, kind4 name4, \
    kind5 name5, kind6 name6
#define GMOCK_INTERNAL_DECL_HAS_8_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, name6, \
    kind7, name7) kind0 name0, kind1 name1, kind2 name2, kind3 name3, \
    kind4 name4, kind5 name5, kind6 name6, kind7 name7
#define GMOCK_INTERNAL_DECL_HAS_9_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, name6, \
    kind7, name7, kind8, name8) kind0 name0, kind1 name1, kind2 name2, \
    kind3 name3, kind4 name4, kind5 name5, kind6 name6, kind7 name7, \
    kind8 name8
#define GMOCK_INTERNAL_DECL_HAS_10_TEMPLATE_PARAMS(kind0, name0, kind1, \
    name1, kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, \
    name6, kind7, name7, kind8, name8, kind9, name9) kind0 name0, \
    kind1 name1, kind2 name2, kind3 name3, kind4 name4, kind5 name5, \
    kind6 name6, kind7 name7, kind8 name8, kind9 name9

// Lists the template parameters.
#define GMOCK_INTERNAL_LIST_HAS_1_TEMPLATE_PARAMS(kind0, name0) name0
#define GMOCK_INTERNAL_LIST_HAS_2_TEMPLATE_PARAMS(kind0, name0, kind1, \
    name1) name0, name1
#define GMOCK_INTERNAL_LIST_HAS_3_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2) name0, name1, name2
#define GMOCK_INTERNAL_LIST_HAS_4_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3) name0, name1, name2, name3
#define GMOCK_INTERNAL_LIST_HAS_5_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4) name0, name1, name2, name3, \
    name4
#define GMOCK_INTERNAL_LIST_HAS_6_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5) name0, name1, \
    name2, name3, name4, name5
#define GMOCK_INTERNAL_LIST_HAS_7_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, \
    name6) name0, name1, name2, name3, name4, name5, name6
#define GMOCK_INTERNAL_LIST_HAS_8_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, name6, \
    kind7, name7) name0, name1, name2, name3, name4, name5, name6, name7
#define GMOCK_INTERNAL_LIST_HAS_9_TEMPLATE_PARAMS(kind0, name0, kind1, name1, \
    kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, name6, \
    kind7, name7, kind8, name8) name0, name1, name2, name3, name4, name5, \
    name6, name7, name8
#define GMOCK_INTERNAL_LIST_HAS_10_TEMPLATE_PARAMS(kind0, name0, kind1, \
    name1, kind2, name2, kind3, name3, kind4, name4, kind5, name5, kind6, \
    name6, kind7, name7, kind8, name8, kind9, name9) name0, name1, name2, \
    name3, name4, name5, name6, name7, name8, name9

// Declares the types of value parameters.
#define GMOCK_INTERNAL_DECL_TYPE_AND_0_VALUE_PARAMS()
#define GMOCK_INTERNAL_DECL_TYPE_AND_1_VALUE_PARAMS(p0) , typename p0##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_2_VALUE_PARAMS(p0, p1) , \
    typename p0##_type, typename p1##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_3_VALUE_PARAMS(p0, p1, p2) , \
    typename p0##_type, typename p1##_type, typename p2##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_4_VALUE_PARAMS(p0, p1, p2, p3) , \
    typename p0##_type, typename p1##_type, typename p2##_type, \
    typename p3##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_5_VALUE_PARAMS(p0, p1, p2, p3, p4) , \
    typename p0##_type, typename p1##_type, typename p2##_type, \
    typename p3##_type, typename p4##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, p5) , \
    typename p0##_type, typename p1##_type, typename p2##_type, \
    typename p3##_type, typename p4##_type, typename p5##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6) , typename p0##_type, typename p1##_type, typename p2##_type, \
    typename p3##_type, typename p4##_type, typename p5##_type, \
    typename p6##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6, p7) , typename p0##_type, typename p1##_type, typename p2##_type, \
    typename p3##_type, typename p4##_type, typename p5##_type, \
    typename p6##_type, typename p7##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6, p7, p8) , typename p0##_type, typename p1##_type, typename p2##_type, \
    typename p3##_type, typename p4##_type, typename p5##_type, \
    typename p6##_type, typename p7##_type, typename p8##_type
#define GMOCK_INTERNAL_DECL_TYPE_AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6, p7, p8, p9) , typename p0##_type, typename p1##_type, \
    typename p2##_type, typename p3##_type, typename p4##_type, \
    typename p5##_type, typename p6##_type, typename p7##_type, \
    typename p8##_type, typename p9##_type

// Initializes the value parameters.
#define GMOCK_INTERNAL_INIT_AND_0_VALUE_PARAMS()\
    ()
#define GMOCK_INTERNAL_INIT_AND_1_VALUE_PARAMS(p0)\
    (p0##_type gmock_p0) : p0(gmock_p0)
#define GMOCK_INTERNAL_INIT_AND_2_VALUE_PARAMS(p0, p1)\
    (p0##_type gmock_p0, p1##_type gmock_p1) : p0(gmock_p0), p1(gmock_p1)
#define GMOCK_INTERNAL_INIT_AND_3_VALUE_PARAMS(p0, p1, p2)\
    (p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2)
#define GMOCK_INTERNAL_INIT_AND_4_VALUE_PARAMS(p0, p1, p2, p3)\
    (p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
        p3##_type gmock_p3) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3)
#define GMOCK_INTERNAL_INIT_AND_5_VALUE_PARAMS(p0, p1, p2, p3, p4)\
    (p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
        p3##_type gmock_p3, p4##_type gmock_p4) : p0(gmock_p0), p1(gmock_p1), \
        p2(gmock_p2), p3(gmock_p3), p4(gmock_p4)
#define GMOCK_INTERNAL_INIT_AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, p5)\
    (p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
        p3##_type gmock_p3, p4##_type gmock_p4, \
        p5##_type gmock_p5) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4), p5(gmock_p5)
#define GMOCK_INTERNAL_INIT_AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6)\
    (p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
        p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
        p6##_type gmock_p6) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6)
#define GMOCK_INTERNAL_INIT_AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, p7)\
    (p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
        p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
        p6##_type gmock_p6, p7##_type gmock_p7) : p0(gmock_p0), p1(gmock_p1), \
        p2(gmock_p2), p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), \
        p7(gmock_p7)
#define GMOCK_INTERNAL_INIT_AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8)\
    (p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
        p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
        p6##_type gmock_p6, p7##_type gmock_p7, \
        p8##_type gmock_p8) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), p7(gmock_p7), \
        p8(gmock_p8)
#define GMOCK_INTERNAL_INIT_AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8, p9)\
    (p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
        p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
        p6##_type gmock_p6, p7##_type gmock_p7, p8##_type gmock_p8, \
        p9##_type gmock_p9) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), p7(gmock_p7), \
        p8(gmock_p8), p9(gmock_p9)

// Declares the fields for storing the value parameters.
#define GMOCK_INTERNAL_DEFN_AND_0_VALUE_PARAMS()
#define GMOCK_INTERNAL_DEFN_AND_1_VALUE_PARAMS(p0) p0##_type p0;
#define GMOCK_INTERNAL_DEFN_AND_2_VALUE_PARAMS(p0, p1) p0##_type p0; \
    p1##_type p1;
#define GMOCK_INTERNAL_DEFN_AND_3_VALUE_PARAMS(p0, p1, p2) p0##_type p0; \
    p1##_type p1; p2##_type p2;
#define GMOCK_INTERNAL_DEFN_AND_4_VALUE_PARAMS(p0, p1, p2, p3) p0##_type p0; \
    p1##_type p1; p2##_type p2; p3##_type p3;
#define GMOCK_INTERNAL_DEFN_AND_5_VALUE_PARAMS(p0, p1, p2, p3, \
    p4) p0##_type p0; p1##_type p1; p2##_type p2; p3##_type p3; p4##_type p4;
#define GMOCK_INTERNAL_DEFN_AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, \
    p5) p0##_type p0; p1##_type p1; p2##_type p2; p3##_type p3; p4##_type p4; \
    p5##_type p5;
#define GMOCK_INTERNAL_DEFN_AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6) p0##_type p0; p1##_type p1; p2##_type p2; p3##_type p3; p4##_type p4; \
    p5##_type p5; p6##_type p6;
#define GMOCK_INTERNAL_DEFN_AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7) p0##_type p0; p1##_type p1; p2##_type p2; p3##_type p3; p4##_type p4; \
    p5##_type p5; p6##_type p6; p7##_type p7;
#define GMOCK_INTERNAL_DEFN_AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8) p0##_type p0; p1##_type p1; p2##_type p2; p3##_type p3; \
    p4##_type p4; p5##_type p5; p6##_type p6; p7##_type p7; p8##_type p8;
#define GMOCK_INTERNAL_DEFN_AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8, p9) p0##_type p0; p1##_type p1; p2##_type p2; p3##_type p3; \
    p4##_type p4; p5##_type p5; p6##_type p6; p7##_type p7; p8##_type p8; \
    p9##_type p9;

// Lists the value parameters.
#define GMOCK_INTERNAL_LIST_AND_0_VALUE_PARAMS()
#define GMOCK_INTERNAL_LIST_AND_1_VALUE_PARAMS(p0) p0
#define GMOCK_INTERNAL_LIST_AND_2_VALUE_PARAMS(p0, p1) p0, p1
#define GMOCK_INTERNAL_LIST_AND_3_VALUE_PARAMS(p0, p1, p2) p0, p1, p2
#define GMOCK_INTERNAL_LIST_AND_4_VALUE_PARAMS(p0, p1, p2, p3) p0, p1, p2, p3
#define GMOCK_INTERNAL_LIST_AND_5_VALUE_PARAMS(p0, p1, p2, p3, p4) p0, p1, \
    p2, p3, p4
#define GMOCK_INTERNAL_LIST_AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, p5) p0, \
    p1, p2, p3, p4, p5
#define GMOCK_INTERNAL_LIST_AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6) p0, p1, p2, p3, p4, p5, p6
#define GMOCK_INTERNAL_LIST_AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7) p0, p1, p2, p3, p4, p5, p6, p7
#define GMOCK_INTERNAL_LIST_AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8) p0, p1, p2, p3, p4, p5, p6, p7, p8
#define GMOCK_INTERNAL_LIST_AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8, p9) p0, p1, p2, p3, p4, p5, p6, p7, p8, p9

// Lists the value parameter types.
#define GMOCK_INTERNAL_LIST_TYPE_AND_0_VALUE_PARAMS()
#define GMOCK_INTERNAL_LIST_TYPE_AND_1_VALUE_PARAMS(p0) , p0##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_2_VALUE_PARAMS(p0, p1) , p0##_type, \
    p1##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_3_VALUE_PARAMS(p0, p1, p2) , p0##_type, \
    p1##_type, p2##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_4_VALUE_PARAMS(p0, p1, p2, p3) , \
    p0##_type, p1##_type, p2##_type, p3##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_5_VALUE_PARAMS(p0, p1, p2, p3, p4) , \
    p0##_type, p1##_type, p2##_type, p3##_type, p4##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, p5) , \
    p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, p5##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6) , p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, p5##_type, \
    p6##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6, p7) , p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
    p5##_type, p6##_type, p7##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6, p7, p8) , p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
    p5##_type, p6##_type, p7##_type, p8##_type
#define GMOCK_INTERNAL_LIST_TYPE_AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6, p7, p8, p9) , p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
    p5##_type, p6##_type, p7##_type, p8##_type, p9##_type

// Declares the value parameters.
#define GMOCK_INTERNAL_DECL_AND_0_VALUE_PARAMS()
#define GMOCK_INTERNAL_DECL_AND_1_VALUE_PARAMS(p0) p0##_type p0
#define GMOCK_INTERNAL_DECL_AND_2_VALUE_PARAMS(p0, p1) p0##_type p0, \
    p1##_type p1
#define GMOCK_INTERNAL_DECL_AND_3_VALUE_PARAMS(p0, p1, p2) p0##_type p0, \
    p1##_type p1, p2##_type p2
#define GMOCK_INTERNAL_DECL_AND_4_VALUE_PARAMS(p0, p1, p2, p3) p0##_type p0, \
    p1##_type p1, p2##_type p2, p3##_type p3
#define GMOCK_INTERNAL_DECL_AND_5_VALUE_PARAMS(p0, p1, p2, p3, \
    p4) p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, p4##_type p4
#define GMOCK_INTERNAL_DECL_AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, \
    p5) p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, p4##_type p4, \
    p5##_type p5
#define GMOCK_INTERNAL_DECL_AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, \
    p6) p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, p4##_type p4, \
    p5##_type p5, p6##_type p6
#define GMOCK_INTERNAL_DECL_AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7) p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, p4##_type p4, \
    p5##_type p5, p6##_type p6, p7##_type p7
#define GMOCK_INTERNAL_DECL_AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8) p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, \
    p4##_type p4, p5##_type p5, p6##_type p6, p7##_type p7, p8##_type p8
#define GMOCK_INTERNAL_DECL_AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8, p9) p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, \
    p4##_type p4, p5##_type p5, p6##_type p6, p7##_type p7, p8##_type p8, \
    p9##_type p9

// The suffix of the class template implementing the action template.
#define GMOCK_INTERNAL_COUNT_AND_0_VALUE_PARAMS()
#define GMOCK_INTERNAL_COUNT_AND_1_VALUE_PARAMS(p0) P
#define GMOCK_INTERNAL_COUNT_AND_2_VALUE_PARAMS(p0, p1) P2
#define GMOCK_INTERNAL_COUNT_AND_3_VALUE_PARAMS(p0, p1, p2) P3
#define GMOCK_INTERNAL_COUNT_AND_4_VALUE_PARAMS(p0, p1, p2, p3) P4
#define GMOCK_INTERNAL_COUNT_AND_5_VALUE_PARAMS(p0, p1, p2, p3, p4) P5
#define GMOCK_INTERNAL_COUNT_AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, p5) P6
#define GMOCK_INTERNAL_COUNT_AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6) P7
#define GMOCK_INTERNAL_COUNT_AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7) P8
#define GMOCK_INTERNAL_COUNT_AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8) P9
#define GMOCK_INTERNAL_COUNT_AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, \
    p7, p8, p9) P10

// The name of the class template implementing the action template.
#define GMOCK_ACTION_CLASS_(name, value_params)\
    GTEST_CONCAT_TOKEN_(name##Action, GMOCK_INTERNAL_COUNT_##value_params)

#define ACTION_TEMPLATE(name, template_params, value_params)\
  template <GMOCK_INTERNAL_DECL_##template_params\
            GMOCK_INTERNAL_DECL_TYPE_##value_params>\
  class GMOCK_ACTION_CLASS_(name, value_params) {\
   public:\
    GMOCK_ACTION_CLASS_(name, value_params)\
        GMOCK_INTERNAL_INIT_##value_params {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      explicit gmock_Impl GMOCK_INTERNAL_INIT_##value_params {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      GMOCK_INTERNAL_DEFN_##value_params\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(\
          new gmock_Impl<F>(GMOCK_INTERNAL_LIST_##value_params));\
    }\
    GMOCK_INTERNAL_DEFN_##value_params\
   private:\
    GTEST_DISALLOW_ASSIGN_(GMOCK_ACTION_CLASS_(name, value_params));\
  };\
  template <GMOCK_INTERNAL_DECL_##template_params\
            GMOCK_INTERNAL_DECL_TYPE_##value_params>\
  inline GMOCK_ACTION_CLASS_(name, value_params)<\
      GMOCK_INTERNAL_LIST_##template_params\
      GMOCK_INTERNAL_LIST_TYPE_##value_params> name(\
          GMOCK_INTERNAL_DECL_##value_params) {\
    return GMOCK_ACTION_CLASS_(name, value_params)<\
        GMOCK_INTERNAL_LIST_##template_params\
        GMOCK_INTERNAL_LIST_TYPE_##value_params>(\
            GMOCK_INTERNAL_LIST_##value_params);\
  }\
  template <GMOCK_INTERNAL_DECL_##template_params\
            GMOCK_INTERNAL_DECL_TYPE_##value_params>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      GMOCK_ACTION_CLASS_(name, value_params)<\
          GMOCK_INTERNAL_LIST_##template_params\
          GMOCK_INTERNAL_LIST_TYPE_##value_params>::gmock_Impl<F>::\
              gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION(name)\
  class name##Action {\
   public:\
    name##Action() {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl() {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>());\
    }\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##Action);\
  };\
  inline name##Action name() {\
    return name##Action();\
  }\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##Action::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P(name, p0)\
  template <typename p0##_type>\
  class name##ActionP {\
   public:\
    name##ActionP(p0##_type gmock_p0) : p0(gmock_p0) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      explicit gmock_Impl(p0##_type gmock_p0) : p0(gmock_p0) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0));\
    }\
    p0##_type p0;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP);\
  };\
  template <typename p0##_type>\
  inline name##ActionP<p0##_type> name(p0##_type p0) {\
    return name##ActionP<p0##_type>(p0);\
  }\
  template <typename p0##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP<p0##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P2(name, p0, p1)\
  template <typename p0##_type, typename p1##_type>\
  class name##ActionP2 {\
   public:\
    name##ActionP2(p0##_type gmock_p0, p1##_type gmock_p1) : p0(gmock_p0), \
        p1(gmock_p1) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1) : p0(gmock_p0), \
          p1(gmock_p1) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1));\
    }\
    p0##_type p0;\
    p1##_type p1;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP2);\
  };\
  template <typename p0##_type, typename p1##_type>\
  inline name##ActionP2<p0##_type, p1##_type> name(p0##_type p0, \
      p1##_type p1) {\
    return name##ActionP2<p0##_type, p1##_type>(p0, p1);\
  }\
  template <typename p0##_type, typename p1##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP2<p0##_type, p1##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P3(name, p0, p1, p2)\
  template <typename p0##_type, typename p1##_type, typename p2##_type>\
  class name##ActionP3 {\
   public:\
    name##ActionP3(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, \
          p2##_type gmock_p2) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP3);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type>\
  inline name##ActionP3<p0##_type, p1##_type, p2##_type> name(p0##_type p0, \
      p1##_type p1, p2##_type p2) {\
    return name##ActionP3<p0##_type, p1##_type, p2##_type>(p0, p1, p2);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP3<p0##_type, p1##_type, \
          p2##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P4(name, p0, p1, p2, p3)\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type>\
  class name##ActionP4 {\
   public:\
    name##ActionP4(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2, p3##_type gmock_p3) : p0(gmock_p0), p1(gmock_p1), \
        p2(gmock_p2), p3(gmock_p3) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
          p3##_type gmock_p3) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
          p3(gmock_p3) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
      p3##_type p3;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2, p3));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
    p3##_type p3;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP4);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type>\
  inline name##ActionP4<p0##_type, p1##_type, p2##_type, \
      p3##_type> name(p0##_type p0, p1##_type p1, p2##_type p2, \
      p3##_type p3) {\
    return name##ActionP4<p0##_type, p1##_type, p2##_type, p3##_type>(p0, p1, \
        p2, p3);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP4<p0##_type, p1##_type, p2##_type, \
          p3##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P5(name, p0, p1, p2, p3, p4)\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type>\
  class name##ActionP5 {\
   public:\
    name##ActionP5(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2, p3##_type gmock_p3, \
        p4##_type gmock_p4) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
          p3##_type gmock_p3, p4##_type gmock_p4) : p0(gmock_p0), \
          p1(gmock_p1), p2(gmock_p2), p3(gmock_p3), p4(gmock_p4) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
      p3##_type p3;\
      p4##_type p4;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2, p3, p4));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
    p3##_type p3;\
    p4##_type p4;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP5);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type>\
  inline name##ActionP5<p0##_type, p1##_type, p2##_type, p3##_type, \
      p4##_type> name(p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, \
      p4##_type p4) {\
    return name##ActionP5<p0##_type, p1##_type, p2##_type, p3##_type, \
        p4##_type>(p0, p1, p2, p3, p4);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP5<p0##_type, p1##_type, p2##_type, p3##_type, \
          p4##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P6(name, p0, p1, p2, p3, p4, p5)\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type>\
  class name##ActionP6 {\
   public:\
    name##ActionP6(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2, p3##_type gmock_p3, p4##_type gmock_p4, \
        p5##_type gmock_p5) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4), p5(gmock_p5) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
          p3##_type gmock_p3, p4##_type gmock_p4, \
          p5##_type gmock_p5) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
          p3(gmock_p3), p4(gmock_p4), p5(gmock_p5) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
      p3##_type p3;\
      p4##_type p4;\
      p5##_type p5;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2, p3, p4, p5));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
    p3##_type p3;\
    p4##_type p4;\
    p5##_type p5;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP6);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type>\
  inline name##ActionP6<p0##_type, p1##_type, p2##_type, p3##_type, \
      p4##_type, p5##_type> name(p0##_type p0, p1##_type p1, p2##_type p2, \
      p3##_type p3, p4##_type p4, p5##_type p5) {\
    return name##ActionP6<p0##_type, p1##_type, p2##_type, p3##_type, \
        p4##_type, p5##_type>(p0, p1, p2, p3, p4, p5);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP6<p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
          p5##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P7(name, p0, p1, p2, p3, p4, p5, p6)\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type>\
  class name##ActionP7 {\
   public:\
    name##ActionP7(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2, p3##_type gmock_p3, p4##_type gmock_p4, \
        p5##_type gmock_p5, p6##_type gmock_p6) : p0(gmock_p0), p1(gmock_p1), \
        p2(gmock_p2), p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), \
        p6(gmock_p6) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
          p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
          p6##_type gmock_p6) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
          p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
      p3##_type p3;\
      p4##_type p4;\
      p5##_type p5;\
      p6##_type p6;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2, p3, p4, p5, \
          p6));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
    p3##_type p3;\
    p4##_type p4;\
    p5##_type p5;\
    p6##_type p6;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP7);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type>\
  inline name##ActionP7<p0##_type, p1##_type, p2##_type, p3##_type, \
      p4##_type, p5##_type, p6##_type> name(p0##_type p0, p1##_type p1, \
      p2##_type p2, p3##_type p3, p4##_type p4, p5##_type p5, \
      p6##_type p6) {\
    return name##ActionP7<p0##_type, p1##_type, p2##_type, p3##_type, \
        p4##_type, p5##_type, p6##_type>(p0, p1, p2, p3, p4, p5, p6);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP7<p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
          p5##_type, p6##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P8(name, p0, p1, p2, p3, p4, p5, p6, p7)\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type>\
  class name##ActionP8 {\
   public:\
    name##ActionP8(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2, p3##_type gmock_p3, p4##_type gmock_p4, \
        p5##_type gmock_p5, p6##_type gmock_p6, \
        p7##_type gmock_p7) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), \
        p7(gmock_p7) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
          p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
          p6##_type gmock_p6, p7##_type gmock_p7) : p0(gmock_p0), \
          p1(gmock_p1), p2(gmock_p2), p3(gmock_p3), p4(gmock_p4), \
          p5(gmock_p5), p6(gmock_p6), p7(gmock_p7) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
      p3##_type p3;\
      p4##_type p4;\
      p5##_type p5;\
      p6##_type p6;\
      p7##_type p7;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2, p3, p4, p5, \
          p6, p7));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
    p3##_type p3;\
    p4##_type p4;\
    p5##_type p5;\
    p6##_type p6;\
    p7##_type p7;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP8);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type>\
  inline name##ActionP8<p0##_type, p1##_type, p2##_type, p3##_type, \
      p4##_type, p5##_type, p6##_type, p7##_type> name(p0##_type p0, \
      p1##_type p1, p2##_type p2, p3##_type p3, p4##_type p4, p5##_type p5, \
      p6##_type p6, p7##_type p7) {\
    return name##ActionP8<p0##_type, p1##_type, p2##_type, p3##_type, \
        p4##_type, p5##_type, p6##_type, p7##_type>(p0, p1, p2, p3, p4, p5, \
        p6, p7);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP8<p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
          p5##_type, p6##_type, \
          p7##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P9(name, p0, p1, p2, p3, p4, p5, p6, p7, p8)\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type, typename p8##_type>\
  class name##ActionP9 {\
   public:\
    name##ActionP9(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2, p3##_type gmock_p3, p4##_type gmock_p4, \
        p5##_type gmock_p5, p6##_type gmock_p6, p7##_type gmock_p7, \
        p8##_type gmock_p8) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
        p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), p7(gmock_p7), \
        p8(gmock_p8) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
          p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
          p6##_type gmock_p6, p7##_type gmock_p7, \
          p8##_type gmock_p8) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
          p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), \
          p7(gmock_p7), p8(gmock_p8) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
      p3##_type p3;\
      p4##_type p4;\
      p5##_type p5;\
      p6##_type p6;\
      p7##_type p7;\
      p8##_type p8;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2, p3, p4, p5, \
          p6, p7, p8));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
    p3##_type p3;\
    p4##_type p4;\
    p5##_type p5;\
    p6##_type p6;\
    p7##_type p7;\
    p8##_type p8;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP9);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type, typename p8##_type>\
  inline name##ActionP9<p0##_type, p1##_type, p2##_type, p3##_type, \
      p4##_type, p5##_type, p6##_type, p7##_type, \
      p8##_type> name(p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, \
      p4##_type p4, p5##_type p5, p6##_type p6, p7##_type p7, \
      p8##_type p8) {\
    return name##ActionP9<p0##_type, p1##_type, p2##_type, p3##_type, \
        p4##_type, p5##_type, p6##_type, p7##_type, p8##_type>(p0, p1, p2, \
        p3, p4, p5, p6, p7, p8);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type, typename p8##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP9<p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
          p5##_type, p6##_type, p7##_type, \
          p8##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

#define ACTION_P10(name, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type, typename p8##_type, \
      typename p9##_type>\
  class name##ActionP10 {\
   public:\
    name##ActionP10(p0##_type gmock_p0, p1##_type gmock_p1, \
        p2##_type gmock_p2, p3##_type gmock_p3, p4##_type gmock_p4, \
        p5##_type gmock_p5, p6##_type gmock_p6, p7##_type gmock_p7, \
        p8##_type gmock_p8, p9##_type gmock_p9) : p0(gmock_p0), p1(gmock_p1), \
        p2(gmock_p2), p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), \
        p7(gmock_p7), p8(gmock_p8), p9(gmock_p9) {}\
    template <typename F>\
    class gmock_Impl : public ::testing::ActionInterface<F> {\
     public:\
      typedef F function_type;\
      typedef typename ::testing::internal::Function<F>::Result return_type;\
      typedef typename ::testing::internal::Function<F>::ArgumentTuple\
          args_type;\
      gmock_Impl(p0##_type gmock_p0, p1##_type gmock_p1, p2##_type gmock_p2, \
          p3##_type gmock_p3, p4##_type gmock_p4, p5##_type gmock_p5, \
          p6##_type gmock_p6, p7##_type gmock_p7, p8##_type gmock_p8, \
          p9##_type gmock_p9) : p0(gmock_p0), p1(gmock_p1), p2(gmock_p2), \
          p3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), \
          p7(gmock_p7), p8(gmock_p8), p9(gmock_p9) {}\
      virtual return_type Perform(const args_type& args) {\
        return ::testing::internal::ActionHelper<return_type, gmock_Impl>::\
            Perform(this, args);\
      }\
      template <typename arg0_type, typename arg1_type, typename arg2_type, \
          typename arg3_type, typename arg4_type, typename arg5_type, \
          typename arg6_type, typename arg7_type, typename arg8_type, \
          typename arg9_type>\
      return_type gmock_PerformImpl(const args_type& args, arg0_type arg0, \
          arg1_type arg1, arg2_type arg2, arg3_type arg3, arg4_type arg4, \
          arg5_type arg5, arg6_type arg6, arg7_type arg7, arg8_type arg8, \
          arg9_type arg9) const;\
      p0##_type p0;\
      p1##_type p1;\
      p2##_type p2;\
      p3##_type p3;\
      p4##_type p4;\
      p5##_type p5;\
      p6##_type p6;\
      p7##_type p7;\
      p8##_type p8;\
      p9##_type p9;\
     private:\
      GTEST_DISALLOW_ASSIGN_(gmock_Impl);\
    };\
    template <typename F> operator ::testing::Action<F>() const {\
      return ::testing::Action<F>(new gmock_Impl<F>(p0, p1, p2, p3, p4, p5, \
          p6, p7, p8, p9));\
    }\
    p0##_type p0;\
    p1##_type p1;\
    p2##_type p2;\
    p3##_type p3;\
    p4##_type p4;\
    p5##_type p5;\
    p6##_type p6;\
    p7##_type p7;\
    p8##_type p8;\
    p9##_type p9;\
   private:\
    GTEST_DISALLOW_ASSIGN_(name##ActionP10);\
  };\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type, typename p8##_type, \
      typename p9##_type>\
  inline name##ActionP10<p0##_type, p1##_type, p2##_type, p3##_type, \
      p4##_type, p5##_type, p6##_type, p7##_type, p8##_type, \
      p9##_type> name(p0##_type p0, p1##_type p1, p2##_type p2, p3##_type p3, \
      p4##_type p4, p5##_type p5, p6##_type p6, p7##_type p7, p8##_type p8, \
      p9##_type p9) {\
    return name##ActionP10<p0##_type, p1##_type, p2##_type, p3##_type, \
        p4##_type, p5##_type, p6##_type, p7##_type, p8##_type, p9##_type>(p0, \
        p1, p2, p3, p4, p5, p6, p7, p8, p9);\
  }\
  template <typename p0##_type, typename p1##_type, typename p2##_type, \
      typename p3##_type, typename p4##_type, typename p5##_type, \
      typename p6##_type, typename p7##_type, typename p8##_type, \
      typename p9##_type>\
  template <typename F>\
  template <typename arg0_type, typename arg1_type, typename arg2_type, \
      typename arg3_type, typename arg4_type, typename arg5_type, \
      typename arg6_type, typename arg7_type, typename arg8_type, \
      typename arg9_type>\
  typename ::testing::internal::Function<F>::Result\
      name##ActionP10<p0##_type, p1##_type, p2##_type, p3##_type, p4##_type, \
          p5##_type, p6##_type, p7##_type, p8##_type, \
          p9##_type>::gmock_Impl<F>::gmock_PerformImpl(\
          GMOCK_ACTION_ARG_TYPES_AND_NAMES_UNUSED_) const

namespace testing {

// The ACTION*() macros trigger warning C4100 (unreferenced formal
// parameter) in MSVC with -W4.  Unfortunately they cannot be fixed in
// the macro definition, as the warnings are generated when the macro
// is expanded and macro expansion cannot contain #pragma.  Therefore
// we suppress them here.
#ifdef _MSC_VER
# pragma warning(push)
# pragma warning(disable:4100)
#endif

// Various overloads for InvokeArgument<N>().
//
// The InvokeArgument<N>(a1, a2, ..., a_k) action invokes the N-th
// (0-based) argument, which must be a k-ary callable, of the mock
// function, with arguments a1, a2, ..., a_k.
//
// Notes:
//
//   1. The arguments are passed by value by default.  If you need to
//   pass an argument by reference, wrap it inside ByRef().  For
//   example,
//
//     InvokeArgument<1>(5, string("Hello"), ByRef(foo))
//
//   passes 5 and string("Hello") by value, and passes foo by
//   reference.
//
//   2. If the callable takes an argument by reference but ByRef() is
//   not used, it will receive the reference to a copy of the value,
//   instead of the original value.  For example, when the 0-th
//   argument of the mock function takes a const string&, the action
//
//     InvokeArgument<0>(string("Hello"))
//
//   makes a copy of the temporary string("Hello") object and passes a
//   reference of the copy, instead of the original temporary object,
//   to the callable.  This makes it easy for a user to define an
//   InvokeArgument action from temporary values and have it performed
//   later.

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_0_VALUE_PARAMS()) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args));
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_1_VALUE_PARAMS(p0)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_2_VALUE_PARAMS(p0, p1)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_3_VALUE_PARAMS(p0, p1, p2)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_4_VALUE_PARAMS(p0, p1, p2, p3)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2, p3);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_5_VALUE_PARAMS(p0, p1, p2, p3, p4)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2, p3, p4);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, p5)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2, p3, p4, p5);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2, p3, p4, p5, p6);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, p7)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2, p3, p4, p5, p6, p7);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, p7, p8)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2, p3, p4, p5, p6, p7, p8);
}

ACTION_TEMPLATE(InvokeArgument,
                HAS_1_TEMPLATE_PARAMS(int, k),
                AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)) {
  return internal::CallableHelper<return_type>::Call(
      ::std::tr1::get<k>(args), p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
}

// Various overloads for ReturnNew<T>().
//
// The ReturnNew<T>(a1, a2, ..., a_k) action returns a pointer to a new
// instance of type T, constructed on the heap with constructor arguments
// a1, a2, ..., and a_k. The caller assumes ownership of the returned value.
ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_0_VALUE_PARAMS()) {
  return new T();
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_1_VALUE_PARAMS(p0)) {
  return new T(p0);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_2_VALUE_PARAMS(p0, p1)) {
  return new T(p0, p1);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_3_VALUE_PARAMS(p0, p1, p2)) {
  return new T(p0, p1, p2);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_4_VALUE_PARAMS(p0, p1, p2, p3)) {
  return new T(p0, p1, p2, p3);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_5_VALUE_PARAMS(p0, p1, p2, p3, p4)) {
  return new T(p0, p1, p2, p3, p4);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_6_VALUE_PARAMS(p0, p1, p2, p3, p4, p5)) {
  return new T(p0, p1, p2, p3, p4, p5);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_7_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6)) {
  return new T(p0, p1, p2, p3, p4, p5, p6);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_8_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, p7)) {
  return new T(p0, p1, p2, p3, p4, p5, p6, p7);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_9_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, p7, p8)) {
  return new T(p0, p1, p2, p3, p4, p5, p6, p7, p8);
}

ACTION_TEMPLATE(ReturnNew,
                HAS_1_TEMPLATE_PARAMS(typename, T),
                AND_10_VALUE_PARAMS(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)) {
  return new T(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
}

#ifdef _MSC_VER
# pragma warning(pop)
#endif

}  // namespace testing

#endif  // GMOCK_INCLUDE_GMOCK_GMOCK_GENERATED_ACTIONS_H_
// This file was GENERATED by command:
//     pump.py gmock-generated-function-mockers.h.pump
// DO NOT EDIT BY HAND!!!

// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file implements function mockers of various arities.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_GENERATED_FUNCTION_MOCKERS_H_
#define GMOCK_INCLUDE_GMOCK_GMOCK_GENERATED_FUNCTION_MOCKERS_H_

// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file implements the ON_CALL() and EXPECT_CALL() macros.
//
// A user can use the ON_CALL() macro to specify the default action of
// a mock method.  The syntax is:
//
//   ON_CALL(mock_object, Method(argument-matchers))
//       .With(multi-argument-matcher)
//       .WillByDefault(action);
//
//  where the .With() clause is optional.
//
// A user can use the EXPECT_CALL() macro to specify an expectation on
// a mock method.  The syntax is:
//
//   EXPECT_CALL(mock_object, Method(argument-matchers))
//       .With(multi-argument-matchers)
//       .Times(cardinality)
//       .InSequence(sequences)
//       .After(expectations)
//       .WillOnce(action)
//       .WillRepeatedly(action)
//       .RetiresOnSaturation();
//
// where all clauses are optional, and .InSequence()/.After()/
// .WillOnce() can appear any number of times.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_SPEC_BUILDERS_H_
#define GMOCK_INCLUDE_GMOCK_GMOCK_SPEC_BUILDERS_H_

#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#if GTEST_HAS_EXCEPTIONS
# include <stdexcept>  // NOLINT
#endif

// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyong Wan)

// Google Mock - a framework for writing C++ mock classes.
//
// This file implements some commonly used argument matchers.  More
// matchers can be defined by the user implementing the
// MatcherInterface<T> interface if necessary.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_MATCHERS_H_
#define GMOCK_INCLUDE_GMOCK_GMOCK_MATCHERS_H_

#include <math.h>
#include <algorithm>
#include <iterator>
#include <limits>
#include <ostream>  // NOLINT
#include <sstream>
#include <string>
#include <utility>
#include <vector>


#if GTEST_LANG_CXX11
#include <initializer_list>  // NOLINT -- must be after gtest.h
#endif

namespace testing {

// To implement a matcher Foo for type T, define:
//   1. a class FooMatcherImpl that implements the
//      MatcherInterface<T> interface, and
//   2. a factory function that creates a Matcher<T> object from a
//      FooMatcherImpl*.
//
// The two-level delegation design makes it possible to allow a user
// to write "v" instead of "Eq(v)" where a Matcher is expected, which
// is impossible if we pass matchers by pointers.  It also eases
// ownership management as Matcher objects can now be copied like
// plain values.

// MatchResultListener is an abstract class.  Its << operator can be
// used by a matcher to explain why a value matches or doesn't match.
//
// TODO(wan@google.com): add method
//   bool InterestedInWhy(bool result) const;
// to indicate whether the listener is interested in why the match
// result is 'result'.
class MatchResultListener {
 public:
  // Creates a listener object with the given underlying ostream.  The
  // listener does not own the ostream, and does not dereference it
  // in the constructor or destructor.
  explicit MatchResultListener(::std::ostream* os) : stream_(os) {}
  virtual ~MatchResultListener() = 0;  // Makes this class abstract.

  // Streams x to the underlying ostream; does nothing if the ostream
  // is NULL.
  template <typename T>
  MatchResultListener& operator<<(const T& x) {
    if (stream_ != NULL)
      *stream_ << x;
    return *this;
  }

  // Returns the underlying ostream.
  ::std::ostream* stream() { return stream_; }

  // Returns true iff the listener is interested in an explanation of
  // the match result.  A matcher's MatchAndExplain() method can use
  // this information to avoid generating the explanation when no one
  // intends to hear it.
  bool IsInterested() const { return stream_ != NULL; }

 private:
  ::std::ostream* const stream_;

  GTEST_DISALLOW_COPY_AND_ASSIGN_(MatchResultListener);
};

inline MatchResultListener::~MatchResultListener() {
}

// An instance of a subclass of this knows how to describe itself as a
// matcher.
class MatcherDescriberInterface {
 public:
  virtual ~MatcherDescriberInterface() {}

  // Describes this matcher to an ostream.  The function should print
  // a verb phrase that describes the property a value matching this
  // matcher should have.  The subject of the verb phrase is the value
  // being matched.  For example, the DescribeTo() method of the Gt(7)
  // matcher prints "is greater than 7".
  virtual void DescribeTo(::std::ostream* os) const = 0;

  // Describes the negation of this matcher to an ostream.  For
  // example, if the description of this matcher is "is greater than
  // 7", the negated description could be "is not greater than 7".
  // You are not required to override this when implementing
  // MatcherInterface, but it is highly advised so that your matcher
  // can produce good error messages.
  virtual void DescribeNegationTo(::std::ostream* os) const {
    *os << "not (";
    DescribeTo(os);
    *os << ")";
  }
};

// The implementation of a matcher.
template <typename T>
class MatcherInterface : public MatcherDescriberInterface {
 public:
  // Returns true iff the matcher matches x; also explains the match
  // result to 'listener' if necessary (see the next paragraph), in
  // the form of a non-restrictive relative clause ("which ...",
  // "whose ...", etc) that describes x.  For example, the
  // MatchAndExplain() method of the Pointee(...) matcher should
  // generate an explanation like "which points to ...".
  //
  // Implementations of MatchAndExplain() should add an explanation of
  // the match result *if and only if* they can provide additional
  // information that's not already present (or not obvious) in the
  // print-out of x and the matcher's description.  Whether the match
  // succeeds is not a factor in deciding whether an explanation is
  // needed, as sometimes the caller needs to print a failure message
  // when the match succeeds (e.g. when the matcher is used inside
  // Not()).
  //
  // For example, a "has at least 10 elements" matcher should explain
  // what the actual element count is, regardless of the match result,
  // as it is useful information to the reader; on the other hand, an
  // "is empty" matcher probably only needs to explain what the actual
  // size is when the match fails, as it's redundant to say that the
  // size is 0 when the value is already known to be empty.
  //
  // You should override this method when defining a new matcher.
  //
  // It's the responsibility of the caller (Google Mock) to guarantee
  // that 'listener' is not NULL.  This helps to simplify a matcher's
  // implementation when it doesn't care about the performance, as it
  // can talk to 'listener' without checking its validity first.
  // However, in order to implement dummy listeners efficiently,
  // listener->stream() may be NULL.
  virtual bool MatchAndExplain(T x, MatchResultListener* listener) const = 0;

  // Inherits these methods from MatcherDescriberInterface:
  //   virtual void DescribeTo(::std::ostream* os) const = 0;
  //   virtual void DescribeNegationTo(::std::ostream* os) const;
};

// A match result listener that stores the explanation in a string.
class StringMatchResultListener : public MatchResultListener {
 public:
  StringMatchResultListener() : MatchResultListener(&ss_) {}

  // Returns the explanation accumulated so far.
  internal::string str() const { return ss_.str(); }

  // Clears the explanation accumulated so far.
  void Clear() { ss_.str(""); }

 private:
  ::std::stringstream ss_;

  GTEST_DISALLOW_COPY_AND_ASSIGN_(StringMatchResultListener);
};

namespace internal {

// A match result listener that ignores the explanation.
class DummyMatchResultListener : public MatchResultListener {
 public:
  DummyMatchResultListener() : MatchResultListener(NULL) {}

 private:
  GTEST_DISALLOW_COPY_AND_ASSIGN_(DummyMatchResultListener);
};

// A match result listener that forwards the explanation to a given
// ostream.  The difference between this and MatchResultListener is
// that the former is concrete.
class StreamMatchResultListener : public MatchResultListener {
 public:
  explicit StreamMatchResultListener(::std::ostream* os)
      : MatchResultListener(os) {}

 private:
  GTEST_DISALLOW_COPY_AND_ASSIGN_(StreamMatchResultListener);
};

// An internal class for implementing Matcher<T>, which will derive
// from it.  We put functionalities common to all Matcher<T>
// specializations here to avoid code duplication.
template <typename T>
class MatcherBase {
 public:
  // Returns true iff the matcher matches x; also explains the match
  // result to 'listener'.
  bool MatchAndExplain(T x, MatchResultListener* listener) const {
    return impl_->MatchAndExplain(x, listener);
  }

  // Returns true iff this matcher matches x.
  bool Matches(T x) const {
    DummyMatchResultListener dummy;
    return MatchAndExplain(x, &dummy);
  }

  // Describes this matcher to an ostream.
  void DescribeTo(::std::ostream* os) const { impl_->DescribeTo(os); }

  // Describes the negation of this matcher to an ostream.
  void DescribeNegationTo(::std::ostream* os) const {
    impl_->DescribeNegationTo(os);
  }

  // Explains why x matches, or doesn't match, the matcher.
  void ExplainMatchResultTo(T x, ::std::ostream* os) const {
    StreamMatchResultListener listener(os);
    MatchAndExplain(x, &listener);
  }

  // Returns the describer for this matcher object; retains ownership
  // of the describer, which is only guaranteed to be alive when
  // this matcher object is alive.
  const MatcherDescriberInterface* GetDescriber() const {
    return impl_.get();
  }

 protected:
  MatcherBase() {}

  // Constructs a matcher from its implementation.
  explicit MatcherBase(const MatcherInterface<T>* impl)
      : impl_(impl) {}

  virtual ~MatcherBase() {}

 private:
  // shared_ptr (util/gtl/shared_ptr.h) and linked_ptr have similar
  // interfaces.  The former dynamically allocates a chunk of memory
  // to hold the reference count, while the latter tracks all
  // references using a circular linked list without allocating
  // memory.  It has been ob2c SHtio::s(pl_.get();
  }

 pro2T-Ed linked_ptr have sc scamerio  Thwever, inared_ptr (un tat a-}

 pro // listget();
  en the v abo mesy nury.user of the mapy ofnstructor o // that nhe default acnstructor o  //
  // It'ferformance, T-Emmo a chobabmen,e supuld ove thifsing a // shared_ptr (ulps t  ::ststing::internal::Fustget();
 <nst MatcherInterface<T>*  >mpl_(i};

// // namespace teternal::// A matcher<T> obia copy ole tad liIMMUTLE FO(cept> y a msgn mntat//   ject isat cre nheckinhether an alue is type T, atches,  The
   implementation wh MatchAn<T> obia jt beaistget();
   honst

n MatcherInterface<T> i,o fapy og itssailsr alcap w ThDot maierits / from ittcherIn!emplate <typename T>
class MatcherBa public Maternal::FutcherBase()> ob public:
  // Crestructs a manu Matcher.
   Nded, or thoresg Matcher<Tbjects ca a STL // cantain #s.  ItAefault a-nstructed ontcher is ust NUyemaieializer_  FoYou // can tt used,t dot, iln alueivalue.
as been obmsgn m to be.
  botcher<T {}

  // Constructs a matcher from its implementation.
  explicit MatcherBaonst MatcherInterface<T>* impl)
      : impernal::FutcherBase()> ompl) {}

  vi Implemit Manstructor orre all cs hopeop to alite " // ExpECT_CALL(mofoo, B() ) {
stead of "EpECT_CALL(mofoo, B() Eq ) {)ometimes t botcher<T Talue.
);// NOLINT
#i

// The imllowing ditwopecializations helow a e user im write "vruc/ in tead of "Epqtreaand li"foo"n tead of "Epqt"foo") en thstring.
/ matcher.
s expected, template <tyclass MaEST_DIAPI_atchAn<T>nst Maternal::string s&>
  : imblic Maternal::FutcherBase()>nst Maternal::string s&>b public:
  //tcher<T {}

  //plicit MatcherBaonst MatcherInterface<T>nst Maternal::string s&>impl)
      : impernal::FutcherBase()>nst Maternal::string s&>mpl) {}

  vi ImA cs hoe user im write "vrucn tead of "Epqtreaanmetimes t,here a // shatis an tring.
bjects   botcher<T nst Maternal::string s& s);// NOLINT
#i vi ImA cs hoe user im write "v"foo"n tead of "Epqt"foo") metimes t  botcher<T nst Macred* s);// NOLINT
#i

//mplate <tyclass MaEST_DIAPI_atchAn<T>ternal::string s>
  : imblic Maternal::FutcherBase()>ternal::string s>b public:
  //tcher<T {}

  //plicit MatcherBaonst MatcherInterface<T>ternal::string s>impl)
      : impernal::FutcherBase()>ternal::string s>mpl) {}

  vi ImA cs hoe user im write "vrucn tead of "Epqtreaanmetimes t,here a // shatis an tring.
bjects   botcher<T nst Maternal::string s& s);// NOLINT
#i vi ImA cs hoe user im write "v"foo"n tead of "Epqt"foo") metimes t  botcher<T nst Macred* s);// NOLINT
#i

//f GTEST_HAS_EXRICTNG_PIECE_/ The imllowing ditwopecializations helow a e user im write "vruc/ in tead of "Epqtreaand li"foo"n tead of "Epqt"foo") en thstringMaPiece/ matcher.
s expected, template <tyclass MaEST_DIAPI_atchAn<T>nst MaringMaPiece&>
  : imblic Maternal::FutcherBase()>nst MaringMaPiece&>b public:
  //tcher<T {}

  //plicit MatcherBaonst MatcherInterface<T>nst MaringMaPiece&>impl)
      : impernal::FutcherBase()>nst MaringMaPiece&>mpl) {}

  vi ImA cs hoe user im write "vrucn tead of "Epqtreaanmetimes t,here a // shatis an tring.
bjects   botcher<T nst Maternal::string s& s);// NOLINT
#i vi ImA cs hoe user im write "v"foo"n tead of "Epqt"foo") metimes t  botcher<T nst Macred* s);// NOLINT
#i vi ImA cs hoe user im wrps StringMaPieces dirts ly  botcher<T ringMaPiece s);// NOLINT
#i

//mplate <tyclass MaEST_DIAPI_atchAn<T>ringMaPiece>
  : imblic Maternal::FutcherBase()>ringMaPiece>b public:
  //tcher<T {}

  //plicit MatcherBaonst MatcherInterface<T>ringMaPiece>impl)
      : impernal::FutcherBase()>ringMaPiece>mpl) {}

  vi ImA cs hoe user im write "vrucn tead of "Epqtreaanmetimes t,here a // shatis an tring.
bjects   botcher<T nst Maternal::string s& s);// NOLINT
#i vi ImA cs hoe user im write "v"foo"n tead of "Epqt"foo") metimes t  botcher<T nst Macred* s);// NOLINT
#i vi ImA cs hoe user im wrps StringMaPieces dirts ly  botcher<T ringMaPiece s);// NOLINT
#i

/ndif  // GMOST_HAS_EXRICTNG_PIECE_// The imPolyry.phictcher<Tbass Mamplate <tkes it easy fo implement du// mapolyry.phicatcher.
s(i.e. matcher to t cre nhtch relues an meme
// maat nhone pe, \
g. whpqtnand liNotNu M).
  
// TODdefine an
apolyry.phicatcher.
, user toould prinide addnmplem/ conss Mamt crs at escribeTo() method ofd a_kescribeNegationTo(::)/ met:
d oand doeine an
ameer ofnction sh( messer ofnction shmplate <//
//   maol MatchAndExplain(T nst MaVues &alue,
//   innnnnnnnnnnnnnnnnnnnnntchResultListener* listener) const {//
// whS the nefinition, n meNotNu M).or a uscolemetexample, template <tynss Mapl>::lass MaPolyry.phictcher<Tb public:
  explicit StPolyry.phictcher<T nst Mapl>:&nd _pl) {}impl_(imd _pl) {}

  // Returns th
amutle taference to a e underlying ostcher.
 // implementation whjects   bopl>:&nmutle t_pl)  { return stpl_(i}

  // Returns thastplmutle taference to a e underlying ostcher.
 // implementation whjects   bonst Mapl>:&npl)  { nst { return sspl_(i}

  //mplate <typename T>
  Maerator catchAn<T> o const {
    return imtchAn<T> o w maMonory.phicpl<F> ompl) _)
  }

 protate:
  //mplate <typename T>
  Maass Matonory.phicpl<F public MatcherDeterface<T>*      rblic:
  ex//plicit Matonory.phicpl<F(nst Mapl>:&npl) ) impl_(impl) {}

  vivirtual void DescribeTo(::std::ostream* os) const = {     : pl_.gescribeTo(os);
    *o
  vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: pl_.gescribeTogationTo(os);
  }
*o
  vivirtual vool MatchAndExplain(T x, MatchResultListener* listener) const {
    rereturn impl_.getchAndExplain(x, listener);
  }
*o
  vivotate:
  //bonst Mapl>:mpl_(i}; //boEST_DISALLOW_ASSIGN_(natonory.phicpl<F
  }

}; //pl>:mpl_(i}; //EST_DISALLOW_ASSIGN_(naPolyry.phictcher<T
};

// Aneates a litcher from its implementation.
 This he expasi im wre
   that nhe detchAn<T> obnstructor argst doesn't caquired ou ne
//   plicit Mlyrite "vt temporte <tgument, whg. w/
//   makes tcher<T o))
// tovs/   makehAn<T>nst Maring s&>mo))
//mplate <typename T>
  line MatchRe<T> obkes tcher<T nst MatcherInterface<T>* impl)
 
  return netchAn<T> o il<F
  }// Aneates a lipolyry.phicatcher.
som its implementation.
 This he e/   pasi im wre
 hat nhe dePolyry.phictcher<T<pl>::bnstructor argst d/ dissn't caquired ou ne
/ plicit Mlyrite "vt temporte <tgument, whg. w/
//   makes Polyry.phictcher<T o))
// tovs/   maPolyry.phictcher<T<TenaOfFoo>mo))
//mplate <tynss Mapl>::lline MaPolyry.phictcher<T<pl>::bkes Polyry.phictcher<T nst Mapl>:&npl) )   return nePolyry.phictcher<T<pl>:: il<F
  }// AnAnying if ide Byt te'ternal::'amespace teIINTERRUNALMPLIEENT OAON) / a m MatUSNOT
/E LIED ANINIED CONSDE!

/mespace internal {

// A T detchAn<TCastpl>:mass Mamplate <t an thper<ror implementing Mn MatcherInCast.  FoWeeed to
s helps linkerder to imparalizly/ specializatByt teplementation wh MatchAn<TCast.  (+ mol cs h/ conss M/ructoramplate <so be alparalizlypecializatBdbut itno / froction shmplate <s.).
/ This fineratelerb sn is
 sed inen thtchAn<TCast. 'srgument maisu// mapolyry.phicatcher.
s(i.e. metimng this cre nh copinrb t to bean MatcherInut it not own Mayet;or imample, a (v)"ue.
)) oan alue ismo)r/   plple, a "hlo") otemplate <typename T>
typename arMclass MatcherBaCastpl>:m public:
  exstioncatchRe<T> obCast.Mapolyry.phic_tcher.
_or_"ue.
)
    re Matre nh colipolyry.hicatcher.
,  whath isce {
wwas  to sae
  //// imptsopinrb sn iserator ca honates atchRe<T> o FoOit.
re nh colilue
  //// that 'lould prbpassed by a e untchRe<T> o'scnstructor o  ////
  //// thWcallt care Matcher<T>
/(polyry.phic_tcher.
_or_"ue.
)
en thtaisu////// thpolyry.phicatcher.
sbecse is t' Ma colmbigus ar  /Trs at impl_.it M///// thnstructor arom itt his, ae
uizlyphpearnwhen thTrs at impl_.it M///// thnstructor arom ity nupena)  ////
  //// thIt wot mark fo saennditions izlyppl_.itt_ce t///// thpolyry.phic_tcher.
_or_"ue.
o satchRe<T> obbecse is t wot maigger w///// thuser t-fined bypinrb sn isom itt  saTr  /n Maextens (sumesg Mats
  //// a verue.
).   return imCastpl>:      :: hpolyry.phic_tcher.
_or_"ue.
          Bl Meannstru  t<         im: pernal::stplemit MlyCinrb tle i<M,atchRe<T> ob>::"ue.
o c
  }

 protate:
  //stioncatchRe<T> obCastpl>: Malue, anBl Meannstru  t<false>)
    re Matre n'be afilemit Mlyopinrb t to betchRe<T> o,o fats
 n'belipolyry.phic   re Matcher.
   It st be a k-"ue.
o n t Unfse dirts aieializerion to a nates  //// a vetcher.
  voreturn netchAn<T> o plemit MCast_> o "ue.
))  }

  //stioncatchRe<T> obCastpl>: Mapolyry.phic_tcher.
_or_"ue.
                               Bl Meannstru  t<ue i>)
    re Matr imposmit Mlyopinrb tle to altchRe<T> o,oich museanMamt crther t   re Matr imlipolyry.hpicatcher.
s catchAn<T> ors at impl_.it Mfnstructor o //re Maom itt   Inh otisce {using a t teplemit Mfnstrb sn isll deoduce goa   re Matcher.
  ////
  //// thEn un  /Trs at impl_.it Mhnstructor arom itt,s t wot mabcaller dbbecse i///// thnatesg Matcher<T>,  wod prquired ochunn wh typwoser t-fined bypinrb sn i  //// a (rst.
a honates aTsom itt d the mna honates atchRe<T> osom itT).   return impolyry.phic_tcher.
_or_"ue.
  }
};

// The  maty.usecializatBderb sn is
 sed inen thtchAn<TCast. 'srgument m/ is imready knMatcher i This hely gucoleilewhen thee T, an be
// usstioncizlyppinrb t to beee T,Utemplate <typename T>
typename arUclass MatcherBaCastpl>:<T,atchRe<T>U  >m public:
  exstioncatchRe<T> obCast.nst MatcherIn>U &ource c_tcher.
)
    return imtchAn<T> o w mapl>: urce c_tcher.
)
  }

 protate:
  //nss Mapl>: public MatcherDeterface<T>*      rblic:
  ex//plicit Mapl<F(nst MatcherIn>U &ource c_tcher.
)         :ource c_tcher.
_ urce c_tcher.
)}

  vivi thWcalegatioehe matcherg Malog Ma a e unurce cotcher.
  ////rtual vool MatchAndExplain(T x, MatchResultListener* listener) const {
    rereturn imurce c_tcher.
_etchAndExplain(x,stionc_ce t>U (x)listener);
  }
*o
  vivirtual void DescribeTo(::std::ostream* os) const = {     : urce c_tcher.
_escribeTo(os);
    *o
  vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: urce c_tcher.
_escribeTogationTo(os);
  }
*o
  vivotate:
  //bonst MatchRe<T>U  urce c_tcher.
_}; //boEST_DISALLOW_ASSIGN_(napl<F
  }

};

// The  maen unty.usecializatBderb sn is
 sed inr imaiciently,
sce ng Mn Mamatcher to exptson to enatemplate <typename T>
class MatcherBaCastpl>:<T,atchRe<T>T  >m public:
  exstioncatchRe<T> obCast.nst MatcherIn>T &otcher.
)}
eturn imtcher.
;
};

// // namespace teternal::// A Ierder to imbcasaftad licar(),sce ng Metween thfferencematchers.
tr havehe exdn Maexsmit MlyoviaatcherBaCast> o m),oich mukes a c/ matcher.
smad liturns a potchRe<T> o FoItucoleilewhly guen thTrn be
// usstioncizlyppinrb t to beeh<tgument, eee T, memtemplate <typename T>
typename arMclline MatchRe<T> obkehAn<TCast.M tcher.
)
    turn internal::CatcherBaCastpl>:<T,at:Callst.tcher.
)  }// Anplementats SafttcherInCast.  /
//   Wuser t impernamedie <tass Mamoxdnhe actual elsaftace ng Me atNokia'h/ coSymbi nheoleileran tt uscidinbetween t
tr hplate <tyT,at:..". (M)nd
//   hplate <tyT,aU:..". (nst MatcherIn>U &)/ mer imoction shmplate <sut itn bef messer ofnction shmplate <stemplate <typename T>
class MaSafttcherInCastpl>:m public:
  ex The  maerloads and, lewhpolyry.phicatcher.
and Malues an y gung ca // shmonory.phicatcher.
andreand, leby the usxt pan M  template <typename T>M> exstioncaline MatchRe<T> obCast.Mapolyry.phic_tcher.
_or_"ue.
)
    return internal::CatcherBaCastpl>:<T,at:Callst.polyry.phic_tcher.
_or_"ue.
)  }

  // Ree  maerloads and, lewhmonory.phicatcher.
a  //
  // It'nineratelif thee T, an be
/filemit Mlyopinrb t to beee T,U,e suc
  // "isaftlyopinrb t potchRe<T>U:. a gitchRe<T> ob(i.e. tcherInu
  // nentribariou  t): jt bekeep copy of the teiginal tetchRe<T>U:,opinrb t e
  // sigument, eom teme T, a a U, d the mnaps Stito a e underlying ostchRe<T>U:. // Ree en y gucept> n is
 sen thUr imliference tod thTt not oas ite
  // siderlying ostchRe<T>U:ay be NUterested in aneh<tgument, 'srgddsteswhich
//// impnot owpserved.
n the constrb sn isom it a a U  template <typename T>U> exstioncaline MatchRe<T> obCast.nst MatcherIn>U &otcher.
)
    re thEormacthat de an be
/filemit Mlyopinrb t to beU. //boEST_DICOMPILESSIGERT_((pernal::stplemit MlyCinrb tle i<T,aU:::"ue.

                ANNNNNNNNNNNT_st b_bt_pl) it Mly_pinrb tle t_to_U
  }
*o thEormacthat dewere not repinrb tl a new-restrence to e T, a a liference t //// thae T,Ute//boEST_DICOMPILESSIGERT_(         pernal::stis_ference t> o::"ue.
 || !pernal::stis_ference t>U:::"ue.
          n tt u_pinrb t_w-r_ferencet c_gum_to_ference t
  }
*o th'nice {
 otisTod thUre noathm>
eoncahaveh, eormacthat dee
  //// nentrrb sn is
 st relossyte//bohavef GMOST_DIREMOVEIREFERCE OND_ASNSEQT_(T) RawT;e//bohavef GMOST_DIREMOVEIREFERCE OND_ASNSEQT_(U) RawU; //bonst Maol MakTIsOer an=MOCK_INKI_ASOF_(RawT) == pernal::stkOer a; //bonst Maol MakUIsOer an=MOCK_INKI_ASOF_(RawU) == pernal::stkOer a; //boEST_DICOMPILESSIGERT_(         kTIsOer an|| kUIsOer an||         (pernal::stLossss oAthm>
eoncCinrb tle i<RawT, RawU:::"ue.

          ntrrb sn i_of_athm>
eoncype>:s_st b_bt_lossss o)    return MatchAnBaCast> o mcher.
)  }
};

//mplate <typename T>
typename arMclline MatchRe<T> obSafttcherInCast.nst Mat&apolyry.phic_tcher.
)
    turn inSafttcherInCastpl>:> o::llst.polyry.phic_tcher.

  }// AnA> o coturns a potcher to t detcher sty nulue is type T, template <typename T>
cltchRe<T> obA;
  / AnAnying if ide Byt te'ternal::'amespace teIINTERRUNALMPLIEENT OAON) / a m MatUSNOT
/E LIED ANINIED CONSDE!

/mespace internal {

// A Ifhe explanation in  st repty.
,rints "iito a e untream.
  line Maid DePnts IfNotEty.
 nst Maternal::string s& planation i                              std::ostream* os) co     (stplanation in!= "" &&s) = NULL)
 
    *os << "no, "< "nplanation i  }
};
// A turns true iff  e given unpe T,me T> expasfo imady y a mahuma
//   is he exed to encidinbeether anints g a t teee T, mevalue matht
// nobeelps ful  line Maol IsInRdy le tTenaNe T(nst Maring s&eee T_me T 
     thWcaloide Ban ape T,me T>rdy le tff  's resho t  doesn't mantain # // sigemplate <t imoction shmenate  turn in(ee T_me T.leng() cl<= 20n||          eee T_me T.find_rst.
_of("<(") == ring s::np);
  }// MatchReethe value
  agns ot e given untcher.
, ints "ie value
  anexplain
 // thatmatch result *i a e unstener);.eturns the detch result *//   istener' wist bet re NULL.
  //aVues an tt usbpassed bybofnstruiference t,bbecse isme cotcher.
ankes  c/ maw-renstruigument, template <typename T>Vue, anpename T>
clol MatchAnPnts dExplain(x,Vues &alue,
/ nst MatcherIn>T &otcher.
                            tchResultListener* listener) co     (st!stener->stInterested() c)
    re thIthe listener is int usterested i,e sudnht usnd to benstructoree
  //// neinr isplanation.
cl  return Matcher.
 tchReet("ue.
)  }

  //ringMatchResultListener : inr i_stener i  }
nst Maol Match re=atcher.
 tchRedExplain(x,lue,
/ &inr i_stener i)}; //Unirb salPnts ,lue,
/ stener->stream() m)};f GTEST_HAS_EXRTTI }
nst Maring s&eee T_me Tn=MOetTenaNe T<Vue.
o c;    (stInRdy le tTenaNe T(ee T_me T )     *stener->stream() ma "no ( type T,"< "nee T_me Tn ")";
  ndif

n ePnts IfNotEty.
 inr i_stener itr(); / stener->stream() m)};
return Matcher;

// An instrnal {
lps linass for imdog condleile-mes eloopn thgemuple'h/ cofieldstemplate <tyze i_t Nclass MaTuplePferixm public:
  ex TheuplePferix<N>CatcherBs mcher.
_muple,alue,
_muplecoturns a ue i/// imp the marst.
aNofields, memcher.
_mupleetcher ste marst.
aN/// imfields, melue,
_muple,esponeive rly  bomplate <typename T>Mcher.
Tuple,epename T>Vue, Tuple> exstioncaol Matches(T nst MatcherInTuple&emcher.
_muple                        nst MaVues Tuple&elue,
_mupleco    reing a std::ostr1::get    return MaeuplePferix<N - 1>CatcherBs mcher.
_muple,alue,
_muplec         &&sget<N - 1> mcher.
_muple) tchReet(get<N - 1> lue,
_muplec)  }

  // ReeuplePferix<N>CaplainMatchReFlure msTo mcher.
s,alue,
 or s  // mascribes x.ilure mca a tcherg Mae marst.
aNofields, memcher.
  // neagns ot e girst.
aNofields, melues.

 hIthe lres int .ilure m  // lithing ifll debetream_; to oves  bomplate <typename T>Mcher.
Tuple,epename T>Vue, Tuple> exstioncaid ExplainMatchReFlure msTo nst MatcherInTuple&emcher.
s                                       nst MaVues Tuple&elue,
s                                       std::ostream* os) co    reing a std::ostr1::muple_ement c;   reing a std::ostr1::get   //// neFst.
,ascribes x.ilure mca a e girst.
aNo- 1ofieldste////euplePferix<N - 1>CaplainMatchReFlure msTo mcher.
s,alue,
 or s    //// neTn defiribes the neilure me( and yin the
  (N - 1)-tis(0-be {d) //re Maoieldte//bohaveme T>muple_ement c<N - 1,atcherInTuple>Cape T,tcher to=         get<N - 1> mcher.
o)    rehavef GMhaveme T>muple_ement c<N - 1,aVue, Tuple>Cape T,Vue.
  }
 aVues alue
  = get<N - 1> lue,
o)    reringMatchResultListener : stener i  }
   (st!tcher.
 tchRedExplain(x,lue,
/ &stener i))
    im:  neTO(wan@g):nclude <s the
  ssage
 he usxe of Goe peramewot t   re// neaused insi CK_MATETHOD*()
en thssible i.   re//s << "no xplated, igum #"< "nNo- 1o "no: 
    De  get<N - 1> mcher.
o)escribeTo(os);
    *o//s << "no\n           Aual e: 
    De   thWcareme coe reference coiunpe T,Vue.
o sapren uree
  ////// sideirb sal ints .
som itints g a t tegddstes, melues.which
//////// si
 n'beterestedg a tooe user immosof the vemes  The
  ////// simcher.
 MatchAndExplain() method cand, lewhe callswhen
  ////// sit tegddstes, interestedg.
cl//////ternal::stUnirb salPnts ,lue,
/ );
    *o//Pnts IfNotEty.
 stener itr(); / );
    *o//s << "no\n"  }
*o
 }
};

// The imbe {allswtemplate <tyclass MaeuplePferix<0>m public:
  exmplate <typename T>Mcher.
Tuple,epename T>Vue, Tuple> exstioncaol Matches(T nst MatcherInTuple&e/*emcher.
_muplee*/                        nst MaVues Tuple&e/*elue,
_muplee*/)
    return inue i  }

  //mplate <typename T>Mcher.
Tuple,epename T>Vue, Tuple> exstioncaid ExplainMatchReFlure msTo nst MatcherInTuple&e/*emcher.
se*/                                       nst MaVues Tuple&e/*elue,
se*/                                       std::ostream* os/os) e*/)
 };

// TheupletcherBs mcher.
_muple,alue,
_muplecoturns a ue imp thl
  /matchers cainemcher.
_mupleetcherhe consrsponsing whfields,it
tr lue,
_muple FoItuia copyleileraror meimemcher.
_mupleed
//   lue,
_mupleeve sifferencemamber of tifields, : inpyleatle tofield
tr havehtemplate <typename T>Mcher.
Tuple,epename T>Vue, Tuple> ol MaeupletcherBs nst MatcherInTuple&emcher.
_muple                    nst MaVues Tuple&elue,
_mupleco    ing a std::ostr1::muple_ze i  //   kes thsureo t detcher 
_mupleed
/ lue,
_mupleeve sie unue T // litber of tifieldscl//EST_DICOMPILESSIGERT_(muple_ze i<tcherInTuple>Calue
  ==                         muple_ze i<Vue, Tuple>Ca"ue.
                          tcher 
_d
/_"ue.
_ve s_fferencem_tber os_of_fields
    turn MaeuplePferix<muple_ze i<Vue, Tuple>Ca"ue.
>Ca       tcherBs mcher.
_muple,alue,
_muplec;

// AnDcribes x.ilure mca a tcherg Matcher.
andgns ot lues.

 hIthe lre
 impnot .ilure m ithing ifll debetream_; to oves  mplate <typename T>Mcher.
Tuple,epename T>Vue, Tuple> id ExplainMatchReFlure mTupleTo nst MatcherInTuple&emcher.
s                                  nst MaVues Tuple&elue,
s                                  std::ostream* os) co    ing a std::ostr1::muple_ze i  //euplePferix<muple_ze i<tcherInTuple>Calue
 >CaplainMatchReFlure msTo 
      tcher 
s,alue,
 or s   
// AnTransrmanTupleVue,
sed
/ ptsolps li  
// TODransrmanTupleVue,
sHps linhidewhe castrnal {
maerg erthat t/ AnTransrmanTupleVue,
seer of implement du/ muplerackrb saltemplate <typename T>
uple,epename T>Func,epename T>OutIrnaclass MaeransrmanTupleVue,
sHps lin{protate:
  //mavef GMhaveme T>std::ostr1::muple_ze i<Tuple>>
upleSe i  public:
  ex Thr exaa museer of timupler't',nkes nnkerder t, elue,e <su'*out++ = f(t)'. // Returns the defal telue is ty'out'nkerca the EXller needs to.
  bostioncaOutIrna Run(Func f/ nst MaTuple&e
,aOutIrna out)
    return inIratoreOvInTuple<
uple,e
upleSe i::"ue.
o c(f/ 
,aout)  }

 protate:
  //mplate <typename T>
up, ze i_t kRemaing aSe i> exstctoreIratoreOvInTuple
    reOutIrna orator c.  (Func f/ nst MaTup&e
,aOutIrna out)
nst {
    im: *out++ = f(std::ostr1::get<
upleSe i::"ue.
 - kRemaing aSe i>(t)
    *o//turn inIratoreOvInTuple<
up, kRemaing aSe i - 1> c(f/ 
,aout)  }
*o
 }
}; //mplate <typename T>
up> exstctoreIratoreOvInTuple<
up, 0>
    reOutIrna orator c.  (Func /osfe*/  nst MaTup&e/oste*/  OutIrna out)
nst {
    im: turn inout  }
*o
 }
}; 

// ThSceedibl rlynkevos th'f(ement c)'n thaa muement co the vemupler't',/ a mearnng whaa musult *i a e un'out'nkrator>
.eturns the defal telue i/   jty'out'template <typename T>
uple,epename T>Func,epename T>OutIrnaclOutIrna eransrmanTupleVue,
s(Func f/ nst MaTuple&e
,aOutIrna out)
    turn MaeransrmanTupleVue,
sHps li<
uple,eFunc,eOutIrnac::Run(f/ 
,aout)  }// Anplementats A> o ctemplate <typename T>
class MaAnytcherInpl>: public MatcherDeterface<T>*     blic:
  virtual ~Mol MatchAndExplain(T    im: Te/osxe*/  tchResultListener* li/listener) e*/)
nst { return ssue i    virtual ~Mid DescribeTo(::std::ostream* os) const { ims << "no and ying i"    virtual ~Mid DescribeTogationTo(::std::ostream* os) const {
    im   is he exmosolform scolemetendib'isaftas it's ret usvertheful i   im    write "vt())A<ol Mo c
 Thwever, e suc
 t repilemetelforulert
//  im   su muahssibleity o,ed
/ ptoesn't mahurto be alpreped_p.   *os << "noner, etcher s
  }
};

// Thplementats _, potcher to t detcher sty nulue is tyy n
tr have This he ex
apolyry.phicatcher.
, soe sund togemplate <thave
 nentrrb sn iserator ca hokes  ptopear ag Me atgitchRe<T> obr a u n
tr have, teass MaAnying itcherInu public:
  exmplate <typename T>
  Maerator catchAn<T> o const {
 eturn ssA> o c;
};

// Thplementats matcher to t creylear a liven unlue isth th// mapre-suppld lilue ising a n Ma the ve==, <=, <etc) ,aerator c  The
   impwoslue,
seing maeylear doest mahe sieoeve sie unue Thmenate
// The twtcher tofined by lres inpolyry.phica(r imample, a (v)5)an be
// used by hokeherh imper, posho t, podoliceetc) t The
 fery.uswere
   thgemplate <thaveentrrb sn iserator ca the
  plementation.
  
//   Wuseine anis ands matccronkerder to imemitsne <tplicatio so fce c
 nentdate
// The twllowing ditplate <tfinition, nsumeseshat the foRhseramewot te e/   a "bar "thavee(i.e. nther th'nst MaT'or th'T&'cteefine GMOCK_INCLIEENT OICOMPISINONATCHERS__( \   *ome T,aer,elativeon,egated d_lativeon) \   mplate <typename T>Rhs>nass fome T##tcherInu  \   *blic:
  \   *oplicit Mame T##tcherIn nst MaRhs& rh : strh _(rh : {} \   *omplate <typename T>Lhs>n\   *oerator catchAn<T>Lhs> const {
 e\   im: turn inkes tcher<T w mapl>:>Lhs> rh _)
 e\   im} \   *otate:
  \   *omplate <typename T>Lhs>n\   *onss Mapl>: public MatcherDeterface<T>Lhs>n e\   im:blic:
  \   *o//plicit Mapl<F(nst MaRhs& rh : strh _(rh : {} \   *ovirtual ~Mol MatchAndExplain(T \   *oviiiiiLhs lhs  tchResultListener* li/listener) e*/)
nst { re\   *oviiiturn inlhsoertrh _;e\   *ovi} \   *ovirtual ~Mid DescribeTo(::std::ostream* os) const { im\   *oviiis << "nlativeon  " ";m\   *oviiiUnirb salPnts ,rh _or s  e\   *ovi} \   *ovirtual ~Mid DescribeTogationTo(::std::ostream* os) const {
 m\   *oviiis << "ngated d_lativeon  " ";m\   *oviiiUnirb salPnts ,rh _or s  e\   *ovi} \   *ovotate:
  \   *o oRhserh _;e\   *oviEST_DISALLOW_ASSIGN_(napl<F
 e\   im} e\   imRhserh _;e\   *oEST_DISALLOW_ASSIGN_(name T##tcherIn
 e\   }// Anplementats (v)" , Ge)" , Gt)" , Le)" , Lt)" , d liNe)" / resulneive rly  OCK_INCLIEENT OICOMPISINONATCHERS__(Eq,e==, s empql ~Mto", s et mapql ~Mto")  OCK_INCLIEENT OICOMPISINONATCHERS__(GT,a>=, s em>=", s et ma>=")  OCK_INCLIEENT OICOMPISINONATCHERS__(Gt, >, s em>", s et ma>")  OCK_INCLIEENT OICOMPISINONATCHERS__(Le, <=, s em<=", s et ma<=")  OCK_INCLIEENT OICOMPISINONATCHERS__(Lt, <ets em<", s et ma<")  OCK_INCLIEENT OICOMPISINONATCHERS__(Ne, !=, s et mapql ~Mto", s empql ~Mto"    #uef GMOCK_INCLIEENT OICOMPISINONATCHERS__// Anplementats e perolyry.phicaIsNu M).otcher.
, ich muscher sty nuraw, : smart/ mapots .
sat ignNULL.
  nss MapsNu MtcherInu public:
  exmplate <typename T>intee(r  Maol MatchAndExplain(T nst Maintee(r& p                         tchResultListener* li/listener) e*/)
nst { r   return inGetRawintee(r(p) == LL; } }

  //id DescribeTo(::std::ostream* os) const { ims << "no anLL; "    vird DescribeNegationTo(::std::ostream* os) const {
    *os << "no et maLL; "  }
};

// Thplementats e perolyry.phicaNotNu M).otcher.
, ich muscher sty nuraw, : smart/ mapots .
sat ignNUt NULL.   nss MaNotNu MtcherInu public:
  exmplate <typename T>intee(r  Maol MatchAndExplain(T nst Maintee(r& p                         tchResultListener* li/listener) e*/)
nst { r   return inGetRawintee(r(p) != LL; } }

  //id DescribeTo(::std::ostream* os) const { ims << "no at maLL; "    vird DescribeNegationTo(::std::ostream* os) const {
    *os << "no eaLL; "  }
};

// ThRef(riou blecoscher sty nugument, eet ignNUliference to
//   'riou ble' This hetcher to inpolyry.phicagst doe nhtch reu n
tr sup.
sae T, met teee T, me'riou ble' e
// The twReftcherInumplate <tnss Mailementats Ref(riou blec FoItuca// osty gu NUteru  tiio soth th/ strence to e T This hepren urshuser t/ from itmtenes nlysing a Ref(x)y hokeherh ew-restrence tooction s
 sigument,  For example, the Dellowing dill derht
/eous,
sceer t 
 nentleileraror m:/
//   mat a n;/   makehAn<T>t a> m1 = Ref(n);//m   is hewot mantleile./   makehAn<T>t a&> m2 = Ref(n);//   is hewl dentleile./mplate <typename T>
class MaReftcherIn
//mplate <typename T>
class MaReftcherIn<T&>b pu/ GMOgle Mock) gnNUlineraticafmework fod the useeds to exsuppo t
// shmoing ity nuoction shmenas,nclude g a t o that dekes  w-renstru
// references igument, s The
 fery.ust temporte <tramewot teT (d
//// reSup.
sbewin)an be
/fieru  tiio so imeier an anst {
ee T, roa    maw-renstruimenate blic:
  // RetuftcherIn).okes a c T&n tead of "Enst MaT&as itwwas  to 
  // sintleilera beneherhing a Ref(nst M_"ue.
)
aa litcher fro roa    maw-renstruiferences   explicit MatuftcherIn)T&nx: stjects _(x)y{}// NOLINT
#i vimplate <typename T>Sup.
  Maerator catchAn<T>Sup.
&o const {
    re NOByassedg.
bjects _n(ee TaT&)y hopl<F(),oich mupecteda liSup.
&,   re NOw<tkes hsureo t deSup.
s an trup.
sae T, meT   Inhparallar l,   re NOis anccher sting a Ref(nst M_"ue.
)
aa litcher fro roa      maw-renstruiferences as itu nec
 t reilemit Mlyopinrb tn anst {      maference to a aaw-renstruiferences   ex: turn inkes tcher<T w mapl>:>Sup.
 (jects _)
  }

 protate:
  //mplate <typename T>Sup.
  Manss Mapl>: public MatcherDeterface<T>Sup.
&o     rblic:
  ex//plicit Mapl<F(Sup.
&nx: stjects _(x)y{}// NOLINT
#i vi//   kehAndExplain() mekes a c Sup.
&n(asoerpos to benstru Sup.
&) //re Makerder to imtcherhe coterfaces.atcherDeterface<T>Sup.
&o  ////rtual vool MatchAndExplain(T          Sup.
&nxMatchResultListener* listener) const {
    rere*stener->< "noich is oncates d @"< "nstionc_ce t>nst {
rd D*>(&x
    *o//turn in&x == &jects _  }
*o
  vivirtual void DescribeTo(::std::ostream* os) const = {     : s << "noferences use valuou ble 
    De  Unirb salPnts <T>Sup.
&o::Pnts ,jects _/ );
    *o
  vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: s << "noesn'Ut NUference to  valuou ble 
    De  Unirb salPnts <T>Sup.
&o::Pnts ,jects _/ );
    *o
  vivotate:
  //bonst MaSup.
&njects _     *oEST_DISALLOW_ASSIGN_(napl<F
  }

}; //T&njects _     EST_DISALLOW_ASSIGN_(natuftcherIn
};

// AnPolyry.phicthper<rorction sfor imnaor wod thwinbering.
btcher 
s  line Maol IsCaseInsensive rCringMaEql ~s nst Macred* lhs  nst Macred* rh : {   turn MaSing s::CaseInsensive rCringMaEql ~s lhs  rh :  }//line Maol IsCaseInsensive rCringMaEql ~s nst Mawcred_t* lhs                                           nst Mawcred_t* rh : {   turn MaSing s::CaseInsensive rWinbCringMaEql ~s lhs  rh :  }// reSing.
beylearisonor imnaor wo imwinbering.
shis cre nhve sieer dd, oLL;
 nenredact 
s  mplate <typename T>Sing.
Tena> ol MaCaseInsensive rringMaEql ~s nst MaSing.
Tena& s1                                   nst MaSing.
Tena& s2 
     thA.ust tehd oempql ~?
   (st!CaseInsensive rCringMaEql ~s s1.c_r(); / s2.c_r(); ))
    return infalse  }

  // ReSkiphe expql ~Mhd oe  bonst Mapename T>Sing.
Tena::"ue.
_pe T,mul 0;
  //nst Mare i_t i1 = s1.find(mul / i2 = s2.find(mul 
  // InA.uswer the foenof "Eeier ans1, : s2?
   (sti1 ==>Sing.
Tena::np);n|| i2 ==>Sing.
Tena::np);)
    return int1 ==>i2  }

  // ReA.ust tetls, mpql ~?
  turn imCaseInsensive rringMaEql ~s s1.subr();t1 + 1 / s2.subr();t2 + 1 :  }// reSing.
btcher 
s  / Thplementats pql ~ity-be {dering.
btcher 
sistkT>SinEq,eSinCaseNe, anexptc  mplate <typename T>Sing.
Tena> ass StreaEql ~itytcherInu public:
  exreaEql ~itytcherIn nst MaSing.
Tena& str,aol Ispected_eq                       ol Isca t_sensive r      : imring.
_treaa,spected_eq_(pected_eq),sca t_sensive r_(ca t_sensive r }

  vi ImAcpt> sapots .
saenas,nparallar lly  //   vinst Macred* //   vinred* //   vinst Mawcred_t* //   viwcred_t* //mplate <typename T>CredTena> Maol MatchAndExplain(T CredTena* s  tchResultListener* listener) const {
    re (sts == LL; )
    im: turn in!pected_eq_  }
*o
 }
return MatchAndExplain(x,Sing.
Tena(s)listener);
  }

  vi ImMcher sty nmng this cre nhpinrb t eoaSing.
Tena  //
  // Itis he ex
amplate < ithi jt beaiain(xuoction shth thnst MaSing.
Tena&  // libecse isringMaPiece s atme coterfaceng.
bw-replicit Manstructor as  bomplate <typename T>Mcher.eSing.
Tena> Maol MatchAndExplain(T nst MaMcher.eSing.
Tena& s                         tchResultListener* li/listener) e*/)
nst { r   renst MaSing.
Tena& s2(;
    *onst Maol Maeq = ca t_sensive r_ ? s2 == ring s_ :         CaseInsensive rringMaEql ~s s2, ring s_)    return Mapected_eq_ == eq} }

  //id DescribeTo(::std::ostream* os) const { i   rescribeTo(:Hps li(pected_eq_/ );
    
  //id DescribeTogationTo(::std::ostream* os) const {
    imscribeTo(:Hps li(!pected_eq_/ );
    
  /otate:
  //id DescribeTo(:Hps li(ol Ispected_eq :std::ostream* os) const {
    Sts << "n(pected_eq ? o ea" imo at ma")    res << "nopql ~Mto 
    De (st!ca t_sensive r_)
    im: s << "no(ignesg Maca t) 
    De
 }
reUnirb salPnts ,ring s_/ );
    
  //nst MaSing.
Tena ring s_  }
nst Maol Mapected_eq_  }
nst Maol Maca t_sensive r_     EST_DISALLOW_ASSIGN_(nareaEql ~itytcherIn
};

// Anplementats e perolyry.phicaHasSubr();subr()g s.otcher.
, ich m
 nen be
/fed by atgitchRe<T> obaonca Me at an be
/fcinrb t to bean Mar()g s  mplate <typename T>Sing.
Tena> ass StHasSubr()tcherInu public:
  explicit MaHasSubr()tcherIn nst MaSing.
Tena& subr()g s.     : imrubr()g s_;subr()g s.o

  vi ImAcpt> sapots .
saenas,nparallar lly  //   vinst Macred* //   vinred* //   vinst Mawcred_t* //   viwcred_t* //mplate <typename T>CredTena> Maol MatchAndExplain(T CredTena* s  tchResultListener* listener) const {
    return imu != LL;  &&stchAndExplain(x,Sing.
Tena(s)listener);
  }

  vi ImMcher sty nmng this cre nhpinrb t eoaSing.
Tena  //
  // Itis he ex
amplate < ithi jt beaiain(xuoction shth thnst MaSing.
Tena&  // libecse isringMaPiece s atme coterfaceng.
bw-replicit Manstructor as  bomplate <typename T>Mcher.eSing.
Tena> Maol MatchAndExplain(T nst MaMcher.eSing.
Tena& s                         tchResultListener* li/listener) e*/)
nst { r   renst MaSing.
Tena& s2(;
    *oturn imu2.find(rubr()g s_) != Sing.
Tena::np);  }

  vi ImDcribes x.wt the  hetcher toscher s  void DescribeNe(::std::ostream* os) const {
    *os << "nos atmubr()g s 
    DeUnirb salPnts ,rubr()g s_/ );
    
  //id DescribeTogationTo(::std::ostream* os) const {
    ims << "nos atnotmubr()g s 
    DeUnirb salPnts ,rubr()g s_/ );
    
  /otate:
  //nst MaSing.
Tena rubr()g s_     EST_DISALLOW_ASSIGN_(naHasSubr()tcherIn
};

// Anplementats e perolyry.phicaStarasWh t;subr()g s.otcher.
, ich m
 nen be
/fed by atgitchRe<T> obaonca Me at an be
/fcinrb t to bean Mar()g s  mplate <typename T>Sing.
Tena> ass StStarasWh ttcherInu public:
  explicit MaStarasWh ttcherIn nst MaSing.
Tena& pferix: stpferix_(pferix: { }

  // ReAcpt> sapots .
saenas,nparallar lly  //   vinst Macred* //   vinred* //   vinst Mawcred_t* //   viwcred_t* //mplate <typename T>CredTena> Maol MatchAndExplain(T CredTena* s  tchResultListener* listener) const {
    return imu != LL;  &&stchAndExplain(x,Sing.
Tena(s)listener);
  }

  vi ImMcher sty nmng this cre nhpinrb t eoaSing.
Tena  //
  // Itis he ex
amplate < ithi jt beaiain(xuoction shth thnst MaSing.
Tena&  // libecse isringMaPiece s atme coterfaceng.
bw-replicit Manstructor as  bomplate <typename T>Mcher.eSing.
Tena> Maol MatchAndExplain(T nst MaMcher.eSing.
Tena& s                         tchResultListener* li/listener) e*/)
nst { r   renst MaSing.
Tena& s2(;
    *oturn imu2.leng() cl>=tpferix_.leng() cl&&         s2.subr();0,tpferix_.leng() c) == pferix_} }

  //id DescribeTo(::std::ostream* os) const { i   res << "nostarashth th
    DeUnirb salPnts ,pferix_/ );
    
  //id DescribeTogationTo(::std::ostream* os) const {
    ims << "noesn't mastarahth th
    DeUnirb salPnts ,pferix_/ );
    
  /otate:
  //nst MaSing.
Tena pferix_}    EST_DISALLOW_ASSIGN_(narearasWh ttcherIn
};

// Anplementats e perolyry.phicaEndsWh t;subr()g s.otcher.
, ich m
 nen be
/fed by atgitchRe<T> obaonca Me at an be
/fcinrb t to bean Mar()g s  mplate <typename T>Sing.
Tena> ass StEndsWh ttcherInu public:
  explicit MaEndsWh ttcherIn nst MaSing.
Tena& sufrix: stsufrix_;sufrix: 

  vi ImAcpt> sapots .
saenas,nparallar lly  //   vinst Macred* //   vinred* //   vinst Mawcred_t* //   viwcred_t* //mplate <typename T>CredTena> Maol MatchAndExplain(T CredTena* s  tchResultListener* listener) const {
    return imu != LL;  &&stchAndExplain(x,Sing.
Tena(s)listener);
  }

  vi ImMcher sty nmng this cre nhpinrb t eoaSing.
Tena  //
  // Itis he ex
amplate < ithi jt beaiain(xuoction shth thnst MaSing.
Tena&  // libecse isringMaPiece s atme coterfaceng.
bw-replicit Manstructor as  bomplate <typename T>Mcher.eSing.
Tena> Maol MatchAndExplain(T nst MaMcher.eSing.
Tena& s                         tchResultListener* li/listener) e*/)
nst { r   renst MaSing.
Tena& s2(;
    *oturn imu2.leng() cl>=tsufrix_.leng() cl&&         s2.subr();u2.leng() cl-tsufrix_.leng() c) == rufrix_} }

  //id DescribeTo(::std::ostream* os) const { i   res << "noendshth th
    DeUnirb salPnts ,rufrix_/ );
    
  //id DescribeTogationTo(::std::ostream* os) const {
    ims << "noesn't maendhth th
    DeUnirb salPnts ,rufrix_/ );
    
  /otate:
  //nst MaSing.
Tena rufrix_}    EST_DISALLOW_ASSIGN_(naEndsWh ttcherIn
};

// Anplementats polyry.phicatcher.
anMcher sRegex(regex)nd
//   Ctain #sRegex(regex),hath iscebe
/fed by atgitchRe<T> obaonca Me a/ Thean be
/fcinrb t to beaar()g s  ass MatcherBsRegextcherInu public:
  extcherBsRegextcherIn(nst MaRE* regex,aol Isfull_tcher.     : imregex_(regex),hfull_tcher_(full_tcher. 

  vi ImAcpt> sapots .
saenas,nparallar lly  //   vinst Macred* //   vinred* //   vinst Mawcred_t* //   viwcred_t* //mplate <typename T>CredTena> Maol MatchAndExplain(T CredTena* s  tchResultListener* listener) const {
    return imu != LL;  &&stchAndExplain(T ternal::string s(s)listener);
  }

  vi ImMcher sty nmng this cre nhpinrb t eoaternal::string s  //
  // Itis he ex
amplate < ithi jt beaiain(xuoction shth thnst Maternal::string s&  // libecse isringMaPiece s atme coterfaceng.
bw-replicit Manstructor as  bomplate <tyass MatcherBeSing.
Tena> Maol MatchAndExplain(T nst MaMcher.eSing.
Tena& s                         tchResultListener* li/listener) e*/)
nst { r   renst Maternal::string s& s2(;
    *oturn imfull_tcher_ ?aRE::Fu Mtcher s2, *regex_) :         RE::Paraliztcher s2, *regex_)} }

  //id DescribeTo(::std::ostream* os) const { i   res << "n(full_tcher_ ?a"scher s" imoctain #s"c          "no regar lxplistesn sh
    DeUnirb salPnts <T>t anal::string so::Pnts ,regex_->patanal; / );
    
  //id DescribeTogationTo(::std::ostream* os) const {
    ims << "noesn't ma"< "n(full_tcher_ ?a"scher" imoctain #"c          "no regar lxplistesn sh
    DeUnirb salPnts <T>t anal::string so::Pnts ,regex_->patanal; / );
    
  /otate:
  //nst Mat anal::stlinked_ptT>nst MaRE>mregex_  }
nst Maol Mafull_tcher_}    EST_DISALLOW_ASSIGN_(natcherBsRegextcherIn
};

// Anplementats matcher to t creylear a t tetwoofields, mea 2-muple/ usedg a n Ma the ve==, <=, <etc) ,aerator c  The
 etwoofields,ing m
 nentlear doest mahe sieoeve sie unue Thmenate
// The twtcher tofined by lres inpolyry.phica(r imample, a (v))an be
// used by hokeherh emuple<per, sho t>,h emuple<nst Maca M&,odolice>,/ a c) t The
 fery.uswere
 hgemplate <thaveentrrb sn iserator ca the
 
 implementation.
  
//   Wuseine anis ands matccronkerder to imemitsne <tplicatio so fce c
 nentdateefine GMOCK_INCLIEENT OICOMPISINON2ATCHERS__(me T,aer,elativeon) \   ass fome T##2tcherInu  \   *blic:
  \   *omplate <typename T>
1anpename T>
2>n\   *oerator catchAn<T>>std::ostr1::muple<
1an
2>n> const {
 e\   im: turn inkes tcher<T w mapl>:>>std::ostr1::muple<
1an
2>n>
 e\   im} \   *omplate <typename T>
1anpename T>
2>n\   *oerator catchAn<T>nst {
std::ostr1::muple<
1an
2>&> const {
 e\   im: turn inkes tcher<T w mapl>:>nst {
std::ostr1::muple<
1an
2>&>
 e\   im} \   *otate:
  \   *omplate <typename T>Tuple>>\   *onss Mapl>: public MatcherDeterface<T>Tuple>> e\   im:blic:
  \   *o//rtual vool MatchAndExplain(T m\   *oviii//eupleigums  \   *oviii//tchResultListener* li/listener) e*/)
nst { re\   *oviiiturn instd::ostr1::get<0>(gums)oertstd::ostr1::get<1>(gums);e\   *ovi} \   *ovirtual ~Mid DescribeTo(::std::ostream* os) const { im\   *oviiis << "n"e no"elativeon;                                 \   *ovi} \   *ovirtual ~Mid DescribeTogationTo(::std::ostream* os) const {
 m\   *oviiis << "n"e nt ma"<lativeon; \   *ovi} \   *o} e\   }// Anplementats (v) , Ge) , Gt) , Le) , Lt) , d liNe))esulneive rly  OCK_INCLIEENT OICOMPISINON2ATCHERS__(Eq,e==, s bepql ~Mpair")  OCK_INCLIEENT OICOMPISINON2ATCHERS__(   *oGT,a>=, saMpairhen
.ust terst.
a>=te unuenstd")  OCK_INCLIEENT OICOMPISINON2ATCHERS__(   *oGt, >, saMpairhen
.ust terst.
a>te unuenstd")  OCK_INCLIEENT OICOMPISINON2ATCHERS__(   *oLe, <=, saMpairhen
.ust terst.
a<=te unuenstd")  OCK_INCLIEENT OICOMPISINON2ATCHERS__(   *oLt, <etsaMpairhen
.ust terst.
a<te unuenstd")  OCK_INCLIEENT OICOMPISINON2ATCHERS__(Ne, !=, s beunpql ~Mpair")   #uef GMOCK_INCLIEENT OICOMPISINON2ATCHERS__// Anplementats e pet())...)itcher fro roanparallar ltgument, eee T,T./   Wusenht usnd Mattf ide Byt tet()tcherInuass Mamplate <as ite
 t/ Anll deoden urefferencemaieru  tiion sfo tht()tcherInuom itsh ag M/ thatmaue Tht()tcherInpl>:> ouass M./mplate <typename T>
class Mat()tcherInpl>: public MatcherDeterface<T>*     blic:
  viplicit Mat()tcherInpl>:.nst MatcherIn>T &otcher.
)     : imtcher.
_ mcher.
) 

  virtual vool MatchAndExplain(T x, MatchResultListener* listener) const {
    return in!tcher.
_ tchRedExplain(x,xlistener);
  }

  virtual void DescribeTo(::std::ostream* os) const = {     tcher.
_ scribeTogationTo(os);
  }

  virtual void DescribeTogationTo(::std::ostream* os) const {
    imtcher.
_ scribeTo(os);
  }

  votate:
  //nst MatchRe<T> obtcher.
_}    EST_DISALLOW_ASSIGN_(nat()tcherInpl>:
};

// Anplementats e pet())m.otcher.
, ich muscher sty-"ue.
o natoesn't m /matcheretcher tos./mplate <typename T>Inr itcherInclass Mat()tcherIn    blic:
  viplicit Mat()tcherIn(Inr itcherInotcher.
)
imtcher.
_ mcher.
) 

  vi Itis hemplate <thaveentrrb sn iserator caaowinset())m.o be aled b
im    wrkeherh  nupena moe nhtch r  bomplate <typename T>
  Maerator catchAn<T> o const {
    return intchAn<T> o w mat()tcherInpl>:> o(SafttcherInCast> o mcher.
_))
  }

 protate:
  //Inr itcherInotcher.
_}    EST_DISALLOW_ASSIGN_(nat()tcherIn
};

// Anplementats e peAllOf(m1anm2)itcher fro roanparallar ltgument, eee T/ The. Wusenht usnd Mattf ide Byt teBothOftcherInuass Mamplate <as i/ that dewl deoden urefferencemaieru  tiion sfo thBothOftcherInuom in Marh ag Mhatmaue ThBothOftcherInpl>:> ouass M./mplate <typename T>
class MaBothOftcherInpl>: public MatcherDeterface<T>*     blic:
  viBothOftcherInpl>:.nst MatcherIn>T &otcher.
1/ nst MatcherIn>T &otcher.
2)     : imtcher.
1_ mcher.
1 / tcher.
2_ mcher.
2) 

  virtual void DescribeTo(::std::ostream* os) const { i   res << "no(
    Detcher.
1_escribeTo(os);
    *os << "no)nd
/ (
    Detcher.
2_escribeTo(os);
    *os << "no)"  }

  virtual void DescribeTogationTo(::std::ostream* os) const {
    ims << "no(
    Detcher.
1_escribeTogationTo(os);
  }
*os << "no)n ro(
    Detcher.
2_escribeTogationTo(os);
  }
*os << "no)"  }

  virtual vool MatchAndExplain(T x, MatchResultListener* listener) const {
    re/thItheier antcher.
1_n rotcher.
2_oesn't makeherhx,e suty gueds    re/th imelain(T icy n Ma the vm.ilurste////SingMatchResultListener : stener i1    De (st!tcher.
1_etchRedExplain(x,xli&stener i1))
    im: *stener->< "nstener i1.r();     *o//turn infalse  }
*o
  viviSingMatchResultListener : stener i2    De (st!tcher.
2_etchRedExplain(x,xli&stener i2))
    im: *stener->< "nstener i2.r();     *o//turn infalse  }
*o
  vivi/thOer awisee sund to imelain(T icy * oti*a the vm.tch r  borenst Maternal::string sns1,=nstener i1.r();     *onst Maternal::string sns2,=nstener i2.r();      De (sts1 ==>"")
    im: *stener->< "ns2    De} else
    im: *stener->< "ns1    *o// (sts2n!= "")
    im: re*stener->< "no, d li"< "ns2    DeDe
 }
re
 }
return Maue i  }

  /otate:
  //nst MatchRe<T> obtcher.
1_  }
nst MatchRe<T> obtcher.
2_}    EST_DISALLOW_ASSIGN_(naBothOftcherInpl>:
};

//f GTEST_HALANG_CXX11/ MatchReersten/otovidewhmechanismfor imstesg Maaaluou ble tber of titcher.
anit
tr anstenxstctore me(stenTena)nd
/ cam*tl a necombing aitcher from itsu mua
tr sten./ The twmplate <t exdined byrecurbl rlynedg a e Dellowing dimporte <tramewt 
s:/   ma* kSe i is e peleng()a the vetchReersten./   ma* Hd ofis e peae T, met terst.
atcher frothe listen./   ma* Tlurxdit ues e peae Tsrothe liremaing aitcher.
anothe listen./mplate <tyt a kSe ianpename T>Hd oanpename T.". Tlur>
stctoratchReersten/    mavef GMtchReersten<kSe i - 1, Tlur.".>MtchReerstenTlur;   mavef GMstd::ospair<Hd oanpename TMtchReerstenTlur::stenTena> stenTena
  // InBuildLtenxstor a luou dncahaveslue,
seithgented inpairhstctore m. // ReEmple, : vi ImMcher rsten<3,mper, ring s, float>::BuildLten(5, sfoo", 2.0)ill derurn M
// sit tensrsponsing whsult *i type T,pair<per, pair<ring s, float>>  bostioncastenTenanBuildLten.nst MaHd o&otcher.
 Enst MaTlur&.". tls,)
    return instenTena(tcher.
 EtchReerstenTlur::BuildLten.tlur.".c)  }

  // ReCam*tetchRe<T> obcam*teatgitchRe<T> obrm itliven unstenx titcher.
an(builu
// rebynBuildLten.c
 TCombing atchRe<T> ob exed to encombinehe detch r.
anothe l
// resten.TCombing atchRe<T> obst beplement dutcherDeterface<T>*  d
/ ve sia    manstructor aekesg dimwoitchRe<T> oands input  bomplate <typename T>
,omplate <typename T>/* T */>nass foCombing atchRe<T> exstioncatchRe<T> obCam*tetchRe<T.nst MastenTena&emcher.
s)
    return intchAn<T> o w maCombing atchRe<T> o          SafttcherInCast> o mcher.
s.rst.

          tchReerstenTlur::mplate <tCam*tetchRe<T> ,oCombing atchRe<T>            Detcher.
s.uenstd))
  }

 

// The imllowing didined s e pebe {allswor ime lirecurbl rtfinition, nof/ MatchReersten  mplate <typename T>Mcher.
1anpename TMtchReer2>
stctoratchReersten<2,>Mcher.
1antchReer2>/    mavef GMstd::ospair<Mcher.
1antchReer2>/stenTena
  //stioncastenTenanBuildLten.nst MaMcher.
1&otcher.
1/           Deeeeeeeeeeeeeeeeenst MaMcher.
2&otcher.
2)
    return instd::ospair<Mcher.
1antchReer2> mcher.
1/ tcher.
2)  }

  //mplate <typename T>
,omplate <typename T>/* T */>nass foCombing atchRe<T> exstioncatchRe<T> obCam*tetchRe<T.nst MastenTena&emcher.
s)
    return intchAn<T> o w maCombing atchRe<T> o          SafttcherInCast> o mcher.
s.rst.

          SafttcherInCast> o mcher.
s.uenstd))
  }

 

// ThVuou dnctcherInu exed tor ime liluou dncaplementation.
nof/ MaAllOf(m_1/ t_2,>...)id
/ AnyOf(m_1/ t_2,>...)./   Ctmbing atchRe<T> ob exed to enrecurbl rlyncombinehe deotovidedemcher.
     ( type T,Args...)./mplate <typplate <typename T>
cnass foCombing atchRe<Tanpename T.". Argsclass MaVuou dnctcherInu   blic:
  viVuou dnctcherIn.nst MaArgs&.". mcher.
s)
/ NOLINT
#i      imtcher.
snatcherBrstenTena::BuildLten.mcher.
s.".c) 

  vi Itis hemplate <thaveentrrb sn iserator caaowinseaM
// siVuou dnctcherIn<Mcher.
1antchReer2.".>Mjects   wrkeherh  nupena e
 t/// nea de Goe pertovidedemcher.
  (Mcher.
1antchReer2,>...)ie nhtch r  bomplate <typename T>
  Maerator catchAn<T> o const {
    return intchAn<TstenTena::mplate <tCam*tetchRe<T> ,oCombing atchRe<T>          tcher.
sn
  }

 protate:
  //mavef GMtchReersten<re iof...(Args),,Args...>ntchAn<TstenTena;  //nst Mapename TMtchReerstenTena::stenTenantcher.
sn}    EST_DISALLOW_ASSIGN_(naVuou dnctcherIn
};

//mplate <typename T.". Argscledg a AllOftcherInu=iVuou dnctcherIn<BothOftcherInpl>:,,Args...>
//fdif

u/ GMOST_HALANG_CXX11/    Ud tor implementatg a e DeAllOf(m_1/ .../ t_n.otcher.
, ich m
 netcher.sty-"ue.
o natotcher.sty de Goe pemcher.
  m_1/ .../ d
/ t_n  mplate <typename T>Mcher.
1anpename TMtchReer2>
ass MaBothOftcherIn    blic:
  viBothOftcherIn(Mcher.
1otcher.
1/ tchReer2otcher.
2)     : imtcher.
1_ mcher.
1 / tcher.
2_ mcher.
2) 

  vi Itis hemplate <thaveentrrb sn iserator caaowinsea // InBothOftcherIn<Mcher.
1antchReer2>/jects   wrkeherh  nupena e
 t/// ne oti>Mcher.
1 m MatchReer2oe nhtch r  bomplate <typename T>
  Maerator catchAn<T> o const {
    return intchAn<T> o w maBothOftcherInpl>:> o(SafttcherInCast> o mcher.
1_)                                                 SafttcherInCast> o mcher.
2_))
  }

 protate:
  //Mcher.
1otcher.
1_  }
tchReer2otcher.
2_}    EST_DISALLOW_ASSIGN_(naBothOftcherIn
};

// Anplementats e peAnyOf(m1anm2)itcher fro roanparallar ltgument, eee T/ The.  Wusenht usnd Mattf ide Byt teAnyOftcherIn ass Mamplate <as i/ that dewl deoden urefferencemaieru  tiion sfo thAnyOftcherIn om in Marh ag Mhatmaue ThEier aOftcherInpl>:> ouass M./mplate <typename T>
class MaEier aOftcherInpl>: public MatcherDeterface<T>*     blic:
  viEier aOftcherInpl>:.nst MatcherIn>T &otcher.
1/ nst MatcherIn>T &otcher.
2)     : imtcher.
1_ mcher.
1 / tcher.
2_ mcher.
2) 

  virtual void DescribeTo(::std::ostream* os) const { i   res << "no(
    Detcher.
1_escribeTo(os);
    *os << "no)n ro(
    Detcher.
2_escribeTo(os);
    *os << "no)"  }

  virtual void DescribeTogationTo(::std::ostream* os) const {
    ims << "no(
    Detcher.
1_escribeTogationTo(os);
  }
*os << "no)nd
/ (
    Detcher.
2_escribeTogationTo(os);
  }
*os << "no)"  }

  virtual vool MatchAndExplain(T x, MatchResultListener* listener) const {
    re/thItheier antcher.
1_n rotcher.
2_otcher.stx,e sujt bend to i   re/thelain(T icy *one*a the vm.tch reste////SingMatchResultListener : stener i1    De (sttcher.
1_etchAndExplain(T xli&stener i1))
    im: *stener->< "nstener i1.r();     *o//turn inue i  }
*o
  viviSingMatchResultListener : stener i2    De (sttcher.
2_etchAndExplain(T xli&stener i2))
    im: *stener->< "nstener i2.r();     *o//turn inue i  }
*o
  vivi/thOer awisee sund to imelain(T icy * oti*a the vm.ilur  borenst Maternal::string sns1,=nstener i1.r();     *onst Maternal::string sns2,=nstener i2.r();      De (sts1 ==>"")
    im: *stener->< "ns2    De} else
    im: *stener->< "ns1    *o// (sts2n!= "")
    im: re*stener->< "no, d li"< "ns2    DeDe
 }
re
 }
return infalse  }

  /otate:
  //nst MatchRe<T> obtcher.
1_  }
nst MatchRe<T> obtcher.
2_}    EST_DISALLOW_ASSIGN_(naEier aOftcherInpl>:
};

//f GTEST_HALANG_CXX11/ MaAnyOftcherIn  exed tor ime liluou dncaplementation.
nof AnyOf(m_1/ t_2,>...)./mplate <typename T.". Argscledg a AnyOftcherIn =iVuou dnctcherIn<Eier aOftcherInpl>:,,Args...>
//fdif

u/ GMOST_HALANG_CXX11/    Ud tor implementatg a e DeAnyOf(m_1/ .../ t_n.otcher.
, ich m
 netcher.sty-"ue.
o natotcher.styt leaenx  Ma the vemcher.
  m_1/ .../
tr a
/ t_n  mplate <typename T>Mcher.
1anpename TMtchReer2>
ass MaEier aOftcherIn    blic:
  viEier aOftcherIn(Mcher.
1otcher.
1/ tchReer2otcher.
2)     : imtcher.
1_ mcher.
1 / tcher.
2_ mcher.
2) 

  vi Itis hemplate <thaveentrrb sn iserator caaowinsea // InEier aOftcherIn<Mcher.
1antchReer2>/jects   wrkeherh  nupena e
 t/// ne oti>Mcher.
1 m MatchReer2oe nhtch r  bomplate <typename T>
  Maerator catchAn<T> o const {
    return intchAn<T> o w maEier aOftcherInpl>:> o          SafttcherInCast> o mcher.
1_)  SafttcherInCast> o mcher.
2_))
  }

 protate:
  //Mcher.
1otcher.
1_  }
tchReer2otcher.
2_}    EST_DISALLOW_ASSIGN_(naEier aOftcherIn
};

// AnUd tor implementatg a Truly,pfed),hath isrns thaeodedatio aterbean Matcher.
  mplate <typename T>Pdedatio class MaerulytcherIn    blic:
  viplicit MaerulytcherIn(Pdedatio eoded: stpfedatio _,pfed) 

  vi Itis hethod camplate <taowinseTruly,pfed)o be aled b
aa litcher f vi Itr imee T,Then
.usTfis e pegument, eee T, thodedatio a'oded' The
  ///sigument, s inps M b
byeferences igs e perdedatio amagu N
re Makerested insi t tegddstes, mee pegument,   bomplate <typename T>
  Maol MatchAndExplain(T x&nxMa/ NOLINT
#i                       tchResultListener* li/listener) e*/)
nst { r   re   Wierouthe foif-stioentatantSVCtme cmes s was thabouthpinrb tg M/  re   y-"ue.
o oaol Ma(was g a 4800)./  re     re   Wsuc
 t reite "v'turn in!!pfedatio _,x);'s ite
 toesn't mark f   re   en thsfedatio _,x)oturns a a ass Mapinrb tgble  oaol Mab
//  im   havg.
bw-aerator c!()./  re (stsfedatio _,x))     : turn inue i  }
*oturn infalse  }

  //id DescribeTo(::std::ostream* os) const { i   res << "nosionsfi s e peven unsfedatio "  }

  //id DescribeTogationTo(::std::ostream* os) const {
    ims << "noesn't masionsfy e peven unsfedatio "  }

  /otate:
  //Pdedatio eodedatio _}    EST_DISALLOW_ASSIGN_(naerulytcherIn
};

// AnUd tor implementatg a tcherIs mcher.
),hath isrns thaetcher frterb
tr anodedatio   mplate <typename T>M> ass MatcherBrAsPdedatio e   blic:
  viplicit MatcherBrAsPdedatio (Motcher.
)
imtcher.
_ mcher.
) 

  vi Itis hemplate <torator c.  aowinsetcherIs m)o be aled b
aa l vi Itrdedatio a shmena,Then
.usme ex
atcher fr shmena,T  //
  // Itispegument, exs inps M b
byeferences i tead of "Ebnulue ias i/im   se cotcher frmagu Nakerested insi ptsogddstes,(e.g.nds in
vi ImMcher s(Ref(n)),x))  bomplate <typename T>
  Maol Maorator c. .nst MaT&nx: nst { r   re   Wpeledetcher 
_ncommito beaaparallar ltmena,n
.us tead of "   re   en the vetchReerAsPdedatio ejects  wasanstructored This h/  re   yowinseus  write "vtcherIs m)oen
.usme ex
apolyry.phicatcher.
/  re   (e.g.n(v)5))./  re     re   Ithwwaste "vtcherIr> o mcher.
_).tcherIs x: n
.u,attfwot m   re   ntleile en thtcher 
_ns atmena,tcherIr>nst MaT&>;e (swwaste "   re   tcherIr>nst MaT&> mcher.
_).tcherIs x: n
.u,attfwot m ntleile   re   en thtcher 
_ns atmena,tcherIr>T>;e (swwajt beste "   re   tcher 
_.tcherIs x:,attfwot m ntleile en thtcher 
_n h/  re   polyry.phic, e.g.n(v)5)./  re     re   tcherInCast>nst MaT&> )gnNUteedibarform smesg dim tensdeark f   re   ithg de Goe peabove situion sf  ex: turn inkeherInCast>nst MaT&> mcher.
_).tcherIs x:  }

 protate:
  //Motcher.
_}    EST_DISALLOW_ASSIGN_(natchReerAsPdedatio 
};

// AnF implementatg a SIGERT_THAT()nd
/ EXPECT_THAT() The
 etplate <
 sigument, /Mott beb hgemena e
 tan be
/fcinrb t to beaatcher.
  mplate <typename T>M> ass MaPdedatio F imatanaFromtcherIn    blic:
  viplicit MaPdedatio F imatanaFromtcherIn.nst Mat& m)
imtcher.
_ m) 

  vi Itis hemplate <t()serator caaowinseaaPdedatio F imatanaFromtcherIn vi Itjects   wras  athaeodedatio -f imatana suit ble rm sedg a th t
u/ GMOgle MoTted's EXPECT_PRED_FORMAT1).otccro  bomplate <typename T>
  MaA M ron sRult *i rator c. .nst Macred* "ue.
_pext Enst MaT&nx: nst { r   re   Wpepinrb t tcher 
_n beaatcherIr>nst MaT&> *now*s tead of "   re   en the vePdedatio F imatanaFromtcherIn jects  wasanstructored,   re NOas tcher 
_nmagu Napolyry.phica(e.g.nNotNu M).)nd
/ wwasot m   re   knowhath isrena eofieru  tiio  ito beu tilswer cal vly seehe l
//// site T, thx n
.u./  re     re   Wsuste "vSafttcherInCast>nst MaT&> mcher.
_)s tead of "   re   tcherIr>nst MaT&> mcher.
_),igs e pelatana wot m ntleile en t   re   tcher 
_ns atmena,tcherIr>T>a(e.g.nAn>t a>())./  re   Wusent marte "vtcherIrCast>nst MaT&>heier aas ite
 taaowins/  re   pottatg vly unsaftsenwnce tg a nthe vemcher.
egument,   bo}
nst MatchRe<T>nst MaT&>hmcher.
e=vSafttcherInCast>nst MaT&> mcher.
_); viviSingMatchResultListener : stener i    De (sttchRePnts dExplain(T xlitcher.
, &stener i))     : turn inA M ron sSceedib;      Destd::osring sream*  ss    Des<< "noVue is t:i"< "n"ue.
_pext< "no\n"i        "noEecteded: 
    Detcher.
escribeTo(os&s;
  }
*os<< "no\nMaAcal v:i"< "nstener i.r();     *oturn inA M ron sFailure))e "nss.r();     
  /otate:
  //nst Matotcher.
_}    EST_DISALLOW_ASSIGN_(naPdedatio F imatanaFromtcherIn
};

// AnAthper<rorction sorm sconrb tg M matcher to ohaeodedatio -f imatana/ Anllerouthe foer tund tg dimoiplicit Mly rte "ve peae T This he e/ used byr implementatg a SIGERT_THAT()nd
/ EXPECT_THAT()  mplate <typename T>M> line MaPdedatio F imatanaFromtcherIn<M> kes Pdedatio F imatanaFromtcherIn.nst Mat& mcher.
) 

*oturn inPdedatio F imatanaFromtcherIn<M> mcher.
)  }// Anplementats e perolyry.phicafloatg a pots  pql ~ityotcher.
, ich muscher s  impwosfloatslue,
seedg a ULP-be {deapproximion.
nor,aeron.
 vly,ean Maer t-lneiifd liepsilon The
 etplate <e exme  to ou NUteru  tiio soth t/ AnFloatTenaning maeier anfloats imdolice  mplate <typename T>FloatTena> ass MaFloatg aEqtcherIn    blic:
  vi   Cttructor aer imFloatg aEqtcherIn. // Itispetcher.
's inputewl de
/fcilear doth thrh  The
 etcher to am*tsmpwo // ItNANands pql ~M (snan_eq_n impsnue i ThOer awise, uef r IEEExstindards  // lipql ~ityoeylearisons,intwe thNANanwl dealwaysoturn infalse.  Wuslneiifyoa    mawationv etcx_abs_ror m_n erm eofiedatio ee
 taULP-be {deapproximion.
nwl d/// ne esed byr imeylearison. //Floatg aEqtcherIn(FloatTenanrhs  ol Manan_eq_n i) :     rh _(rh :,anan_eq_n i_(men_eq_n i),etcx_abs_ror m_(-1: { }

  // ReCttructor aee
 tasuppo tshuser t-lneiifd litcx_abs_ror mhat dewl de aled b
im   r imeylearisoni tead of "EULP-be {deapproximion.
 The
 etcxeabsolutN
re Masroulde alw-rewationv . //Floatg aEqtcherIn(FloatTenanrhs  ol Manan_eq_n i,nFloatTenantcx_abs_ror m) :     rh _(rh :,anan_eq_n i_(men_eq_n i),etcx_abs_ror m_(tcx_abs_ror m) r   reEST_DICHECK_(tcx_abs_ror ma>=t0c          "no,oen
.usmcx_abs_ror mais"< "nmcx_abs_ror m  }

  // Replementats floatg a pots  pql ~ityotcher.
y atgitchRe<T> o  bomplate <typename T>
  Manss Mapl>: public MatcherDeterface<T>To     rblic:
  ex//pl>:.FloatTenanrhs  ol Manan_eq_n i,nFloatTenantcx_abs_ror m) :       rh _(rh :,anan_eq_n i_(men_eq_n i),etcx_abs_ror m_(tcx_abs_ror m) r
  vivirtual vool MatchAndExplain(T x,lue iai                                 tchResultListener* li/listener) e*/)
nst { r   re//nst MaFloatg aintee<FloatTena> lhs("ue.
)  rh  rh _)     De// ReCtlear a NaNanrst.
,M (snan_eq_n i_mpsnue i    De// (stlhs.is_n i()n||hrh  is_n i())
    im: re (stlhs.is_n i()n&&hrh  is_n i())
    im: re*oturn innan_eq_n i_;   im: re}   im: re/thOn<e exn i; e peotrIn  ext usnan.
im: re*oturn infalse  }
*ore}   im:  (stHasMaxAbsEor m())
    im: re   Wusr<rf im  bepql ~ityoeheck soeet ignnfewl dekeherhnnf,elagardldib   im: re    "Eeor mabouef  ThIthe lirelt *i ty"ue.
o- rh _ woulderelt *iin   im: re    rb flowo imitheier an"ue.
o he nf,ee lidefat *irelt *iihe nfitioy,   im: re   ich musrouldety gukeherhnfetcx_abs_ror m_n ex
lsoe nfitioy.
im: re*oturn in"ue.
o== rh _ ||hfabs("ue.
o- rh _)a<=ttcx_abs_ror m_  }
*ore} else
    im: *oturn inlhs.AlmostEql ~s rh :  }
*ore}   im
  vivirtual void DescribeTo(::std::ostream* os) const = {     :     s->odecisn i()oturns a e perdevious,
ssen/otecisn i, ich muwe     :    stor o enrestor o  peoream*  eofits origi
 vonstfigurion.
     :    afana outputtg s  //re//nst Mastd::osrinm* re i old_otecisn ie=v s->odecisn i(   im: re*ostd::osnentric_mitsts<FloatTena>::digits10 + 2:  }
*ore (stFloatg aintee<FloatTena> rh _) is_n i())
    im: re (stnan_eq_n i_)
    im: re*os << "no eaLaN";   im: re} else
    im: *o*os << "nonev toscher s";   im: re}   im: } else
    im: *os << "no eaapproximiorlyn"< "nrh _;   im: re (stHasMaxAbsEor m())
    im: re*os << "no (absolutNEeor ma<=t"< "nmcx_abs_ror m_< "no)"  }
im: re}   im: }   im:  s->odecisn i(old_otecisn i
    *o
  vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im:  AnAs,inry.u, get origi
 vootecisn i  //re//nst Mastd::osrinm* re i old_otecisn ie=v s->odecisn i(   im: re*ostd::osnentric_mitsts<FloatTena>::digits10 + 2:  }
*ore (stFloatg aintee<FloatTena> rh _) is_n i())
    im: re (stnan_eq_n i_)
    im: re*os << "no et maLaN";   im: re} else
    im: *o*os << "noisty nmng t";   im: re}   im: } else
    im: *os << "no et maapproximiorlyn"< "nrh _;   im: re (stHasMaxAbsEor m())
    im: re*os << "no (absolutNEeor ma>t"< "nmcx_abs_ror m_< "no)"  }
im: re}   im: }   im: /Retustor oorigi
 vootecisn i  //re// s->odecisn i(old_otecisn i
    *o
  vivotate:
  //bool MaHasMaxAbsEor m()onst {
    im: turn inmcx_abs_ror m_<>0;
  //*o
  vivinst MaFloatTenanrhs_    *onst Maol Manan_eq_n i_    *o   tcx_abs_ror mawl de aled b r im"ue.
oeylearisonien th>0;
. vivinst MaFloatTenantcx_abs_ror m_     reEST_DISALLOW_ASSIGN_(napl<F
  }

}; // The imllowing di3thaveentrrb sn iserator csaaowinaFloatEq rh : d
//// reNanSensive rFloatEq rh :  be aled b
aa litchRe<T>float>,oa    matchRe<T>nst Mafloat&>,o roantchRe<T>float&>,obutet ung thelse. // It(While Ogle M's C++ensdg snstyleoesn't maaowinagument, snps M b
// rebynw-renstruiferences asw amaguseehe lm ithnsdeat usnstf img dimo
// sit testyle The
 fery.usOgle Mock) geds to exsuppo the lm.c   erator catchAn<T>FloatTena> const {
    return intcs tcher<T w mapl>:>FloatTena> rh _,anan_eq_n i_,etcx_abs_ror m_c)  }

  //erator catchAn<T>nst {
FloatTena&o const {
    return intcs tcher<T  }
im: rew mapl>:>nst {
FloatTena&o rh _,anan_eq_n i_,etcx_abs_ror m_c)  }

  //erator catchAn<T>FloatTena&o const {
    return intcs tcher<T w mapl>:>FloatTena&o rh _,anan_eq_n i_,etcx_abs_ror m_c)  }

  /otate:
  //nst MaFloatTenanrhs_    nst Maol Manan_eq_n i_       tcx_abs_ror mawl de aled b r im"ue.
oeylearisonien th>0;
. vinst MaFloatTenantcx_abs_ror m_     EST_DISALLOW_ASSIGN_(naFloatg aEqtcherIn
};

// Anplementats e peinteeee)m.otcher.
orm smeherg M mapots .
swhos<
 sipots . etcher hetcher tos The
 epots .
sn be
/feier anrawo imsmarn  mplate <typename T>Inr itcherInclass MainteeeetcherIn    blic:
  viplicit MaPnteeeetcherIn.nst MaInr itcherIn& mcher.
) imtcher.
_ mcher.
) 

  vi Itis hemaveentrrb sn iserator camplate <taowinseinteeee)m.o be a vi Ited b
aa litcher fro roanyapots .
saenaswhos<ipots . eaenasii/im   eyleatgble th the coten antcher.
,oen
.usaenasPots .
sn be
/ // lipier ananrawopots .
s roansmarnopots .
  //
  // Itispenm*sonieusenhis an tead of "Errlyg a n     matckePolyry.phictcherIn.)fis e  the folatana  ext usflexgble // lipnoughor implementatg a e DescribeTo(::)ethod ca "Einteeee))  bomplate <typename T>Pots .
  Maerator catchAn<T>Pots .
  const {
    return intcs tcher<T w mapl>:>Pots .
  mcher.
_))  }

  /otate:
  // Itispetonory.phicaplementation.
nat deworksro roanparallar ltpots .
saena  bomplate <typename T>Pots .
  Manss Mapl>: public MatcherDeterface<T>Pots .
      rblic:
  ex//mavef GMpename T>Pots .eOf<EST_DIREMOVE_CON_DI(a/ NOLINT
#i        EST_DIREMOVE_REFERENCE_(Pots .
))>::aenasPots .e     replicit Mapl>:.nst MaInr itcherIn& mcher.
)i        imtcher.
_ tcherInCast>nst MaPots .e&> mcher.
)) r
  vivirtual void DescribeTo(::std::ostream* os) const = {     : s << "nopots so ohae"ue.
o nato"  }
im: tcher 
_.scribeTo(os);
    *o
  vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: s << "noesn'xt uspots   ohae"ue.
o nato"  }
im: tcher 
_.scribeTo(os);
    *o
  vivirtual vool MatchAndExplain(T Pots .
spots .
ai                                 tchResultListener* listener) const {
    rere (stGetRawPots .
(pots .
) == LL; )
im: re*oturn infalse     im: sstener->< "noich mupots so oh"  }
im: turn inkeherPnts dExplain(T *pots .
a tcher 
_listener);
  }
*o
  vivotate:
  //bonst MatchRe<T>nst MaPots .e&>otcher.
_}    reEST_DISALLOW_ASSIGN_(napl<F
  }

}; //nst MaInr itcherInotcher.
_}    EST_DISALLOW_ASSIGN_(naPnteeeetcherIn
};

// Anplementats e peField(.otcher.
orm smeherg M mafield (i.e Tmeer o/ Anluou ble), mean jects   mplate <typename T>Css Manpename TMFieldTena> ass MaFieldtcherIn    blic:
  viFieldtcherIn(FieldTena>Css M::*fieldai               nst MatchRe<T>nst MaFieldTena& &otcher.
)     : imfield_(field / tcher.
_ mcher.
) 

  vird DescribeTo(::std::ostream* os) const { i   res << "noisty  jects  whos<iven unfield 
    Detcher.
_ scribeTo(os);
  }

  v/id DescribeTogationTo(::std::ostream* os) const {
    ims << "noisty  jects  whos<iven unfield 
    Detcher.
_ scribeTogationTo(os);
  }

  vimplate <typename T>
  Maol MatchAndExplain(T nst MaT&nlue iastchResultListener* listener) const {
    return MatchAndExplain(xpl>:.i        pename T>::mp tg a::ternal::sti            is_pots .
<EST_DIREMOVE_CON_DI(T)>::aena()          lue iasstener);
  }

  votate:
  // Itisperst.
agument, /ofatchAndExplain(xpl>:.)gnNUteed to behper // ItSymbian's C++ensleile
snhoos<iich mu rb loato beuse.  Itseaenasii/im   ue i_aenasiff e peField(.otcher.
o exed to enkeherhaopots .
  //ol MatchAndExplain(Tpl>:.false_aenas/* is_t u_pots .
 */ Enst MaCss M& jecai                           tchResultListener* listener) const {
    resstener->< "noicos<iven unfield  ea";   return MatchAnPnts dExplain(T jec.*field_a tcher 
_listener);
  }

  viol MatchAndExplain(Tpl>:.ue i_aenas/* is_pots .
 */ Enst MaCss M* pai                           tchResultListener* listener) const {
    re (sts == LL; )
im: return infalse     imsstener->< "noich mupots so ohy  jects  "    *o   Sies i*pns atmafield,attftt beb hgeass M/ructor/uni shmena,d
////// sit usuc
 t reb hgepots .
 The
 fery.uswerps M false_aena()nds///// sit perst.
agument,   ex: turn inkeherdExplain(Tpl>:.false_aena) , *plistener);
  }

  vinst MaFieldTena>Css M::*field_  }
nst MatchRe<T>nst MaFieldTena& otcher.
_}    EST_DISALLOW_ASSIGN_(naFieldtcherIn
};

// Anplementats e peireratty(.otcher.
orm smeherg M mapreratty    (i.e Tturn in"ue.
o mea getana thod c), mean jects   mplate <typename T>Css Manpename TMirerattyTena> ass MairerattytcherIn    blic:
  vi   T pertorattyamaguve siaeferences ipena, soe'nst MaPrerattyTena&'      tcy cse isdoliceeferences snd
/ iluro encomeile The
ad's icy we // lind toEST_DIREFERENCE_TO_CON_D, ich muworksrlagardldibf "    liPrerattyTenaning maaeferences im st r  bomavef GMEST_DIREFERENCE_TO_CON_DnaPderattyTena) RefToCttruPderatty}    irerattytcherInaPderattyTena (Css M::*rtoratty) const {ai                  nst MatchRe<T>RefToCttruPderatty &otcher.
)     : imrtoratty_,pforatty)/ tcher.
_ mcher.
) 

  vird DescribeTo(::std::ostream* os) const { i   res << "noisty  jects  whos<iven unrtorattya
    Detcher.
_ scribeTo(os);
  }

  v/id DescribeTogationTo(::std::ostream* os) const {
    ims << "noisty  jects  whos<iven unrtorattya
    Detcher.
_ scribeTogationTo(os);
  }

  vimplate <typename T>
  Maol MatchAndExplain(T nst MaT&lue iastchResultListener* listener) const {
    return MatchAndExplain(xpl>:.i        pename T>::mp tg a::ternal::sti            is_pots .
<EST_DIREMOVE_CON_DI(T)>::aena()          lue iasstener);
  }

  votate:
  // Itisperst.
agument, /ofatchAndExplain(xpl>:.)gnNUteed to behper // ItSymbian's C++ensleile
snhoos<iich mu rb loato beuse.  Itseaenasii/im   ue i_aenasiff e peireratty(.otcher.
o exed to enkeherhaopots .
  //ol MatchAndExplain(Tpl>:.false_aenas/* is_t u_pots .
 */ Enst MaCss M& jecai                           tchResultListener* listener) const {
    resstener->< "noicos<iven unrtorattya ea";   re ReC
 t reps M e lirern in"ue.
o(r imample, a ts .o betchAnPnts dExplain(T,   re NOath israk.sty-w-renstruiferences 
aa lument,   ex: RefToCttruPderattyirelt *i=  jec.*rtoratty_);     *oturn intchAnPnts dExplain(T relt *a tcher 
_listener);
  }

  viol MatchAndExplain(Tpl>:.ue i_aenas/* is_pots .
 */ Enst MaCss M* pai                           tchResultListener* listener) const {
    re (sts == LL; )
im: return infalse     imsstener->< "noich mupots so ohy  jects  "    *o   Sies i*pns atmartorattyamhod c,attftt beb hgeass M/ructor/uni s///// sitena,d
/it usuc
 t reb hgepots .
 The
 fery.uswerps M///// sifalse_aena()ndsit perst.
agument,   ex: turn inkeherdExplain(Tpl>:.false_aena) , *plistener);
  }

  viPderattyTena (Css M::*rtoratty_) const {  }
nst MatchRe<T>RefToCttruPderatty otcher.
_}    EST_DISALLOW_ASSIGN_(naPderattytcherIn
};

// AnTena traits lneiifyg maluouousufeare ms, mefferencemarctio csar imsultLiOf./ The twdefat *implate <tlneiifd sufeare ms,r imrctio c jects s./ ThFctio c ass Mms,he sieoemavef GMgument, _tena,d
/irelt *_ee T/ Th be aleyleatgble th thsultLiOf./mplate <typename T>Fctio c>
stctoraCall bleTraits {
//mavef GMpename T>Fctio c::relt *_ee ThsultLiTena; //mavef GMFctio c So cageTena;  //stioncaid DeCheckIsValid(Fctio c /* rctio c */)
{} vimplate <typename T>
  MastioncasultLiTena Invoke(Fctio c f, TMgum)
{eturn inf(gum);

 

// ThSneiializaon sorm srction sopots .
M./mplate <typename T>Ar
Tenaanpename TMsulTena> stctoraCall bleTraits<sulTena(*)(Ar
Tena)>/    mavef GMsulTenahsultLiTena; //mavef GMsulTena(*So cageTena)(Ar
Tena);  //stioncaid DeCheckIsValid(sulTena(*f)(Ar
Tena)) r   reEST_DICHECK_(f != LL; c          "noLL;  rction sopots .
s inps M b
terbesultLiOf()."  }

 vimplate <typename T>
  MastioncasulTena Invoke(sulTena(*f)(Ar
Tena), TMgum)
{ ex: turn in(*f)(gum);
}

 

// Thplementats e pesultLiOf()otcher.
orm smeherg M maturn in"ue.
o mean Maenarforction so mean jects   mplate <typename T>Call ble> ass MasultLiOftcherIn    blic:
  vimavef GMpename T>Call bleTraits<Call ble>::sultLiTena sultLiTena; 
 asultLiOftcherIn(Call bleuc
ll ble/ nst MatcherIn>sultLiTena &otcher.
)     : imc
ll ble_(c
ll ble)/ tcher.
_ mcher.
) 
     Call bleTraits<Call ble>::CheckIsValid(c
ll ble_
  }

  vimplate <typename T>
  Maerator catchAn<T> o const {
    return intchAn<T> o w mapl>:> o c
ll ble_/ tcher.
_))  }

  /otate:
  //mavef GMpename T>Call bleTraits<Call ble>::So cageTena>Call bleSo cageTena;  //mplate <typename T>
  Manss Mapl>: public MatcherDeterface<T>To     rblic:
  ex//pl>:.Call bleSo cageTenauc
ll ble/ nst MatcherIn>sultLiTena &otcher.
)     : : imc
ll ble_(c
ll ble)/ tcher.
_ mcher.
) 

  vivirtual void DescribeTo(::std::ostream* os) const = {     : s << "no exmapp b
byee peven unc
ll bleo ohae"ue.
o nato"  }
im: tcher 
_.scribeTo(os);
    *o
  vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: s << "no exmapp b
byee peven unc
ll bleo ohae"ue.
o nato"  }
im: tcher 
_.scribeTogationTo(os);
  }
*o
  vivirtual vool MatchAndExplain(T x,jeca tchResultListener* listener) const {
    reresstener->< "noich mu exmapp b
byee peven unc
ll bleo oh"  }
im:  ReC
 t reps M e lirern in"ue.
o(r imample, a ts .o b }
im:  RetchAnPnts dExplain(T,Oath israk.sty-w-renstruiferences 
aa lument,   ex:  asultLiTena relt *i=i          Call bleTraits<Call ble>::mplate <tInvoke> o c
ll ble_/ jec     *o//turn intchAnPnts dExplain(T relt *a tcher 
_listener);
  }
*o
  vivotate:
  //bo ThFctio cs, mnerseine anorator c.  as-w-renstruithod caen u erough///// sit py e no cal vyastioeldib. Butewsund to ime ise lm en u en t   re   'is a'e ex
anstruipots .
 TId's e foer t's sponsisibi~ityot re i   re/the isstioefulnc
ll bles th thsultLiOf(),hath isesn''t guaraeeee   re/thhow tc nupes s m ten
ll bleowl de alinvoked  ex: mut ble Call bleSo cageTenauc
ll ble_    *onst MatcherIn>sultLiTena otcher.
_}    reEST_DISALLOW_ASSIGN_(napl<F
  }

}im   ess Mapl>:  vinst MaCall bleSo cageTenauc
ll ble_    nst MatcherIn>sultLiTena otcher.
_}    EST_DISALLOW_ASSIGN_(nasultLiOftcherIn
};

// Anplementats matcher to t crehecks m tere i omean STL-styleoctain #.
  mplate <typename T>Se itcherInclass MaSe iIstcherIn    blic:
  viplicit MaSe iIstcherIn nst MaSe itcherIn&ere i_tcher.
)     : ::ere i_tcher.
_(re i_tcher.
) { }

  //mplate <typename T>Ctain #.
  Maerator catchAn<T>Ctain #.
  const {
    return intcs tcher<T w mapl>:>Ctain #.
  re i_tcher.
_)
  }

  vimplate <typename T>Ctain #.
  Manss Mapl>: public MatcherDeterface<T>Ctain #.
      rblic:
  ex//mavef GMternal::stStlCtain #.
View<i         EST_DIREMOVE_REFERENCE_AND_CON_DI(Ctain #.
)>/Ctain #.
View; ex//mavef GMpename T>Ctain #.
View::aenastde i_ee ThSe iTena; //replicit Mapl>:.nst MaSe itcherIn&ere i_tcher.
)     : :::ere i_tcher.
_(tcherInCast>Se iTena  re i_tcher.
)) r
  vivirtual void DescribeTo(::std::ostream* os) const = {     : s << "nore i "  }
im: re i_tcher.
_.scribeTo(os);
    *o
 vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: s << "nore i "  }
im: re i_tcher.
_.scribeTogationTo(os);
  }
*o
  vivirtual vool MatchAndExplain(T Ctain #.
octain #.
ai                                 tchResultListener* listener) const {
    rereSe iTenaere i =octain #.
 re i;     *o//SingMatchResultListener : re i_stener i    De  nst Maol Marelt *i= re i_tcher.
_.tchAndExplain(T se ian&re i_stener i     *o//sstener->i           "noicos<ire i "e "nse i  "n relt * ? "etcher.s" :i"<esn't makeher"     *o//Pnts IfNotEmpty(re i_stener i.r(); listener);->ream* ()     *o//turn inrelt *  }
*o
  vivotate:
  //bonst MatchRe<T>Se iTena  re i_tcher.
_;   reEST_DISALLOW_ASSIGN_(napl<F
  }

}  /otate:
  //nst MaSe itcherIn re i_tcher.
_;   EST_DISALLOW_ASSIGN_(naSe iIstcherIn
};

// Anplementats mn pql ~ityotcher.
yo roanyaSTL-styleoctain #.
 whos<iementatsn Maruppo th==.tis hetcher.
o exlike (v) , buteits failuremelainnion sfortoviden Maty.usdetlur b
tef imatn.
nat de exed fulnen the vectain #.
  exed to atmasen./ The twfailuremmdibaga repo tshementats e  taa.us tx  Ma the veeratondsobutet u/ thatmaotrIn.he twfailuremmdibagassenht usrepo t duicitio eja out-of-ord o/ Anementats ithe vectain #.
s (ath isest martorat gukeht to ohsens, butecat
tr occuimithe vectain #.
s a.usveio cs, : stens, r imample, )./  / AnUd she vectain #.
'sanstru_itator c,n"ue.
_penaanerator ca==/
tr beg(T  , d liend()  mplate <typename T>Ctain #.
  ass foCoain #.
EqtcherIn    blic:
  vimavef GMternal::stStlCtain #.
View<Ctain #.
  View; exmavef GMpename T>View::aena StlCtain #.
; exmavef GMpename T>View::nstru_ferences 
StlCtain #.
Rerences }; // ThW etck hgeaopyf "Erhs ithllswoe veementats ithitaa.usmodifd l
:    afana ts hetcher.
o excam*ted  explicit MaCoain #.
EqtcherIn.nst MaCoain #.
&hrh ) imrh _(View::Copy rh :) 
      matckesarur o  peer tuesn't maieru  tiio  ts heass Mamplate <   re NOah th
anstrui caferences ipena  ex: (id D)mp tg a::StioncA M roTenaEq<Ctain #.
ai        EST_DIREMOVE_REFERENCE_AND_CON_DI(Ctain #.
)>(
  }

  v/id DescribeTo(::std::ostream* os) const {
    ims << "nopql ~ea";   reUnirb salPnts  rh _,a);
  }

 //id DescribeTogationTo(::std::ostream* os) const {
    ims << "noesn'ht uspql ~M";   reUnirb salPnts  rh _,a);
  }

  vimplate <typename T>LhsCtain #.
  Maol MatchAndExplain(T nst MaLhsCtain #.
&nlhsai                       tchResultListener* listener) const {
    re// EST_DIREMOVE_CON_DI()gnNUteed to beworkaa.ouef mn tSVCt8.0 buM/  re   e
 tan ud shLhsCtain #.
h be al
anstruiaena me cmes s. ex//mavef GMternal::stStlCtain #.
View<EST_DIREMOVE_CON_DI(LhsCtain #.
)>i        LhsView; ex//mavef GMpename T>LhsView::aena LhsStlCtain #.
; ex 
StlCtain #.
Rerences nlhs_stl_ctain #.
 =>LhsView::CttruRerences tlhs     *o (stlhs_stl_ctain #.
 == rh _)     : turn inue i       std::ostream* osnstrui s,=nstener i->ream* ()    *o (st s,!= LL; c
    im:  AnSe cmrg M  exdferencem.eCheck r imamtraslue,
serst.
  ex:  aol Mapnts ed_head.
 =>false  }
*orer im(pename T>LhsStlCtain #.
::nstru_itator chita=i               lhs_stl_ctain #.
.beg(T  ;i           ita!= lhs_stl_ctain #.
.end(); ++it)
    im: re (stternal::stArrayAwa.uFind(rh _.beg(T  , rh _.end(), *it)
==i            rh _.end())
    im: re*o (stsfts ed_head.
)
    im: re*oims << "no, "  }
im:     } else
    im: *o*oims << "noath ishdsit pse
uneectededeementats: "  }
im:      apnts ed_head.
 =>ue i  }
*o:     } }
*o:     Unirb salPnts  *it,a);
  }
:     } }
*o: }    De// ReNowoeheck rm smissg malue,
s  ex:  aol Mapnts ed_head.
2 =>false  }
*orer im(pename T>StlCtain #.
::nstru_itator chita= rh _.beg(T  ;i           ita!= rh _.end(); ++it)
    im: re (stternal::stArrayAwa.uFind(i                lhs_stl_ctain #.
.beg(T  , lhs_stl_ctain #.
.end(), *it)
==i            lhs_stl_ctain #.
.end())
    im: re*o (stsfts ed_head.
2)
    im: re*oims << "no, "  }
im:     } else
    im: *o*oims << "ntsfts ed_head.
 ? ",\nd l" :i"ath i")i                 "no esn't mahe sie pse
eectededeementats: "  }
im:      apnts ed_head.
2 =>ue i  }
*o:     } }
*o:     Unirb salPnts  *it,a);
  }
:     } }
*o: } *o: }    return infalse  }

  /otate:
  //nst MaStlCtain #.
nrhs_     EST_DISALLOW_ASSIGN_(naCoain #.
EqtcherIn
};

// AnAteylearor chrctio c e
 taud she ve<serator camofcilear mpwoslue,
s  stctoraLdibCylearor ch{ vimplate <typename T>Tanpename TMU  Maol Maorator c. .nst MaT&nlhsa/nst MaU&hrh ) nst {
 oturn inlhs "nrh ;

 

// Thplementats Wn tSo t tBy(eylearor c,ectain #.
_tcher.
)  mplate <typename T>Ctlearor c,epename T>Ctain #.
tcherInclass MaWn tSo t tBytcherIn    blic:
  viWn tSo t tBytcherIn.nst MaColearor c&teylearor cai                      nst MaCoain #.
tcherIn&etcher.
)     : imcylearor c_(eylearor c)/ tcher.
_ mcher.
) 

  vimplate <typename T>LhsCtain #.
  Maerator catchAn<T>LhsCtain #.
  const {
    return intcs tcher<T w mapl>:>LhsCtain #.
  cylearor c_/ tcher.
_))  }

  /implate <typename T>LhsCtain #.
  Manss Mapl>: public MatcherDeterface<T>LhsCtain #.
      rblic:
  ex//mavef GMternal::stStlCtain #.
View<i         EST_DIREMOVE_REFERENCE_AND_CON_DI(LhsCtain #.
)> LhsView; ex//mavef GMpename T>LhsView::aena LhsStlCtain #.
; ex 
mavef GMpename T>LhsView::nstru_ferences 
LhsStlCtain #.
Rerences };ex 
 Theransf imsar::ospair<nst {
Key, Vue i>
terber::ospair<Key, Vue i>;ex 
 Thsoeet igweoe nhtch r s Mociionv ectain #.
s. ex 
mavef GMpename T>RemoveCttruFromKey<i        pename T>LhsStlCtain #.
::"ue.
_pena>::aena LhsVue i       pl>:.nst MaColearor c&teylearor ca nst MaCoain #.
tcherIn&etcher.
)     : : imcylearor c_(eylearor c)/ tcher.
_ mcher.
) 

  vivirtual void DescribeTo(::std::ostream* os) const = {     : s << "no(en thso t t)o"  }
im: tcher 
_.scribeTo(os);
    *o
  vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: s << "no(en thso t t)o"  }
im: tcher 
_.scribeTogationTo(os);
  }
*o
  vivirtual vool MatchAndExplain(T LhsCtain #.
hlhsai                                 tchResultListener* listener) const {
    rereLhsStlCtain #.
Rerences nlhs_stl_ctain #.
 =>LhsView::CttruRerences tlhs     *o  std::osveio c<LhsVue i>hso t t_ctain #.
tlhs_stl_ctain #.
.beg(T  ,i                                               lhs_stl_ctain #.
.end())    *o  std::osso t(i           so t t_ctain #.
.beg(T  , so t t_ctain #.
.end(), cylearor c_)     De// (st!stener i->IsIerested i())
    im: re   Ithe listener->< ext uskerested i,ieusenht usnd to i   re: re   cttructorhe coten anelainnion s.
im: re*oturn intcher.
_.tchAnes(so t t_ctain #.
:  }
*ore}    *o//sstener->< "noich mu ex"  }
im: Unirb salPnts  so t t_ctain #.
listener);->ream* ()     *o//sstener->< "no en thso t t"     De//SingMatchResultListener : ten a_stener i    De  nst Maol Match r =ntcher.
_.tchAndExplain(T so t t_ctain #.
li                                                  &ten a_stener i     *o//Pnts IfNotEmpty(ten a_stener i.r(); listener);->ream* ()     *o//turn intcher  }
*o
  vivotate:
  //bonst MaCylearor chcylearor c_    *onst MatcherIn>cst Mastd::osveio c<LhsVue i>&>otcher.
_}    reEST_DISALLOW_ASCOPY_AND_SIGN_(napl<F
  }

}  /otate:
  //nst MaCylearor chcylearor c_    nst MaCoain #.
tcherInotcher.
_}    EST_DISALLOW_ASSIGN_(naWn tSo t tBytcherIn
};

// Anplementats Pnteewise(tueme_tcher.
, rh _ctain #.
:.  pueme_tcher.
n Matt beb hgble  oaomauefrlyncaenx betchAnIn>pueme>nst MaT1&a nst M/ The2&>o>,oen
.usT1 m MaT2aa.use peae Ts, meementats ithe veLHS
   cttin #.
 d
/it T>RHS cttin #.
 sponeiol rly./mplate <typename T>
uemeMcher.
, pename T>RhsCtain #.
  ass MainteewisetcherIn    blic:
  vimavef GMternal::stStlCtain #.
View<RhsCtain #.
 >RhsView; exmavef GMpename T>RhsView::aena RhsStlCtain #.
; exmavef GMpename T>RhsStlCtain #.
::"ue.
_pena>RhsVue i        Like Coain #.
Eqasw amak hgeaopyf "Erhs ithllswoe veementats it      itaa.usmodifd l afana ts hetcher.
o excam*ted  exinteewisetcherIn.nst MaTuemeMcher.
& tueme_tcher.
, nst MaRhsCtain #.
&nrh )     : imtueme_tcher.
_(tueme_tcher.
 , rh _(RhsView::Ctpy rh :) 
      matckesarur o  peer tuesn't maieru  tiio  ts heass Mamplate <   re NOah th
anstrui caferences ipena  ex: (id D)mp tg a::StioncA M roTenaEq<RhsCtain #.
ai        EST_DIREMOVE_REFERENCE_AND_CON_DI(RhsCtain #.
)>()  }

  /implate <typename T>LhsCtain #.
  Maerator catchAn<T>LhsCtain #.
  const {
    return intcs tcher<T w mapl>:>LhsCtain #.
  tueme_tcher.
_, rh _))  }

  /implate <typename T>LhsCtain #.
  Manss Mapl>: public MatcherDeterface<T>LhsCtain #.
      rblic:
  ex//mavef GMternal::stStlCtain #.
View<i         EST_DIREMOVE_REFERENCE_AND_CON_DI(LhsCtain #.
)> LhsView; ex//mavef GMpename T>LhsView::aena LhsStlCtain #.
; ex 
mavef GMpename T>LhsView::nstru_ferences 
LhsStlCtain #.
Rerences };ex 
mavef GMpename T>LhsStlCtain #.
::"ue.
_pena>LhsVue i    re NOWeeps M e liLHSn"ue.
od
/it T>RHS "ue.
o oae coten antcher.
 by   re NOferences asdsit pynmagu Naeectnsi sieoeaopy.  Wustt bee iseueme   re NO tead of "Epair n
.u,a atmarair c
 t reholdererences sn(C++e98,   re NO20.2.2 [lib.rairs]). ex 
mavef GMstd::ostr1ostueme>nst MaLhsVue i&, nst MaRhsVue i&>aInr itcherInArg       pl>:.nst MaTuemeMcher.
& tueme_tcher.
, nst MaRhsStlCtain #.
&nrh )     :      tono_tueme_tcher.
_eholds matonory.phicarb sn isethe lituemeatcher.
      :   : tono_tueme_tcher.
_(SafttcherInCast>Inr itcherInArg  tueme_tcher.
) ,i          rh _(rh : 

  vivirtual void DescribeTo(::std::ostream* os) const = {     : s << "nocttin #sn"< "nrh _ re i; i           "no lue,
s,oen
.usea r "ue.
od
/iits corsponsidg malue,
 ith"  }
im: Unirb salPnts In>shsStlCtain #.
>::Pnts  rh _,a);
  }
  : s << "noo"  }
im: tono_tueme_tcher.
_.scribeTo(os);
    *o
 vivirtual void DescribeTogationTo(::std::ostream* os) const {
    im: s << "noesn't macttin #mampctlyn"< "nrh _ re i; i           "no lue,
s,oo
octain #sty-"ue.
oxtyt se coindex i"i           "no en
.usxod
/it T>i-thn"ue.
o me"  }
im: Unirb salPnts  rh _,a);
  }
  : s << "noo"  }
im: tono_tueme_tcher.
_.scribeTogationTo(os);
  }
*o
  vivirtual vool MatchAndExplain(T LhsCtain #.
hlhsai                                 tchResultListener* listener) const {
    rereLhsStlCtain #.
Rerences nlhs_stl_ctain #.
 =>LhsView::CttruRerences tlhs     *o  nst {
de i_eo cal v_re i =olhs_stl_ctain #.
.re i;     *o// (st cal v_re i != rh _.re i; )
    im: re*stener->< "noich mucttin #sn"< "n cal v_re i  "no lue,
s"  }
im:   turn infalse  }
*ore}  }
*orepename T>LhsStlCtain #.
::nstru_itator chleft =olhs_stl_ctain #.
.beg(T  ;i      pename T>RhsStlCtain #.
::nstru_itator chrighta= rh _.beg(T  ;i      r im(de i_eoi 0;
 oi !=  cal v_re i; ++i, ++left, ++right)
    im: recst MaInr itcherInArgn"ue.
_rair(*left, *right)     De//*o (stltener i->IsIerested i())
    im: re//SingMatchResultListener : ten a_stener i    De  //*o (st!tono_tueme_tcher.
_.tchAndExplain(T i                  "ue.
_rair, &ten a_stener i )
    im: re*oimsstener->< "noicer o  pe"ue.
orair ("  }
im:      aUnirb salPnts  *left, stener);->ream* ()     *o//re*oimsstener->< "no, "  }
im:      aUnirb salPnts  *right, stener);->ream* ()     *o//re*oimsstener->< "no)  ignndex #"< "ni  "no est makeher"    *o//re*oimPnts IfNotEmpty(ten a_stener i.r(); listener);->ream* ()     *o////////turn infalse  }
*oreeeee} }
*o:   } else
    im: *o*o (st!tono_tueme_tcher.
_.tchAnes("ue.
_rair))   *o////////turn infalse  }
*oreee} }
*o: }    De//turn inue i  }
*o
  vivotate:
  //bonst MatchRe<T>Inr itcherInArg  tono_tueme_tcher.
_    *onst MaRhsStlCtain #.
nrhs_     reEST_DISALLOW_ASSIGN_(napl<F
  }

}  /otate:
  //nst MaTuemeMcher.
 tueme_tcher.
_    nst MaRhsStlCtain #.
nrhs_     EST_DISALLOW_ASSIGN_(naPnteewisetcherIn
};

// AnHolds e lisogicacomm.
nao Coain #stcherInpl>: d
/ Ea rtcherInpl>:  mplate <typename T>Ctain #.
  ass foQu  tifd rtcherInpl>: public MatcherDeterface<T>Ctain #.
     blic:
  vimavef GMEST_DIREMOVE_REFERENCE_AND_CON_DI(Ctain #.
) RawCtain #.
; exmavef GMStlCtain #.
View<RawCtain #.
  View; exmavef GMpename T>View::aena StlCtain #.
; exmavef GMpename T>View::nstru_ferences 
StlCtain #.
Rerences };exmavef GMpename T>StlCtain #.
::"ue.
_pena>Ementat;  //mplate <typename T>Inr itcherInclexplicit MaQu  tifd rtcherInpl>:(Inr itcherInoten a_tcher.
)     : imten a_tcher.
_ i           mp tg a::SafttcherInCast>nst MaEmentat&>(ten a_tcher.
)) 

  vi ItChecks icetrIn  // It* Allnementats ithe vectain #.
akeher,M (sall_ementats_srould_tcher. // It* Anynementat ithe vectain #.
akeher
s,o (s!all_ementats_srould_tcher. //ol MatchAndExplain(Tpl>:.ol Maall_ementats_srould_tcherai                           Ctain #.
nctain #.
li                           tchResultListener* listener) const {
    reStlCtain #.
Rerences nstl_ctain #.
 =>View::CttruRerences tctain #.
:  }
*ode i_eoi 0;
  }
*or im(pename T>StlCtain #.
::nstru_itator chita= stl_ctain #.
.beg(T  ;i         ita!= stl_ctain #.
.end(); ++it, ++i)
    im: SingMatchResultListener : ten a_stener i    De  nst Maol Match res,=nten a_tcher.
_.tchAndExplain(T *it,a&ten a_stener i      *o// (sttch res,!=  ll_ementats_srould_tcher)
    im: re*stener->< "noicos<iementat #"< "nii                   "nttch res,? "etcher.s" :i"<esn't makeher"     *o//imPnts IfNotEmpty(ten a_stener i.r(); listener);->ream* ()     *o////turn in!all_ementats_srould_tcher  }
*ore} *ore} *oreturn inall_ementats_srould_tcher  }

  /ototteded:
*onst MatcherIn>cst MaEmentat&>nten a_tcher.
_     EST_DISALLOW_ASSIGN_(naQu  tifd rtcherInpl>:
};

// Anplementats Coain #s(ementat_tcher.
) f c e
peven ungument, /pena>Ctain #.
./ ThSymmeingcnao Ea rtcherInpl>:  mplate <typename T>Ctain #.
  ass foCoain #stcherInpl>: public MaQu  tifd rtcherInpl>:>Ctain #.
     blic:
  vimplate <typename T>Inr itcherInclexplicit MaCoain #stcherInpl>:(Inr itcherInoten a_tcher.
)     : imQu  tifd rtcherInpl>:>Ctain #.
 (ten a_tcher.
) 

  vi ItscribeTos ic the  hetcher.
oesn'. //rtual void DescribeTo(::std::ostream* os) const = {     s << "nocttin #sn thleaenx  Maementat  nato"  }
ime  h->ten a_tcher.
_.scribeTo(os);
  }

  v/itual void DescribeTogationTo(::std::ostream* os) const {
    ims << "noesn't macttin #manynementat  nato"  }
ime  h->ten a_tcher.
_.scribeTo(os);
  }

  v/itual vool MatchAndExplain(T Ctain #.
octain #.
ai                               tchResultListener* listener) const {
    return inu  h->tchAndExplain(Tpl>:.false,ectain #.
asstener);
  }

  votate:
  //EST_DISALLOW_ASSIGN_(naCoain #stcherInpl>:
};

// Anplementats Ea r(ementat_tcher.
) f c e
peven ungument, /pena>Ctain #.
./ ThSymmeingcnao Coain #stcherInpl>:  mplate <typename T>Ctain #.
  ass foEa rtcherInpl>: public MaQu  tifd rtcherInpl>:>Ctain #.
     blic:
  vimplate <typename T>Inr itcherInclexplicit MaEa rtcherInpl>:(Inr itcherInoten a_tcher.
)     : imQu  tifd rtcherInpl>:>Ctain #.
 (ten a_tcher.
) 

  vi ItscribeTos ic the  hetcher.
oesn'. //rtual void DescribeTo(::std::ostream* os) const = {     s << "noty gucttin #snementats e  ta"  }
ime  h->ten a_tcher.
_.scribeTo(os);
  }

  v/itual void DescribeTogationTo(::std::ostream* os) const {
    ims << "nocttin #snse coementat  nato"  }
ime  h->ten a_tcher.
_.scribeTogationTo(os);
  }

  viitual vool MatchAndExplain(T Ctain #.
octain #.
ai                               tchResultListener* listener) const {
    return inu  h->tchAndExplain(Tpl>:.ue i,ectain #.
asstener);
  }

  votate:
  //EST_DISALLOW_ASSIGN_(naEa rtcherInpl>:
};

// Anplementats rolyry.phicaCoain #s(ementat_tcher.
)  mplate <typename T>M> ass foCoain #stcherIn    blic:
  viplicit MaCoain #stcherIn(M m) imten a_tcher.
_ m) 

  vimplate <typename T>Ctain #.
  Maerator catchAn<T>Ctain #.
  const {
    return intcs tcher<T w maCoain #stcherInpl>:>Ctain #.
 (ten a_tcher.
_c)  }

  /otate:
  //nst MaMnten a_tcher.
_     EST_DISALLOW_ASSIGN_(naCoain #stcherIn
};

// Anplementats rolyry.phicaEa r(ementat_tcher.
)  mplate <typename T>M> ass foEa rtcherIn    blic:
  viplicit MaEa rtcherIn(M m) imten a_tcher.
_ m) 

  vimplate <typename T>Ctain #.
  Maerator catchAn<T>Ctain #.
  const {
    return intcs tcher<T w maEa rtcherInpl>:>Ctain #.
 (ten a_tcher.
_c)  }

  /otate:
  //nst MaMnten a_tcher.
_     EST_DISALLOW_ASSIGN_(naEa rtcherIn
};

// Anplementats Key(ten a_tcher.
) f c e
peven ungument, /rair pena   AnKey(ten a_tcher.
) tch res,aner::ospair whos<i'rst.
'nfield tch res
 NO tn a_tcher.
.  F imample, a Coain #s(Key(Ge(5))) n be
/fed to enkeherhat
tr r::osmap e
 tanttin #sn thleaenx  Maementat whos<ikeya ea>= 5  mplate <typename T>PairTena  ass foKeytcherInpl>: public MatcherDeterface<T>PairTena     blic:
  vimavef GMEST_DIREMOVE_REFERENCE_AND_CON_DI(PairTena) RawPairTena; exmavef GMpename T>RawPairTena::rst.
_pena>KeyTena;  //mplate <typename T>Inr itcherInclexplicit MaKeytcherInpl>:(Inr itcherInoten a_tcher.
)     : imten a_tcher.
_ i          mp tg a::SafttcherInCast>nst MaKeyTena&>(ten a_tcher.
)) 
 }

  vi/Returns a eruasiff 'key_"ue.
.rst.
'n(e
pekey) tch res,e coten antcher.
. viitual vool MatchAndExplain(T PairTena key_"ue.
ai                               tchResultListener* listener) const {
    reSingMatchResultListener : ten a_stener i    Denst Maol Match r,=nten a_tcher.
_.tchAndExplain(T key_"ue.
.rst.
li                                                      &ten a_stener i     *onst Maternal::stsingManelainnion s,=nten a_stener i.r();     *o (stelainnion s,!= "")
    im: *stener->< "noicos<irst.
afield  eay-"ue.
o"< "nelainnion s    *o
 viviturn intcher  }

  vi ItscribeTos ic the  hetcher.
oesn'. //rtual void DescribeTo(::std::ostream* os) const = {     s << "nos atmakeya nato"  }
imten a_tcher.
_.scribeTo(os);
  }

  v/ ItscribeTos ic the sundtionTosethe  hetcher.
oesn'. //rtual void DescribeTogationTo(::std::ostream* os) const {
    ims << "noesn't mave siaekeya nato"  }
imten a_tcher.
_.scribeTo(os);
  }

  votate:
  //nst MaMcherIn>cst MaKeyTena&>nten a_tcher.
_     EST_DISALLOW_ASSIGN_(naKeytcherInpl>:
};

// Anplementats rolyry.phicaKey(tcher.
_f c_key)  mplate <typename T>M> ass foKeytcherIn    blic:
  viplicit MaKeytcherIn(M m) imtcher.
_f c_key_ m) 

  vimplate <typename T>PairTena  Maerator catchAn<T>PairTena  const {
    return intcs tcher<T w maKeytcherInpl>:>PairTena  tcher.
_f c_key_c)  }

  /otate:
  //nst MaMntcher.
_f c_key_     EST_DISALLOW_ASSIGN_(naKeytcherIn
};

// Anplementats Pair(rst.
_tcher.
, senstd_tcher.
) f c e
peven ungument, /rair
 sitena,ah thits pwostcher.
s. SeT>Pair corction sobelow  mplate <typename T>PairTena  ass foPairtcherInpl>: public MatcherDeterface<T>PairTena     blic:
  vimavef GMEST_DIREMOVE_REFERENCE_AND_CON_DI(PairTena) RawPairTena; exmavef GMpename T>RawPairTena::rst.
_pena>Fst.
Tena; exmavef GMpename T>RawPairTena::senstd_aena SenstdTena;  //mplate <typename T>Fst.
Mcher.
, pename T>SenstdtcherInclexPairtcherInpl>:(Fst.
Mcher.
 rst.
_tcher.
, SenstdtcherIn senstd_tcher.
)     : imrst.
_tcher.
_ i            mp tg a::SafttcherInCast>nst MaFst.
Tena&>(rst.
_tcher.
) ,i        senstd_tcher.
_ i            mp tg a::SafttcherInCast>nst MaSenstdTena&>(senstd_tcher.
)) 
 }

  vi/RescribeTos ic the  hetcher.
oesn'. //rtual void DescribeTo(::std::ostream* os) const = {     s << "nos atmarst.
afield  nato"  }
imrst.
_tcher.
_.scribeTo(os);
    *os << "no, d
/ h atmasenstdafield  nato"  }
imsenstd_tcher.
_.scribeTo(os);
  }

  v/ ItscribeTos ic the sundtionTosethe  hetcher.
oesn'. //rtual void DescribeTogationTo(::std::ostream* os) const {
    ims << "nos atmarst.
afield  nato"  }
imrst.
_tcher.
_.scribeTogationTo(os);
  }
*os << "no,  c h atmasenstdafield  nato"  }
imsenstd_tcher.
_.scribeTogationTo(os);
  }

  vi/Returns a eruasiff 'a_rair.rst.
'ntch res,rst.
_tcher.
 d
/ 'a_rair.senstd'      tch res,senstd_tcher.
. viitual vool MatchAndExplain(T PairTena a_rairai                               tchResultListener* listener) const {
    re (st!stener i->IsIerested i())
    im:    Ithe listener->< ext uskerested i,ieusent mand to imcttructorhe c   im:    elainnion s.
im: return infst.
_tcher.
_.tcherIs(a_rair.rst.
) &&i             senstd_tcher.
_.tcherIs(a_rair.senstd
    *o
 viviSingMatchResultListener : fst.
_ten a_stener i    De (st!fst.
_tcher.
_.tcherdExplain(T a_rair.rst.
li                                        &fst.
_ten a_stener i))
    im: *stener->< "noicos<irst.
afield esn'ht ustcher"    *o//Pnts IfNotEmpty(fst.
_ten a_stener i.r(); listener);->ream* ()     *o//turn infalse  }
*o
 viviSingMatchResultListener : senstd_ten a_stener i    De (st!senstd_tcher.
_.tcherdExplain(T a_rair.senstdli                                         &senstd_ten a_stener i))
    im: *stener->< "noicos<isenstdafield esn'ht ustcher"    *o//Pnts IfNotEmpty(senstd_ten a_stener i.r(); listener);->ream* ()     *o//turn infalse  }
*o
 viviplain(TSuccess(fst.
_ten a_stener i.r(); lisenstd_ten a_stener i.r(); li                   stener i     *oturn inue i  }

  /otate:
  //id Deplain(TSuccess(nst Maternal::stsingMa& fst.
_elainnion sai                      nst Maternal::stsingMa& senstd_elainnion sai                      tchResultListener* listener) const {
    re*stener->< "noicos<ibo thfieldsstcher"    *o (stfst.
_elainnion s,!= "")
    im: *stener->< "no,oen
.usah<irst.
afield  eay-"ue.
o"< "nfst.
_elainnion s  }
*o
 vivi (stsenstd_elainnion s,!= "")
    im: *stener->< "no,o"    *o// (stfst.
_elainnion s,!= "")
    im: : *stener->< "nod
/ "    *o//} else
    im: *osstener->< "noicer o"    *o//}   im: *stener->< "nom terenstdafield  eay-"ue.
o"< "nsenstd_elainnion s  }
*o
 vi
  vinst MaMcherIn>cst MaFst.
Tena&>nfst.
_tcher.
_; vinst MaMcherIn>cst MaSenstdTena&> senstd_tcher.
_     EST_DISALLOW_ASSIGN_(naPairtcherInpl>:
};

// Anplementats rolyry.phicaPair(rst.
_tcher.
, senstd_tcher.
)./mplate <typename T>Fst.
Mcher.
, pename T>SenstdtcherInclass foPairtcherIn    blic:
  viPairtcherIn(Fst.
Mcher.
 rst.
_tcher.
, SenstdtcherIn senstd_tcher.
)     : imrst.
_tcher.
_ rst.
_tcher.
), senstd_tcher.
_(senstd_tcher.
) 

  vimplate <typename T>PairTena  Maerator catchAn<T>PairTena   const {
    return intcs tcher<T    im: *ow maPairtcherInpl>:>PairTena  i            rst.
_tcher.
_, senstd_tcher.
_c)  }

  /otate:
  //nst MaFst.
Mcher.
 rst.
_tcher.
_; vinst MaSenstdtcherIn senstd_tcher.
_     EST_DISALLOW_ASSIGN_(naPairtcherIn
};

// Anplementats EmentatsAra()nd
/ EmentatsAraArray()  mplate <typename T>Ctain #.
  ass foEmentatsAratcherInpl>: public MatcherDeterface<T>Ctain #.
     blic:
  vimavef GMEST_DIREMOVE_REFERENCE_AND_CON_DI(Ctain #.
) RawCtain #.
; exmavef GMternal::stStlCtain #.
View<RawCtain #.
  View; exmavef GMpename T>View::aena StlCtain #.
; exmavef GMpename T>View::nstru_ferences 
StlCtain #.
Rerences };exmavef GMpename T>StlCtain #.
::"ue.
_pena>Ementat;  // ItCttructors,e cotcher.
 fromtmasequces immeementatslue,
seor // Itementatstcher.
s. //mplate <typename T>InputI .
  MaEmentatsAratcherInpl>:(InputI .
 rst.
,>InputI .
 ss t)
    imwhilestfst.
a!= ls t)
    im: tcher 
s_.push_back tcherInCast>nst MaEmentat&>(*fst.
++))  }
*o
 vi
  vi/RescribeTos ic the  hetcher.
oesn'. //rtual void DescribeTo(::std::ostream* os) const = {      (stcount() == 0)
    im: * << "no exempty"    *o} else
 (stcount() == 1)
    im: * << "noh at1oementat  nato"  }
im: tcher 
s_[0].scribeTo(os);
    *o
 else
    im: * << "noh at"< "nEmentatstcount())  "no en
.u\n"  }
im: r im(de i_eoi 0;
 oi != count(); ++i)
    im: ims << "nopmentat #"< "ni< "noo"  }
im: : tcher 
s_[i].scribeTo(os);
    *o     (sti +t1o< count()) {i          s << "no,\n"  }
im:   } }
*o: } *o: } }

  v/ ItscribeTos ic the sundtionTosethe  hetcher.
oesn'. //rtual void DescribeTogationTo(::std::ostream* os) const {
    im (stcount() == 0)
    im: * << "no et maempty"    *oreturn i  }
*o
  }
*os << "noesn't mave si"< "nEmentatstcount())  "no,  c\n"  }
imr im(de i_eoi 0;
 oi != count(); ++i)
    im: s << "nopmentat #"< "ni< "noo"  }
im: tcher 
s_[i].scribeTogationTo(os);
  }
*o   (sti +t1o< count()) {i        s << "no,  c\n"  }
im: } *o: } }

  v/itual vool MatchAndExplain(T Ctain #.
octain #.
ai                               tchResultListener* listener) const {
    re Thebeworkaah thream* -like "ctain #.
s"asw amuenx  ly walk   re Ththroughoe veementats ith  Maps M.  }
*onst Maol Mastener) _kerested i,=nstener i->IsIerested i()     *o   elainnion ss[i]  eae veelainnion s,ethe lipmentat  ignndex i.
im: std::osveio c<ternal::stsingMa> elainnion sstcount()); viviSilCtain #.
Rerences nstl_ctain #.
 =>View::CttruRerences tctain #.
:  }
*opename T>StlCtain #.
::nstru_itator chita= stl_ctain #.
.beg(T  ;i    de i_eoampl_p s,=n
  }
*ool Matistcher_fouef =>false *o   He siw afouef aatistcheredeementat yet?    *o   Gohthroughoe veementats d
/ tcher 
s ithrairs, untiliw area r   re ThtheiendimmeeitrInoe veementats  c e
petcher 
s,  c untiliw afief a   re Thtistcher. }
imr im(; ita!= stl_ctain #.
.end() &&oampl_p s,!= count(); ++it, ++ampl_p s) {i      ol Match r *o   Do she vecurncemaementatstcherhe vecurncematcher 
? }
*o   (ststener) _kerested i) {i        SingMatchResultListener : s  }
im: : tcher =ntcher.
s_[ampl_p s].tchAndExplain(T *it,a&;
    *o    elainnion ss[ampl_p s]a= s.r();     *o//} else
    im: *otcher =ntcher.
s_[ampl_p s].tchAnes *it:  }
*ore}    *o// (st!tchAn) {i        tistcher_fouef =>ue i  }
*o:   break  }
im: } *o: } }
:    Ithtistcher_fouef ia erua, 'ampl_p s'  eae venndex ethe litistcher.  }
:    Findhhow tc nuementats e no cal vectain #.
ah a.  Wusaid D }
:    c
llgManre i;  s.t. ts heaodeuworksrr imream* -like "ctain #.
s"   re Thth igent maeine anre i; .i    de i_eo cal v_count =>ampl_p s; }
imr im(; ita!= stl_ctain #.
.end(); ++it)
    im: ++ cal v_count  }
*o
  }
*o (st cal v_count != count())
    im:    T lipmentat count esn't makeher.  Ithe vectain #.
  exempty,   im:    trIne''ht and to imelain(Tmanymrg M  atGooglesMock alam*dy   im:    pnts eae veemptyoctain #.
   OtrInwiseiw ajuenxnd to imshow   im:    how tc nuementats e n no cal vly e n. }
*o   (ststener) _kerested i &&ot cal v_count != 0 )
    im: re*stener->< "noich muh at"< "nEmentatst cal v_count)  }
im: } *o: //turn infalse  }
*o
  }
*o (sttistcher_fouef)
    im:    T lipmentat count tch res, butee veelpl_p s-thnpmentat esn't makeher. }
*o   (ststener) _kerested i) {i        *stener->< "noicos<iementat #"< "nampl_p s, "no esn't matcher"    *o////Pnts IfNotEmpty(elainnion ss[ampl_p s]listener);->ream* ()     *o//} *o: //turn infalse  }
*o
  }
*o   Everytementatstcher.shits eectedion s.  Wusnd to imelain(Tmwhy   re NO(e
peobvuousu  Ms n be
/fskipp b .i     (ststener) _kerested i) {i      ol Mareason_pnts ed =>false  }
*orer im(de i_eoi 0;
 oi != count(); ++i)
    im: imnst Maternal::stsingMa& s =>amainnion ss[i]    *o     (st!s.empty())
    im: re*o (streason_pnts ed)
    im: re*oimsstener->< "no,\nd l "  }
im:     }
im: re*oimsstener->< "noicos<iementat #"< "ni, "no tch res, "< "ns  }
im:     reason_pnts ed =>ue i  }
*o:   } }
*o: } *o: } }
*oturn inue i  }

  /otate:
  //stioncaMdibaga Ementatstde i_eocount)
    return intdibaga()  "ncount  "ntcount == 1,? "eementat" :i"<ementats"
  }

  vide i_eocount() nst {
 oturn intcher 
s_.re i;  

  vistd::osveio c<McherIn>cst MaEmentat&>n>ntcher 
s_     EST_DISALLOW_ASSIGN_(naEmentatsAratcherInpl>:
};

// AnCtaneiol ityotchrix eth(ementats Xntcher 
s)a ts<ementat-majja ord o   AnIniti vly, e n no  not aedges./ ThUs<iNextGraph(.o beitatoreu rb nall p ssgble edge nstfigurion ss./ ThUs<iRd lome i;   beger->oreua rd lom edge nstfigurion s. ass foEST_DIAPI_ tchReMchrix    blic:
  vitchReMchrixtde i_eonum_ementats, de i_eonum_tcher 
s) }
*o: :onum_ementats_(num_ementats li        num_tcher 
s_(num_tcher 
s)a }
im: : tcher d_(num_ementats_* num_tcher 
s_, 0)
    
  vide i_eoLhsSe i;  nst {
 oturn innum_ementats_; } }
de i_eoRhsSe i;  nst {
 oturn innum_tcher 
s_  } }
ol MaHasEdge(de i_eoilhsa/de i_eoirh ) nst {
    return intcher d_[SpaceIndex(ilhsa/irh )] == 1  }

 //id DeSetEdge(de i_eoilhsa/de i_eoirh ,
ol Mab)
    retcher d_[SpaceIndex(ilhsa/irh )] = b,? 1 :o0  }

  vi/ReTam*tg M e vectaneiol ityotchrix  atma(LhsSe i; *RhsSe i; )-bieonumb.
ai     addat1otoeet ignumb.
;eturn is>falseo (sincrentatg M e vegraphhleft iti     empty. //ol MaNextGraph(.;  v/id DeRd lome i; ;  //stngManDebugSingMa const {   /otate:
  //se i_eoSpaceIndex(de i_eoilhsa/de i_eoirh ) nst {
    return inilhs * num_tcher 
s_ +oirh   }

  vide i_eonum_ementats_; vide i_eonum_tcher 
s_        Ea r ementat iex
anharaternaptur to atol M.he ty e noso c to atm      fleht n to rray ts<lhs-majja ord o,ee is'SpaceIndex()'otoeeranste <      a (ilhsa/irh )otchrix coordinoreuterbean jffsen./vistd::osveio c<nhar>etcher d_};

//mavef GMstd::ospair<de i_ea/de i_e>aEmentattcherInPair;/mavef GMstd::osveio c<EmentattcherInPair>aEmentattcherInPairs
// Anturns a matcximum bipartitasmeherg M f c e
peoneiifd l graphh'g'./ The twmeherg M is spptusent to atmaveio c eth{ementat/ tcher.
}hrairs.
EST_DIAPI_ EmentattcherInPairs
FindMaxBipartitaMeherg M(nst MaMcherMchrix& m);

EST_DIAPI_ ol MaFindPairg M(nst MaMcherMchrix& tchrixai                            tchResultListener* listener) c
// AnUnmavef blswoass fof c ilementatg M Unord oedEmentatsAra.  By/ Anputtg M sogicaet i''ht usoneiifdco oae coementat  ena>h
.u,awen Maoeduce binarfoblo taaef increlswoaompilion s,oneed  ass foEST_DIAPI_ Unord oedEmentatsAratcherInpl>:Base
   ototteded:
*o AnAtveio c ethtcher.
oecribeTo
s,  ne r imaa r ementat mcher.
. vi   Do sht usowthe veecribeTo
sot 
/it us n be
/fed to  ly wn the v
// Itementatstcher.
s e no live .i  mavef GMstd::osveio c<nst MaMcherInscribeToeterface<T*>aMcherInscribeToeVec;  v/ ItscribeTos ts heUnord oedEmentatsArantcher.
. viid DescribeTo(:pl>:(std::ostream* os) const {;  v/ ItscribeTos tssundtionTosethe  heUnord oedEmentatsArantcher.
. viid DescribeTogationTo(opl>:(std::ostream* os) const {;  v/ol MaVerifyAllEmentatsAtdtcherInsAratcherId(i      cst Mastd::osveio c<singMa>&tementat_pnts outsai      nst MaMcherMchrix& tchrixai      tchResultListener* listener) const {;  v/McherInscribeToeVec&etcher.
_ecribeTo
s()
    return intcher 
_ecribeTo
s_  }

  vidtioncaMdibaga Ementatstde i_eon)
    return intdibaga()  "nn, "no ementat"  "ntn == 1,? "" :i"s"
  }

  votate:
  //McherInscribeToeVecntcher 
_ecribeTo
s_     EST_DISALLOW_ASSIGN_(naUnord oedEmentatsAratcherInpl>:Base
};

// Anplementats unord oedaEmentatsAraaaef unord oedaEmentatsAraArray  mplate <typename T>Ctain #.
  ass foUnord oedEmentatsAratcherInpl>:
im: sublic MatcherDeterface<T>Ctain #.
 ai      blic MaUnord oedEmentatsAratcherInpl>:Base
   olic:
  vimavef GMEST_DIREMOVE_REFERENCE_AND_CON_DI(Ctain #.
) RawCtain #.
; exmavef GMternal::stStlCtain #.
View<RawCtain #.
  View; exmavef GMpename T>View::aena StlCtain #.
; exmavef GMpename T>View::nstru_ferences 
StlCtain #.
Rerences };exmavef GMpename T>StlCtain #.
::nstru_itator chStlCtain #.
CttruItator c};exmavef GMpename T>StlCtain #.
::"ue.
_pena>Ementat;  // ItCttructors,e cotcher.
 fromtmasequces immeementatslue,
seor // Itementatstcher.
s. //mplate <typename T>InputI .
  MaUnord oedEmentatsAratcherInpl>:(InputI .
 rst.
,>InputI .
 ss t)
    imr im(; fst.
a!= ls t; ++rst.
)     im: tcher 
s_.push_back tcherInCast>nst MaEmentat&>(*fst.
)     *o//tcher.
_ecribeTo
s().push_back tcher 
s_.back ).GetscribeToe())  }
*o
 vi
  vi/RescribeTos ic the  hetcher.
oesn'. //rtual void DescribeTo(::std::ostream* os) const = {     turn inUnord oedEmentatsAratcherInpl>:Base::scribeTo(:pl>:();
  }

  v/ ItscribeTos ic the sundtionTosethe  hetcher.
oesn'. //rtual void DescribeTogationTo(::std::ostream* os) const {
    imturn inUnord oedEmentatsAratcherInpl>:Base::scribeTogationTo(opl>:();
  }

  viitual vool MatchAndExplain(T Ctain #.
octain #.
ai                               tchResultListener* listener) const {
    reSilCtain #.
Rerences nstl_ctain #.
 =>View::CttruRerences tctain #.
:  }
*ostd::osveio c<singMa>tementat_pnts outs  }
*otchReMchrix tchrix = Al::yzeEmentatstdtl_ctain #.
.beg(T  ,i                                         stl_ctain #.
.end(),i                                         &ementat_pnts outsai                                         stener i      *ocst {
de i_eo cal v_count =>tchrix.LhsSe i;     *o (st cal v_count == 0 &&otcher 
s_.empty())
    im: turn inue i  }
*o
   *o (st cal v_count !=ntcher.
s_.re i; )
    im:    T lipmentat count esn't makeher.  Ithe vectain #.
  exempty,   im:    trIne''ht and to imelain(Tmanymrg M  atGooglesMock alam*dy   im:    pnts eae veemptyoctain #.
  OtrInwiseiw ajuenxnd to imshow   im:    how tc nuementats e n no cal vly e n. }
*o   (st cal v_count != 0 &&oltener i->IsIerested i())
    im: re*stener->< "noich muh at"< "nEmentatst cal v_count)  }
im: } *o: //turn infalse  }
*o
  }
*oturn inVerifyAllEmentatsAtdtcherInsAratcherId(ementat_pnts outsai                                                  tchrixaistener) co&&i           FindPairg M(tchrixaistener) c  }

  votate:
  //mavef GMstd::osveio c<McherIn>cst MaEmentat&>n>nMcherInVec;  v/mplate <typename T>EmentatI .
  MatchReMchrix Al::yzeEmentatstEmentatI .
uemen_rst.
,>EmentatI .
uemen_ls tai                              std::osveio c<singMa>*tementat_pnts outsai                              tchResultListener* listener) const {
    reementat_pnts outs->clea);     *ostd::osveio c<nhar>edid_tcher  }
*ode i_eonum_ementats 0;
  }
*or im(;uemen_rst.
 != emen_ls t; ++num_ementats, ++emen_rst.
)
    im:  (stltener i->IsIerested i())
    im: reementat_pnts outs->push_back Pnts ToSingMa *emen_rst.
))  }
im: } *o: //r im(de i_eoirhs 0;
 oirhs !=ntcher.
s_.re i; ; ++irh : 
   im: redid_tcher.push_back tcherIs tcher 
s_[irh ]) *emen_rst.
))  }
im: } *o: 
  }
*otchReMchrix tchrix(num_ementats, tcher.
s_.re i; )    *ostd::osveio c<nhar>::nstru_itator chdid_tcher_itat 0;did_tcher.beg(T  ;i    r im(de i_eoilhs 0;
 oilhs !=nnum_ementats; ++ilh : 
   im: r im(de i_eoirhs 0;
 oirhs !=ntcher.
s_.re i; ; ++irh : 
   im: retchrix.SetEdge(ilhsa/irh , *did_tcher_itat++ != 0   }
im: } *o: } }
: turn intchrix  }

  viMcherInVecntcher 
s_     EST_DISALLOW_ASSIGN_(naUnord oedEmentatsAratcherInpl>:
};

// AnFctio c r ime is(Tmeransf imTueme./ ThPfac imsatcherInCast>Target> oTmans(Tputngument, /ethc nupena  mplate <typename T>
arget> stctoraCastAtdApnamderansf im 
   mplate <typename T>Arg  viMcherIn>Target> orator c. .nst MaArg& aconst {
    return intcherInCast>Target>(ac  }

 

// Anplementats Unord oedEmentatsAra. mplate <typename T>McherInTueme  ass foUnord oedEmentatsAratcherIn    blic:
  viplicit MaUnord oedEmentatsAratcherIn(nst MaMcherInTueme&ngums) }
*o: :otcher 
s_(gums) 

  vimplate <typename T>Ctain #.
  Maerator catchAn<T>Ctain #.
  const {
    remavef GMEST_DIREMOVE_REFERENCE_AND_CON_DI(Ctain #.
) RawCtain #.
; exexmavef GMpename T>ternal::stStlCtain #.
View<RawCtain #.
 ::aena View; ex//mavef GMpename T>View::"ue.
_pena>Ementat; ex//mavef GMstd::osveio c<McherIn>cst MaEmentat&>n>nMcherInVec; }
*otchReInVecntcher 
s; }
*otcher.
s.tuserve:std::ostr1ostueme_re i<McherInTueme ::"ue.
   }
imeransf imTuemeVue is(CastAtdApnamderansf im>nst MaEmentat&>(), tcher.
s_ai                         std::osback_inM roIn(tcher 
s)     *oturn intcs tcher<T w maUnord oedEmentatsAratcherInpl>:>Ctain #.
  i                           tcher.
s.beg(T  , tcher.
s.end())
  }

  votate:
  //nst MaMcherInTuemeatcher.
s_  }
EST_DISALLOW_ASSIGN_(naUnord oedEmentatsAratcherIn
};

// Anplementats EmentatsAra. mplate <typename T>McherInTueme  ass foEmentatsAratcherIn    blic:
  viplicit MaEmentatsAratcherIn(nst MaMcherInTueme&ngums) :otcher 
s_(gums) 

  vimplate <typename T>Ctain #.
  Maerator catchAn<T>Ctain #.
  const {
    remavef GMEST_DIREMOVE_REFERENCE_AND_CON_DI(Ctain #.
) RawCtain #.
; exexmavef GMpename T>ternal::stStlCtain #.
View<RawCtain #.
 ::aena View; ex//mavef GMpename T>View::"ue.
_pena>Ementat; ex//mavef GMstd::osveio c<McherIn>cst MaEmentat&>n>nMcherInVec; }
*otchReInVecntcher 
s; }
*otcher.
s.tuserve:std::ostr1ostueme_re i<McherInTueme ::"ue.
   }
imeransf imTuemeVue is(CastAtdApnamderansf im>nst MaEmentat&>(), tcher.
s_ai                         std::osback_inM roIn(tcher 
s)     *oturn intcs tcher<T w maEmentatsAratcherInpl>:>Ctain #.
  i                           tcher.
s.beg(T  , tcher.
s.end())
  }

  votate:
  //nst MaMcherInTuemeatcher.
s_  }
EST_DISALLOW_ASSIGN_(naEmentatsAratcherIn
};

// Anplementats Unord oedEmentatsAraArray()  mplate <typename T>T  ass foUnord oedEmentatsAraArraytcherIn    blic:
  viUnord oedEmentatsAraArraytcherIn() 

  vimplate <typename T>I .
  MaUnord oedEmentatsAraArraytcherIn(I .
 rst.
,>I .
 ss t) }
*o: :otcher 
s_(rst.
,>ss t)
 
  vimplate <typename T>Ctain #.
  Maerator catchAn<T>Ctain #.
  const {
    return intcs tcher<T i        w maUnord oedEmentatsAratcherInpl>:>Ctain #.
  tcher 
s_.beg(T  ,i                                                       tcher.
s_.end())
  }

  votate:
  //std::osveio c<T>ntcher 
s_     EST_DISALLOW_ASSIGN_(naUnord oedEmentatsAraArraytcherIn
};

// Anplementats EmentatsAraArray()  mplate <typename T>T  ass foEmentatsAraArraytcherIn    blic:
  vimplate <typename T>I .
  MaEmentatsAraArraytcherIn(I .
 rst.
,>I .
 ss t) :otcher 
s_(rst.
,>ss t)
 
  vimplate <typename T>Ctain #.
  Maerator catchAn<T>Ctain #.
  const {
    return intcs tcher<T w maEmentatsAratcherInpl>:>Ctain #.
  i        tcher 
s_.beg(T  , tcher.
s_.end())
  }

  votate:
  //cst Mastd::osveio c<T>ntcher 
s_     EST_DISALLOW_ASSIGN_(naEmentatsAraArraytcherIn
};

// Anturns a e veecribeponTosr imahtcher.
oecne adme g M e veMATCHER*()n Matacrooen
.usah<ier t-supiciadmecribeponTosstngMan ex"",o (n Ma'ndtionTo'  eafalse *otrInwiseirurns a e veecribeponTosethe ln MandtionTosethe antcher.
.  'earom_"ue.
s'octain #sty-ltensethstngMas
 NOet iga.use pepnts -outsethe antcher.
's earometers.
EST_DIAPI_ stngManF imattcherInDcribeponTo.ol MandtionTo,i                                           cst Manhar*/tcher.
_me T,i                                           cst MaSingMas& earom_"ue.
s    }:    me Tspace>ternal::// AnEmentatsAraArray(rst.
,>ss t)/ AnEmentatsAraArray(poterna,ocount)/ AnEmentatsAraArray( rray)/ AnEmentatsAraArray(veio c)/ AnEmentatsAraArray({ e1, e2, ..., en })/ A/ The twEmentatsAraArray()orction ss e nolike EmentatsAra(... , except
 NOet igt ty e noven ung homoger-oususequces itorhInoe an takgManea r  Itementats atmarction sogument, .he tusequces in be
/fsneiifd l  atmt
tr  rray,tmaroternaaaef count,tmaveio c,mans(Titi ve ir-lten,  c mt
tr STL itator chrange. Inmaa r ethe aswoaases, ah<iend olygManrequces 
   c be
/feitrInomasequces immelue,
seoromasequces immetcher.
s.  A/ ThAllnc imsammeEmentatsAraArray()omak hgeaopyf "Ee vennputntcher.
osequces .
 mplate <typename T>I .
  inle anternal::stEmentatsAraArraytcherIn< ex//maveme T>std::ositator c_traits<I .
 ::"ue.
_pena>
EmentatsAraArray(I .
 rst.
,>I .
 ss t) {
//mavef GMpename T>std::ositator c_traits<I .
 ::"ue.
_pena T  }
turn iniernal::stEmentatsAraArraytcherIn<T>(rst.
,>ss t)};

 mplate <typename T>T  inle anternal::stEmentatsAraArraytcherIn<T>eEmentatsAraArray(   *ocst {
T* poterna,ode i_eocount)
    turn inEmentatsAraArray(poterna,oroternaa+ count)  

 mplate <typename T>T,ode i_eoN  inle anternal::stEmentatsAraArraytcherIn<T>eEmentatsAraArray(   *ocst {
T (& rray)[N])
    turn inEmentatsAraArray( rray,tN)  

 mplate <typename T>T,opename T>A  inle anternal::stEmentatsAraArraytcherIn<T>eEmentatsAraArray(   *ocst {
std::osveio c<T,>A &avei)
    turn inEmentatsAraArray(vei.beg(T  , vei.end())  

 #iGMEST_DILANG_CXX11 mplate <typename T>T  inle anternal::stEmentatsAraArraytcherIn<T>
EmentatsAraArray(std::osiTiti ve ir_sten<T>exs)
    turn inEmentatsAraArray(xs.beg(T  , xs.end())  

#end (n/ AnUnord oedEmentatsAraArray(rst.
,>ss t)/ AnUnord oedEmentatsAraArray(poterna,ocount)/ AnUnord oedEmentatsAraArray( rray)/ AnUnord oedEmentatsAraArray(veio c)/ AnUnord oedEmentatsAraArray({ e1, e2, ..., en })/ A/ The twUnord oedEmentatsAraArray()orction ss e nolike/ AnEmentatsAraArray(... , buteallow tcterg M e veementats ithc nuord o  mplate <typename T>I .
  inle anternal::stUnord oedEmentatsAraArraytcherIn< ex//maveme T>std::ositator c_traits<I .
 ::"ue.
_pena>
Unord oedEmentatsAraArray(I .
 rst.
,>I .
 ss t) {
//mavef GMpename T>std::ositator c_traits<I .
 ::"ue.
_pena T  }
turn iniernal::stUnord oedEmentatsAraArraytcherIn<T>(rst.
,>ss t)};

 mplate <typename T>T  inle anternal::stUnord oedEmentatsAraArraytcherIn<T>
Unord oedEmentatsAraArray(cst {
T* poterna,ode i_eocount)
    turn inUnord oedEmentatsAraArray(poterna,oroternaa+ count)  

 mplate <typename T>T,ode i_eoN  inle anternal::stUnord oedEmentatsAraArraytcherIn<T>
Unord oedEmentatsAraArray(cst {
T (& rray)[N])
    turn inUnord oedEmentatsAraArray( rray,tN)  

 mplate <typename T>T,opename T>A  inle anternal::stUnord oedEmentatsAraArraytcherIn<T>
Unord oedEmentatsAraArray(cst {
std::osveio c<T,>A &avei)
    turn inUnord oedEmentatsAraArray(vei.beg(T  , vei.end())  

 #iGMEST_DILANG_CXX11 mplate <typename T>T  inle anternal::stUnord oedEmentatsAraArraytcherIn<T>
Unord oedEmentatsAraArray(std::osiTiti ve ir_sten<T>exs)
    turn inUnord oedEmentatsAraArray(xs.beg(T  , xs.end())  

#end (n/ An_ iex
atcher.
oet igtcher.smanymrg M ethc nupena   A/ The iexecne ion so eafe anas:  A/ Th  1.he tuC++estaefard ratmits e g M e veme T>_ ithc me Tspace>et i/ Th      ext use veglobal me Tspace>orostd::./ Th  2.he tuAnymrg MtcherIn ass foh atno dat
atemb.
oo
octastctor c,/ Th     sbeit's OKo imcam*tveglobal variablessethe  hepena   A   3. c-style h atmpprovedimmee g M _ ithe  heaase.
nst Maternal::stAnymrg MtcherIn _ = {};/ AnCam*tvex
atcher.
oet igtcher.smanyn"ue.
o mee
peven unpena T  mplate <typename T>T  inle antcherIn<T>eA() 
eturn intcs tcher<T w maternal::stAnytcherInpl>:>T>()  

   AnCam*tvex
atcher.
oet igtcher.smanyn"ue.
o mee
peven unpena T  mplate <typename T>T  inle antcherIn<T>eAn() 
eturn inA>T>() 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.smanymrg M equal  imx   A Note:  (se peparometerammeEq() w
.usdeassc to atcst {
T&,eEq("foo")/ Anwouldt mactmpila  mplate <typename T>
  inle anternal::stEqtcherIn<T>eEq(T x) 
eturn internal::stEqtcherIn<T>(x) 

   AnCttructors,antcherIn<T>efromtma'"ue.
'o meeena T  he tuctastctored
   tch rergtcher.smanyn"ue.
oet i''hequal  im'"ue.
'  mplate <typename T>
  tcherIn<T>::tcher<T Tn"ue.
) 
e*e  he=eEq("ue.
  

   AnCam*tvex
atonory.phicatcher.
oet igtcher.smanymrg M ah theena Lhs
 NOaef equal  imrha.  Aier tgtcyxnd to ime ise  heiasteadammeEq(... 
 NO tuord o  imresol sianu rb loadg M  mbiguity.  A/ TheavefEq<T>(x)  exjuenxgeaonn uitatsshort-haef f catchAn<T>T>(Eq(x) 
 NO catchAn<T>T>(x , butery. areadableoe an t liseht r.  A/ ThWtuctuld eine anremisscatonory.phicatcher.
fof c otrInactmparisot
tr eratorn ss (e.g.heavefL
,>eavefGe, d
/ etc , butedeaid tot useo do
 NO t yeto attcos<ie noed tomuchhlessoe an Eq() ithrraionce.  Aier t
   c bealways writastchAn<T>T>(Lt(5))seo beiplicit Maaboutee veeena,/ Thf imample,   mplate <typename T>Lh , pename T>Rhs  inle antcherIn<Lh >heavefEq(cst {
Rhs& rh : 
 turn inEq(rh : 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.smanymrg M >=mx  mplate <typename T>Rhs  inle anternal::stG tcher<T<Rhs  Ge(Rhs x) 
 }
turn iniernal::stG tcher<T<Rhs (x) 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.smanymrg M >mx  mplate <typename T>Rhs  inle anternal::stGttcher<T<Rhs  Gt(Rhs x) 
 }
turn iniernal::stGttcher<T<Rhs (x) 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.smanymrg M <=mx  mplate <typename T>Rhs  inle anternal::stL tcher<T<Rhs  Le(Rhs x) 
 }
turn iniernal::stL tcher<T<Rhs (x) 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.smanymrg M <mx  mplate <typename T>Rhs  inle anternal::stLttcher<T<Rhs  Lt(Rhs x) 
 }
turn iniernal::stLttcher<T<Rhs (x) 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.smanymrg M !=mx  mplate <typename T>Rhs  inle anternal::stN tcher<T<Rhs  Ne(Rhs x) 
 }
turn iniernal::stN tcher<T<Rhs (x) 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.smany NULLoroterna. inle anPolyry.phictcher<T<iernal::stIsNulltcherIn > IsNull() 
 }
turn intcs Polyry.phictcher<T(iernal::stIsNulltcherIn())  

  AnCam*tvex
arolyry.phicatcher.
oet igtcher.smany non-NULLoroterna.  The iex heaonn uitats atNot(NULL) esn't mactmpilaO(e
pectmpilar
 sitrg ksOet igt aeoamptussn so eactmpari M  oroternaaah thainierng.
)./inle anPolyry.phictcher<T<iernal::stNotNulltcherIn > NotNull() 
 }
turn intcs Polyry.phictcher<T(iernal::stNotNulltcherIn())  

  AnCam*tvex
arolyry.phicatcher.
oet igtcher.smany gument, /pt i/ Thferences s variablemx  mplate <typename T>
  inle anternal::stReftchAn<T>T&> Ref(T& x) 
e    NOLINT }
turn iniernal::stReftchAn<T>T&>(x) 

   AnCam*tvex
atcher.
oet igtcher.smany doublemgument, /mpproxitchely/ Anequal  imrha,oen
.usawo NANs e nocst id oedaunequal. inle anternal::stFlo ti MEqtcherIn<double> DoubleEq(doublemrh : 
   turn iniernal::stFlo ti MEqtcherIn<double>(rha,ofalse) 

   AnCam*tvex
atcher.
oet igtcher.smany doublemgument, /mpproxitchely/ Anequal  imrha,oincludg M NaNelue,
sewn thrhs  eaNaN. inle anternal::stFlo ti MEqtcherIn<double> NanSet iten DoubleEq(doublemrh : 
   turn iniernal::stFlo ti MEqtcherIn<double>(rha,oue i) 

   AnCam*tvex
atcher.
oet igtcher.smany doublemgument, /mpproxitchelynequal  i/ Thfha,oupo oae cosneiifd l maxaabsolu <terr imbouef,oen
.usawo NANs e n
   cst id oedaunequal. he twmexaabsolu <terr imbouefamuenxbe non-ndtionve. inle anternal::stFlo ti MEqtcherIn<double> DoubleNea); ex//doublemrh ,/doublemmex_abs_err i: 
   turn iniernal::stFlo ti MEqtcherIn<double>(rha,ofalse,mmex_abs_err i: 

   AnCam*tvex
atcher.
oet igtcher.smany doublemgument, /mpproxitchelynequal  i/ Thfha,oupo oae cosneiifd l maxaabsolu <terr imbouef,oincludg M NaNelue,
sewn t/ Thfha  eaNaN. he twmexaabsolu <terr imbouefamuenxbe non-ndtionve. inle anternal::stFlo ti MEqtcherIn<double> NanSet iten DoubleNea); ex//doublemrh ,/doublemmex_abs_err i: 
   turn iniernal::stFlo ti MEqtcherIn<double>(rha,oerua, mex_abs_err i: 

   AnCam*tvex
atcher.
oet igtcher.smany flo taaument, /mpproxitchely/ Anequal  imrha,oen
.usawo NANs e nocst id oedaunequal. inle anternal::stFlo ti MEqtcherIn<flo t> Flo tEq(flo tarh : 
   turn iniernal::stFlo ti MEqtcherIn<flo t>(rha,ofalse) 

   AnCam*tvex
atcher.
oet igtcher.smany flo taaument, /mpproxitchely/ Anequal  imrha,oincludg M NaNelue,
sewn thrhs  eaNaN. inle anternal::stFlo ti MEqtcherIn<flo t> NanSet iten Flo tEq(flo tarh : 
   turn iniernal::stFlo ti MEqtcherIn<flo t>(rha,oue i) 

   AnCam*tvex
atcher.
oet igtcher.smany flo taaument, /mpproxitchelynequal  i/ Thfha,oupo oae cosneiifd l maxaabsolu <terr imbouef,oen
.usawo NANs e n
   cst id oedaunequal. he twmexaabsolu <terr imbouefamuenxbe non-ndtionve. inle anternal::stFlo ti MEqtcherIn<flo t> Flo tNea); ex//flo tarh ,/flo tamex_abs_err i: 
   turn iniernal::stFlo ti MEqtcherIn<flo t>(rha,ofalse, mex_abs_err i: 

   AnCam*tvex
atcher.
oet igtcher.smany flo taaument, /mpproxitchelynequal  i/ Thfha,oupo oae cosneiifd l maxaabsolu <terr imbouef,oincludg M NaNelue,
sewn t/ Thfha  eaNaN. he twmexaabsolu <terr imbouefamuenxbe non-ndtionve. inle anternal::stFlo ti MEqtcherIn<flo t> NanSet iten Flo tNea); ex//flo tarh ,/flo tamex_abs_err i: 
   turn iniernal::stFlo ti MEqtcherIn<flo t>(rha,oerua, mex_abs_err i: 

   AnCam*tvex
atcher.
oet igtcher.smaoroternaa(rawO casmart)oet igroters
 NOeoay-"ue.
oet igtcher.sm tn a_tcher.
. mplate <typename T>Inr itcherInclinle anternal::stPotern tcher<T<Inr itcherInc Potern (   *ocst {
Inr itcherIn&oten a_tcher.
) 
   turn iniernal::stPotern tcher<T<Inr itcherInc(ten a_tcher.
) 

   AnCam*tvex
atcher.
oet igtcher.sman object whos<iven unfield tch res
 NO'tcher.
'.  F imample, a  A   Field(&Foo::numb.
a Ge(5))
   tch reex
aFoo object xsiff x.numb.
a>= 5  mplate <typename T>Css f, pename T>Fieldeave, pename T>FieldtcherInclinle anPolyry.phictcher<T<
 niernal::stFieldtcherIn<Css f, Fieldeave>n>nField(   *oFieldeave>Css f::*field,/nst MaFseldtcherIn&otcher 
) 
 }
turn intcs Polyry.phictcher<T(   im:  ernal::stFieldtcherIn<Css f, Fieldeave> i          field,/tcherInCast>nst MaFseldeave&  tcher 
))
  }
 The twc
llOeoatcherInCast() is spquioedar imrupportg M ten a
     tch rerssethctmpatgble penas.  F imample, a iteallows
       Field(&Foo::ba
a m)
      imctmpilaOen
.usba
  exainier32 d
/ t iex
atcher.
of c int64.

   AnCam*tvex
atcher.
oet igtcher.sman object whos<iven unproperty
   tch reex'tcher.
'.  F imample, a  A   Property(&Foo::st
, StartsWith("hi"))
   tch reex
aFoo object xsiff x.r(); estartsaah th"hi"  mplate <typename T>Css f, pename T>Propertyeave, pename T>PropertytcherInclinle anPolyry.phictcher<T<
 niernal::stPropertytcherIn<Css f, Propertyeave>n>nProperty(i    Propertyeave (Css f::*property) const {,/nst MaPropertytcherIn&otcher 
) 
 }
turn intcs Polyry.phictcher<T(   im:  ernal::stPropertytcherIn<Css f, Propertyeave> i          property,i          tcherInCast>EST_DIREFERENCE_TO_CON_DI(Propertyeave)  tcher 
))
  }
 The twc
llOeoatcherInCast() is spquioedar imrupportg M ten a
     tch rerssethctmpatgble penas.  F imample, a iteallows
       Property(&Foo::ba
a m)
      imctmpilaOen
.usba
() rurns a ainier32 d
/ t iex
atcher.
of c int64.

   AnCam*tvex
atcher.
oet igtcher.sman object iff e corultLi ethcpplygMa
 NOawc
llableoeo x tch reex'tcher.
'./ AnF imample, a  A   sultLiOf(f, StartsWith("hi"))
   tch reex
aFoo object xsiff f(x) startsaah th"hi"  //wc
llableoparometerac be
/fmarction s,arction sopoterna,ooromafctio c  //wC
llableoh at imsatgsfysah<irollowg M nstdion ss:  A   * It is spquioeda imkeeptno dtio/fmffeiol M e verultLisset/ Th    t twc
llsu   itea
/ tcknot as fumpon ss eboutehow tc nuc
lls/ Th    willObtwmede.uAny dtio/fitekeepsamuenxbe otottededefromte ln Ma  *ocstcurncemaaccess.  A   * Iffiteiatmarction soobjecta iteh at imeine aneena rultLi_pena   A     Wusrectmmendid oivl M yourafctio c ass fes,rromtd::osunarf_rction s  mplate <typename T>C
llable, pename T>RultLiOftcherInclinrnal::stReltLiOftcherIn<C
llable> sultLiOf(i    C
llableoc
llable, cst {
ReltLiOftcherIn&otcher 
) 
 }
turn ininrnal::stReltLiOftcherIn<C
llable> i          c
llable,i          tcherInCast>pename T>ternal::stC
llableTraits<C
llable>stReltLieave> i              tcher 
))  }
 The twc
llOeoatcherInCast() is spquioedar imrupportg M ten a
     tch rerssethctmpatgble penas.  F imample, a iteallows
       sultLiOf(Fction s,am)
      imctmpilaOen
.usFction s() rurns a ainier32 d
/ t iex
atcher.
of c int64.

   AnSingMaetcher.
s.   AnMch reex
astngManequal  imstn./inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stsingMa> >i    SinEq(nst Maternal::stsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stsingMa> i      st
, erua, ue i)) 

   AnMch reex
astngMant usequal  imstn./inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stsingMa> >i    SinNe(nst Maternal::stsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stsingMa> i      st
, false, ue i)) 

   AnMch reex
astngManequal  imstna ignongManaase.
inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stsingMa> >i    SinCaseEq(nst Maternal::stsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stsingMa> i      st
, erua, false)) 

   AnMch reex
astngMant usequal  imstna ignongManaase.
inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stsingMa> >i    SinCaseNe(nst Maternal::stsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stsingMa> i      st
, false, false)) 

   AnCam*tvex
atcher.
oet igtcher.smany singMa,td::ossingMa,t c C singMa
 NOet igctain #ste
peven unsubsingMa.
inle anPolyry.phictcher<T<iernal::stHasSubsintcherIn<ternal::stsingMa> >i    HasSubsin(nst Maternal::stsingMa& subsingMa) 
 }
turn intcs Polyry.phictcher<T(iernal::stHasSubsintcherIn<ternal::stsingMa> i      subsingMa)) 

   AnMch reex
astngManet igstartsaah th'prinex' (aase-set iten )./inle anPolyry.phictcher<T<iernal::stStartsWithtcherIn<ternal::stsingMa> >i    SiartsWith(nst Maternal::stsingMa& prinex) 
 }
turn intcs Polyry.phictcher<T(iernal::stSiartsWithtcherIn<ternal::stsingMa> i      prinex)) 

   AnMch reex
astngManet igendsaah th'sufnex' (aase-set iten )./inle anPolyry.phictcher<T<iernal::stEndsWithtcherIn<ternal::stsingMa> >i    EndsWith(nst Maternal::stsingMa& sufnex) 
 }
turn intcs Polyry.phictcher<T(iernal::stEndsWithtcherIn<ternal::stsingMa> i      sufnex)) 

   AnMch reex
astngManet igfuvly tcher.smregusscaamptussn so'regex'./ The twmeher.
oecs ssowt.
shipseth'regex'./inle anPolyry.phictcher<T<iernal::stMch reeRegextcherInc Mch reeRegex(   *ocst {
inrnal::stRE* regex) 
 }
turn intcs Polyry.phictcher<T(iernal::stMch reeRegextcherIn(regex, ue i)) 

 inle anPolyry.phictcher<T<iernal::stMch reeRegextcherInc Mch reeRegex(   *ocst {
inrnal::stsingMa& regex) 
 }
turn intch reeRegex(w maternal::stRE(regex)) 

   AnMch reex
astngManet igctain #stregusscaamptussn so'regex'./ The twmeher.
oecs ssowt.
shipseth'regex'./inle anPolyry.phictcher<T<iernal::stMch reeRegextcherInc Ctain #eRegex(   *ocst {
inrnal::stRE* regex) 
 }
turn intcs Polyry.phictcher<T(iernal::stMch reeRegextcherIn(regex, false)) 

 inle anPolyry.phictcher<T<iernal::stMch reeRegextcherInc Ctain #eRegex(   *ocst {
inrnal::stsingMa& regex) 
 }
turn inCtain #eRegex(w maternal::stRE(regex)) 

  #iGMEST_DIHAS_GLOBAL_WSTRING ||MEST_DIHAS_STD_WSTRING/ ThWideastngMantcher.
s.   AnMch reex
astngManequal  imstn./inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stwsingMa> >i    SinEq(nst Maternal::stwsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stwsingMa> i      st
, erua, ue i)) 

   AnMch reex
astngMant usequal  imstn./inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stwsingMa> >i    SinNe(nst Maternal::stwsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stwsingMa> i      st
, false, ue i)) 

   AnMch reex
astngManequal  imstna ignongManaase.
inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stwsingMa> >i    SinCaseEq(nst Maternal::stwsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stwsingMa> i      st
, erua, false)) 

   AnMch reex
astngMant usequal  imstna ignongManaase.
inle anPolyry.phictcher<T<iernal::stSinEqualitytcherIn<ternal::stwsingMa> >i    SinCaseNe(nst Maternal::stwsingMa& sin) 
 }
turn intcs Polyry.phictcher<T(iernal::stSinEqualitytcherIn<ternal::stwsingMa> i      st
, false, false)) 

   AnCam*tvex
atcher.
oet igtcher.smany wsingMa,td::oswsingMa,t c C wideastngMa
 NOet igctain #ste
peven unsubsingMa.
inle anPolyry.phictcher<T<iernal::stHasSubsintcherIn<ternal::stwsingMa> >i    HasSubsin(nst Maternal::stwsingMa& subsingMa) 
 }
turn intcs Polyry.phictcher<T(iernal::stHasSubsintcherIn<ternal::stwsingMa> i      subsingMa)) 

   AnMch reex
astngManet igstartsaah th'prinex' (aase-set iten )./inle anPolyry.phictcher<T<iernal::stStartsWithtcherIn<ternal::stwsingMa> >i    SiartsWith(nst Maternal::stwsingMa& prinex) 
 }
turn intcs Polyry.phictcher<T(iernal::stSiartsWithtcherIn<ternal::stwsingMa> i      prinex)) 

   AnMch reex
astngManet igendsaah th'sufnex' (aase-set iten )./inle anPolyry.phictcher<T<iernal::stEndsWithtcherIn<ternal::stwsingMa> >i    EndsWith(nst Maternal::stwsingMa& sufnex) 
 }
turn intcs Polyry.phictcher<T(iernal::stEndsWithtcherIn<ternal::stwsingMa> i      sufnex)) 

  #end (*o   GST_DIHAS_GLOBAL_WSTRING ||MEST_DIHAS_STD_WSTRING/  AnCam*tvex
arolyry.phicatcher.
oet igtcher.sma 2-tuemeoen
.usah</ Thfst.
 field ==ae cosenstd field. inle anternal::stEq2tcherIn Eq() 
eturn internal::stEq2tcherIn() 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.sma 2-tuemeoen
.usah</ Thfst.
 field >=ae cosenstd field. inle anternal::stGe2tcherIn Ge() 
eturn internal::stGe2tcherIn() 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.sma 2-tuemeoen
.usah</ Thfst.
 field >ae cosenstd field. inle anternal::stGt2tcherIn Gt() 
eturn internal::stGt2tcherIn() 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.sma 2-tuemeoen
.usah</ Thfst.
 field <=ae cosenstd field. inle anternal::stLe2tcherIn Le() 
eturn internal::stLe2tcherIn() 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.sma 2-tuemeoen
.usah</ Thfst.
 field <ae cosenstd field. inle anternal::stLt2tcherIn Lt() 
eturn internal::stLt2tcherIn() 

   AnCam*tvex
arolyry.phicatcher.
oet igtcher.sma 2-tuemeoen
.usah</ Thfst.
 field !=ae cosenstd field. inle anternal::stNe2tcherIn Ne() 
eturn internal::stNe2tcherIn() 

   AnCam*tvex
atcher.
oet igtcher.smany "ue.
o meeena Toet igt esn't m
   tch r. mplate <typename T>Inr itcherInclinle anternal::stNottcher<T<Inr itcherInc Not(Inr itcherIn m) 
 }
turn iniernal::stNottcher<T<Inr itcherInc(m) 

   Anturns a matcher.
oet igtcher.smanythgManet igsatgsfieste
peven u  Anpridice <. he twpridice <ac be
/fmny unarfarction soorafctio c/ Anwhos<iturn inuena c be
/filemit Mlyeaonn rteda imol M. mplate <typename T>Pridice <clinle anPolyry.phictcher<T<iernal::stTrulytcherIn<Pridice <c >iTruly(Pridice <wprid) 
 }
turn intcs Polyry.phictcher<T(iernal::stTrulytcherIn<Pridice <c(prid)) 

   Anturns a matcher.
oet igtcher.sme vectain #.
 de i.he tuctain #.
 muen  Anrupportmol thre i;  d
/ de i_eena ich mu
llOSTL-like ctain #.
s otovide   A NoteOet igt toparometera'de i'ac be
/fma"ue.
o meeena de i_eena asaaellOas
   tch rer. F imiastance:  A   EXPECT_THATtctain #.
, Se iIs(2)  




 AnChecksectain #.
ah a 2eementats.  A   EXPECT_THATtctain #.
, Se iIs(Le(2)  

 AnChecksectain #.
ah a  igto.
 2. mplate <typename T>Se itcherInclinle anternal::stSe iIstcherIn<Se itcherInclSe iIs(cst MaSe itcherIn& de i_tch rer) 
 }
turn iniernal::stSe iIstcherIn<Se itcherInc(de i_tch rer) 

   Anturns a matcher.
oet igtcher.smansequal ctain #.
   The iextcher.
obehav.smlike Eq( , butein t lievt, /ethtistcher-ltenssah</ Thlue,
seet iga.usincludedO tuontuctain #.
 butet use veotrIn. (Duemite <  Thlue,
sed
/ ord o d (rences s   not tmelain(Ted.) mplate <typename T>Ctain #.
  inle anPolyry.phictcher<T<iernal::stCtain #.
EqtcherIn<e    NOLINT }


























EST_DIREMOVE_CON_DI(Ctain #.
)> >i    Ctain #.
Eq(cst MaCtain #.
&arh : 
    The iexrollowg M le antfof c workgManarouefaa buM te MSVC 8.0ai     ich mucaufes,Ctain #.
oeo beiaocst {
eena dometimn'. //mavef GMEST_DIREMOVE_CON_DI(Ctain #.
) RawCtain #.
; exturn intcs Polyry.phictcher<T(   im:  ernal::stCtain #.
EqtcherIn<RawCtain #.
 (rh :) 

   Anturns a matcher.
oet igtcher.smauctain #.
 et i,ewn thsortedae g M
 NOetpeven unctmparao c,mtcher.smctain #.
_tcher.
. mplate <typename T>Ctmparao c,mpename T>Ctain #.
tcherInclinle anternal::stWn tSortedBytcherIn<Ctmparao c,mCtain #.
tcherInclWn tSortedBy(cst MaCtmparao c&nctmparao c, }











cst MaCtain #.
tcherIn& ctain #.
_tcher.
) 
 }
turn iniernal::stWn tSortedBytcherIn<Ctmparao c,mCtain #.
tcherInc(i      csmparao c,mctain #.
_tcher.
) 

   Anturns a matcher.
oet igtcher.smauctain #.
 et i,ewn thsortedae g M
 NOetpe<aerator c,mtcher.smctain #.
_tcher.
. mplate <typename T>Ctain #.
tcherInclinle anternal::stWn tSortedBytcherIn<ternal::stLessCtmparao c,mCtain #.
tcherInclWn tSorted(cst MaCtain #.
tcherIn& ctain #.
_tcher.
) 
 }
turn i   im:  ernal::stWn tSortedBytcherIn<ternal::stLessCtmparao c,mCtain #.
tcherInc i          ternal::stLessCtmparao c( , ctain #.
_tcher.
) 

   AnMcher.smansSTL-style ctain #.
 oromanionveo rray et igctain #ste
p  Anre T>numb.
ammeementats asainmrha,oen
.usits i-tr ementat d
/ rha's
   i-tr ementat ( atmarair)msatgsfysah<iven unpairatcher.
,sr imallOi   TheuemetcherIn muenxbe ableoeo 
/fsafelyncastOeoatcherIn<tueme>nst M  The1&, cst {
T2&>n>,oen
.usT1 d
/ T2ga.use pepenasammeementats in t l  ThLHS ctain #.
  
/it e RHS ctain #.
 resneionvely  mplate <typename T>euemetcherIn,mpename T>Ctain #.
clinle anternal::stPoterwisetcherIn<euemetcherIn, }
































EST_DIREMOVE_CON_DI(Ctain #.
)>
Poterwise(cst {
TuemetcherIn& tueme_tcher.
,scst MaCtain #.
&arh : 
    The iexrollowg M le antfof c workgManarouefaa buM te MSVC 8.0ai     ich mucaufes,Ctain #.
oeo beiaocst {
eena dometimn'. //mavef GMEST_DIREMOVE_CON_DI(Ctain #.
) RawCtain #.
; exturn internal::stPoterwisetcherIn<euemetcherIn, RawCtain #.
 ( }




tueme_tcher.
,srh : 

   AnMcher.smansSTL-style ctain #.
 oromanionveo rray et igctain #st i/ ThleastOontuementatstcherl M e veven un"ue.
o ratcher.
.  A/ ThEmple, s:  A   std::osset<ter>npage_ids;  A   page_ids.inM ro(3);  A   page_ids.inM ro(1);  A   EXPECT_THATtpage_ids,mCtain #s(1));  A   EXPECT_THATtpage_ids,mCtain #s(Gt(2) );  A   EXPECT_THATtpage_ids,mNot(Ctain #s(4) );  A  A   std::osmap<tera/de i_e>apage_lengths;  A   page_lengths[1] = 100;  A   EXPECT_THATtpage_lengths,/ Th              Ctain #s(std::ospair<nst Matera/de i_e>(1, 100) );  A  A   cst Manhar*/er t_ids[] = { "joe", "mike", "tom" };  A   EXPECT_THATter t_ids,mCtain #s(Eq(std::ossingMa "tom")) ); mplate <typename T>Mclinle anternal::stCtain #stcherIn<Mc Ctain #e(Motcher 
) 
 }
turn ininrnal::stCtain #stcherIn<Mc(tcher.
) 

   AnMcher.smansSTL-style ctain #.
 oromanionveo rray et igctain #st  ly/ Anementats tcherl M e veven un"ue.
o ratcher.
.  A/ ThEach(m) is semantic vly pqui"uet, /pomNot(Ctain #s(Not(m) ). O ly/ Ane antdibagas   nod (rencet.  A/ ThEmple, s:  A   std::osset<ter>npage_ids;  A    ThEach(m) tcher.smansemptyoctain #.
, regardlessommewt igt is.  A   EXPECT_THATtpage_ids,mEach(Eq(1) );  A   EXPECT_THATtpage_ids,mEach(Eq(77) );  A  A   page_ids.inM ro(3);  A   EXPECT_THATtpage_ids,mEach(Gt(0) );  A   EXPECT_THATtpage_ids,mNot(Each(Gt(4)) );  A   page_ids.inM ro(1);  A   EXPECT_THATtpage_ids,mNot(Each(Lt(2) ));  A  A   std::osmap<tera/de i_e>apage_lengths;  A   page_lengths[1] = 100;  A   page_lengths[2] = 200;  A   page_lengths[3] = 300;  A   EXPECT_THATtpage_lengths,mNot(Each(Pair(1, 100) ));  A   EXPECT_THATtpage_lengths,mEach(Key(Le(3)) );  A  A   cst Manhar*/er t_ids[] = { "joe", "mike", "tom" };  A   EXPECT_THATter t_ids,mNot(Each(Eq(std::ossingMa "tom")) )); mplate <typename T>Mclinle anternal::stEachtcherIn<Mc Each(Motcher 
) 
 }
turn ininrnal::stEachtcherIn<Mc(tcher.
) 

   AnKey(ten a_tcher.
) tcher.smansd::ospairnwhos<i'fst.
'nfield tch res
 NO tn a_tcher.
.  F imample, a Ctain #s(Key(Ge(5)))ac be
/fed topomtcher-mt
tr d::osmap et igctain #st ihleastOontuementatswhos<ikey is >= 5  mplate <typename T>Mclinle anternal::stKeytcherIn<Mc Key(Moten a_tcher.
) 
   turn iniernal::stKeytcherIn<Mc(ten a_tcher.
) 

   AnPair(fst.
_tcher.
,ssenstd_tcher.
) tcher.smasd::ospairnwhos<i'fst.
'nfield
   tch reexfst.
_tcher.
  
/iwhos<i'senstd'nfield tch resssenstd_tcher.
.  F i/ Anemple, a EXPECT_THATtmap_eena, EmentatsAra(Pair(Ge(5), "foo")))ac be
/fed t
    imtcher-m d::osmap<tera/dingMa> et igctain #stempcMlyeontuementatswhos<ikey
 NO s >= 5  
/iwhos<i"ue.
oequals "foo"  mplate <typename T>Fst.
tcherIn,mpename T>SenstdtcherInclinle anternal::stPairtcherIn<Fst.
tcherIn,mSenstdtcherInclPair(Fst.
tcherIn fst.
_tcher.
,sSenstdtcherInssenstd_tcher.
) 
   turn iniernal::stPairtcherIn<Fst.
tcherIn,mSenstdtcherInc( }




fst.
_tcher.
,ssenstd_tcher.
) 

   Anturns a mapridice <aet igis satgsfied bymanythgManet igtcher.sme v  Anven untcher.
. mplate <typename T>Mclinle anternal::sttcherInAsPridice <<Mc Mcher.s(Motcher 
) 
 }
turn ininrnal::sttcherInAsPridice <<Mc(tcher.
) 

   Anturns a er.
oiff e co"ue.
otcher.sme vetcher.
. mplate <typename T>T,opename T>Mclinle anol MaVue i(cst {
T&o"ue.
, Motcher 
) 
 }
turn intestg MstMch ree(tcher.
)("ue.
  

   AnMcher.sme co"ue.
oagn #st e veven untcher.
  
/ielain(Tsme vetcher  AnrultLi  imltener i. mplate <typename T>T,opename T>Mclinle anol Maplain(TMchersultLi( }


Matcher.
,scst {
T&o"ue.
, MchersultListener* listener) co
 }
turn inSafetcherInCast>nst MaT&  tcher 
).tcherdExplain(T "ue.
, stener) c  

 #iGMEST_DILANG_CXX11 /Itscne anvariadicatcher.
oversn ss.he ty e no rb loadedO t  Anvmock-ger-re <d-tcher.
s.hof c t twc
fes,rupported bympriuC++11ectmpilars. mplate <typename T...aArgs  inle anternal::stAllOftcherIn<Args...> AllOf.nst MaArgs&...atcher.
s) 
 }
turn ininrnal::stAllOftcherIn<Args...> tcher 
s...   

 mplate <typename T...aArgs  inle anternal::stAnyOftcherIn<Args...> AnyOf.nst MaArgs&...atcher.
s) 
 }
turn ininrnal::stAnyOftcherIn<Args...> tcher 
s...   

 #end (*o   GST_DILANG_CXX11   AnAllArgs(m) is m dynonym/etht. he iex heed fulO t  A  A   EXPECT_CALL(foo, Bar(_, _ ).With(AllArgs(Eq(  );  A  A ich mu exeasi o  imreadoe an  A  A   EXPECT_CALL(foo, Bar(_, _ ).With(Eq(  ; mplate <typename T>Inr itcherInclinle anInr itcherIn AllArgs(cst {
Inr itcherIn&otcher 
) 
 turn intcher 
 

   AnT aswotacroseallow e g M tcher 
s  imcheckhlue,
seintGooglesTe M  Thtesta.  ASSERT_THATt"ue.
, tcher 
)  
/iEXPECT_THATt"ue.
, tcher 
)  Anruccd toiff e co"ue.
otcher.sme vetcher.
.  Ithe ves feronTosrails,/ The co"ue.
oa
/it e ecribeponTosethe latcher.
owillObtwpnts ed.
#eine anASSERT_THATt"ue.
, tcher 
) ASSERT_PRED_FORMAT1(\ }


::testg Mstinrnal::sttckePridice <F imatrnaFromtcherIn tcher 
),n"ue.
)
#eine anEXPECT_THATt"ue.
, tcher 
)nEXPECT_PRED_FORMAT1(\ }


::testg Mstinrnal::sttckePridice <F imatrnaFromtcherIn tcher 
),n"ue.
)
 }:    me Tspace>testg M
 #end (*o   GMOCK_INCLUDE_GMOCK_GMOCK_MATCHERS_H_

me Tspace>testg M 
   AnAnaabstraio haefle ethc ielaectaon s  ass foElaectaon s
// AnAsse /ethelaectaon s haefles  ass foElaectaon sSet
// AnAnythgManit id he la'inrnal::' me Tspace>IS INTERNAL IMPLEMENTATION/ Ana
/iMUST NOT BE USED IN USER CODE!!!
me Tspace>inrnal:: 
   Anplementats 
atockhrction s  mplate <typename T>F> ass foFction sMock.
;   AnBaswoass fof imamaectaon ss  ass foElaectaon sBasw
// Anplementats c ielaectaon s  mplate <typename T>F> ass foeavefElaectaon s
// AnHelpIn ass fof c testg M e laElaectaon s ass fomplate <  ass foElaectaon sTe M.
;   AnBaswoass fof imrction somock.
s. mplate <typename T>F> ass foFction sMock.
Basw
// AnPtottedsme vetockhobject regtenry (te ass foMock),nallOrction s
   tock.
s, d
/ allOamaectaon ss   A/ The twreas sowe eot mae isry. ane a-grn(Ted otottedn so e:ewn tha
   tockmrction soFoo() is c vleda itend ts  imc sstLi its amaectaon ss
    imsea ich muontushtuld btwpick.d.  IthanorhInoe readoiseallow topo
   c
llO
atockhrction s (eitrInoFoo() oromad (rencetuont)  igt tore T
    im a itectuld mffeiogt to"turioed"  iingbutasammeFoo()'s
   amaectaon ssewn thIsSequces () is ed t,oa
/it us mffeiogich m
   amaectaon s gets pick.d.  Tn
.uf i a wtusequces i
llOtockhrction s
   c
lls  imesst.use peinrngrityf "Ee vetockhobjects' dtio/s.
EST_DIAPI_ EST_DISECLARE_STATIC_MUTEX_(g_vmock_mutax) 

   Unmavef baswoass fof imAion ssultLiHoldIn<R>. ass foUnmavefAion ssultLiHoldInBasw
// AnAbstraio baswoass fommeFction sMock.
Basw. he iex hee v  Anmave-agnostgcopartsethe anrction somock.
>inrnaface.  Its pu n
   virtual methods   noilementated bymFction sMock.
Basw. ass foEST_DIAPI_ UnmavefFction sMock.
Basw    blic:
  viUnmavefFction sMock.
Basw()  }
virtual ~UnmavefFction sMock.
Basw()  i     Verifieste
at allOamaectaon ssu   e  hetockhrction s hav. bteni     satgsfied.  suportsuontu raty. aGooglesTe M non-fatal railu ns
     d
/ rurns a false  (snor. //ol MaVerifydExClearElaectaon ssLock.d() }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 



 AnClearsme veON_CALL()ssse /e  e  hetockhrction s. }
virtual voidnClearscnatLiAion ssLock.d() }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) = 0 



 AnIn allOethe anrollowg M Unmavef*orction ss,eit's t twc
ll.
's


 Anresnst ibility  imguaraateeme vectrrectnessommee vesument, s'
      enas.



 AnPnaf imsat e ecnatLi aion s ah the veven unsument, s d
/ rurns a
       vesion s'snrultLi  he tucallOecribeponTosstngManwillObtwed toin
       veerr imtdibagat imeiribebe t twc
llein t lic
feat e ecnatLi
     dconTosrails.
     L = * }
virtual UnmavefAion ssultLiHoldInBasw* UnmavefPnaf imscnatLiAion s(i      cst {
void* unmavef_gums,i      cst {
singMa& c
ll_ecribeponToconst {
= 0 



 AnPnaf imsat e ven unsion s ah the veven unsument, s d
/ rurns a
       vesion s'snrultLi 
     L = * }
virtual UnmavefAion ssultLiHoldInBasw* UnmavefPnaf imAion s(i      cst {
void* unmavef_gconTo,i      cst {
void* unmavef_gumsconst {
= 0 



 AnWritas 
atdibagat t igt toc
lleis eninrnaestg M (i.e. neitrIn


 Anplicit Mly plaect tot rnplicit Mly unplaect t)o oae coven u 

 Anostream. }
virtual voidnUnmavefDiribebeUninrnaestg MC
ll(i      cst {
void* unmavef_gums,i      std::osostream*nosconst { }








GST_DILOCK_EXCLUDED_(g_vmock_mutax) = 0 



 Anturns a e veamaectaon s et igtcher.sme veven unfction sogument, a
     ( rnNULLo hee vre'atno tcher);ewn thamtcher-tfof uef,
     unmavef_gconTo is sei  impotero oae cogconTo et igshtuld bt
     pnaf im to( rnNULLo fae cogconTo  ex"do ecnatLi"),oa
/
     is_excessnveo hetodifd l  oaindice <awn rhInoe toc
lleexce ts  he


 Anpliect totumb.
. }
virtual cst {
Elaectaon sBasw* UnmavefFitdtcheri MElaectaon s(i      cst {
void* unmavef_gums,i      cst {
void** unmavef_gconTo,/ol M* is_excessnve,i      std::osostream*nwt i,estd::osostream*nwty) }








GST_DILOCK_EXCLUDED_(g_vmock_mutax) = 0 



 AnPnts sme veven unfction sogument, ao oae coostream. }
virtual voidnUnmavefPnts Args(cst {
void* unmavef_gums,i                                std::osostream*nosconst { = 0 



 AnSedsme vetockhobject e  hetockhmethod btlongao o, d
/ rugten.
s
        heiaf imatnTo  n t liglobal tockhregtenry  hWillObtwc vledi     icenev.
  
 EXPECT_CALL() oroON_CALL()u exexecut toe  e  hetocki     method 
     TODO(wan@google.com):hreme T> oaSeddExRugten.
Owt.
(). }
voidnRugten.
Owt.
(cst {
void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(g_vmock_mutax) 



 AnSedsme vetockhobject e  hetockhmethod btlongao o, d
/ sedsme v
:    me Tf "Ee vetockhrction s. hWillObtwc vled unstmaa r invocatnTo 

 Anof e  hetockhrction s. }
voidnSedOwt.
dExNe T(cst {
void* mock_obj, cst Manhar*/me T) }
*o: EST_DILOCK_EXCLUDED_(g_vmock_mutax) 



 Anturns a e vetockhobject e  hetockhmethod btlongao o. hMuenxbe


 Anc vled afteraRugten.
Owt.
() oroSedOwt.
dExNe T()ah a bteni     c vled. }
cst {
void* MockObject(const { }




EST_DILOCK_EXCLUDED_(g_vmock_mutax) 



 Anturns a e veme Tf "Ee  hetockhmethod. hMuenxbenc vled after


 AnSedOwt.
dExNe T()ah a bten c vled. }
cst {
nhar*/Ne T()anst { }




EST_DILOCK_EXCLUDED_(g_vmock_mutax) 



 Anturns a e verultLi ethinvokg M e  hetockhrction s ah the veven u
     dument, a. he iexrction s n be
/fsafelyncavled rromtmtLiieme
       readsocstcurncemly  he tucaller is spsnst ibleof imdeletg M e l


 AnrestLi 
  cst {
UnmavefAion ssultLiHoldInBasw* UnmavefInvokeWith(i      cst {
void* unmavef_gumsc }








GST_DILOCK_EXCLUDED_(g_vmock_mutax) 


ototteded: //mavef GMd::osveio c<cst {
void*> UnmavefOnC
llSaecs 



mavef GMd::osveio c<inrnal::stlink.d_ptr<Elaectaon sBasw> >i  UnmavefElaectaon ss 



 Anturns a  
 Emaectaon s object e  tarerences s aef co-ow#stempai     ich mumuenxbe a ielaectaon s/e  e  hetockhrction s. }
Emaectaon s GetHaefleOf(Elaectaon sBasw* ela) 



 AnAddressommee vetockhobject e  hetockhmethod btlongao o. hO ly/

 Anvalid afterae  hetockhmethod h a bten c vled or/

 AnON_CALL/EXPECT_CALL h a bten invok toe  it. }
cst {
void* mock_obj_;

 AnPnottededeby g_vmock_mutax.



 AnNe Tf "Ee verction s beg M tock.d.  O lynvalid afterae  hetocki     methodah a bten c vled. }
cst {
nhar*/me T_;

 AnPnottededeby g_vmock_mutax.



 AnAllOecnatLi aion s sneifof c t iexrction s mock.
.i  UnmavefOnC
llSaecs unmavef_on_c
ll_sneif_;



 AnAllOamaectaon ssuf c t iexrction s mock.
.i  UnmavefElaectaon ss unmavef_amaectaon ss_;
};

 Anass foUnmavefFction sMock.
Basw

   Unmavef baswoass fof imOnC
llSaec<F>. ass foUnmavefOnC
llSaecBasw    blic:
  vi The twsument, s d.use pelocatnTof "Ee veON_CALL()udtio/mcet.   UnmavefOnC
llSaecBasw(cst {
nhar*/a_fi, a iat d_le ac }




: fi, _(a_fi, ), le a_(a_le ac,>ss t_assusa_(kNont) {}



 AnWn
.usin t lisource fi,  wasat e ecnatLi aion s sneimeine ad? }
cst {
nhar*/fi, ()anst { 
 turn infi, _ 

   ter le a()anst { 
 turn inle a_ 

  
ototteded: //   Giv.smaa r assusasin t liON_CALL()udtio/mcethc me T.   etum>Cssusw     //   Doot tmnhanguse peord o  "Ee veetum>temb.
s! he turun- im    //   syntaxmcheckg M relieste  it. }
  kNont,i    kWith,i    kWillByDcnatLi
  };



 AnA ferosOet igt liON_CALL()udtio/mcethh a   ceroaiunproperty. }
voidnA feroSaecProperty(ol Maproperty, cst {
singMa& railu n_tdibaga)anst { 
i    A fero(property, fi, _, le a_, railu n_tdibaga)  }
}



 AnElaectsOet igt liON_CALL()udtio/mcethh a   ceroaiunproperty. }
voidnElaectSaecProperty(ol Maproperty, cst {
singMa& railu n_tdibaga)anst { 
i    Elaect(property, fi, _, le a_, railu n_tdibaga)  }
}



cst {
nhar*/fi, _;   ter le a_;



 AnT lise {
nssusasin t liON_CALL()udtio/mcethcs se thso rar.


 AnIniti vlynkNont aef changus asat e dtio/mcethiexparsed. }
Cssusw ss t_assusa_;
};

 Anass foUnmavefOnC
llSaecBasw
  The iexmplate <tass foilementats c iON_CALL snei. mplate <typename T>F> ass foOnC
llSaec
: blic:
oUnmavefOnC
llSaecBasw    blic:
  vimavef GMpename T>Fction s<F>::Aument, eueme Aument, eueme; vimavef GMpename T>Fction s<F>::Aument, tcherIneueme Aument, tcherIneueme 



 AnCttructors,anoOnC
llSaec
object fromte leiaf imatnTo  n id 
       vepart, hesis ethc iON_CALL()udtio/mcet.   OnC
llSaec(cst {
nhar*/a_fi, a iat d_le a, }











cst MaAument, tcherIneueme&atcher.
s) }




: UnmavefOnC
llSaecBasw(a_fi, a a_le ac, }






tcher.
s_ tcher 
sc, }






 AnBy ecnatLi,Oamtra_tcher.
_gshtuld tcher-mtythgMa.  Howev.
, }






 Anwa c bt tmiTiti ve i iteah th_ asat  igtrigg 
s aectmpilar
}






 AnbuM te Symbias'snC++ectmpilar (aabt tmdeaid  bttwe thtwo
}






 An rb loadedOctastctor cs ethtcherIn<cst MaAument, eueme&>).
}






amtra_tcher.
_(A<cst MaAument, eueme&>()) 
 }
}



 Anplementats   ve.With()
nssusa.   OnC
llSaec& With(nst MatcherIn<cst MaAument, eueme&>& m) 
 }


 AnMcs ssst.use iex hea vled aigto.
 stce.i    ElaectSaecProperty(ss t_assusa_ < kWith,i                       ".With()
nabt tmappear "i                       "ty. ae an stce te c iON_CALL().")  }
  ss t_assusa_ = kWith 





amtra_tcher.
_ = m  }
  turn in*e  h; }
}



 Anplementats   ve.WillByDcnatLi()
nssusa.   OnC
llSaec& WillByDcnatLi(cst MaAion s<F>& aion s) 
i    ElaectSaecProperty(ss t_assusa_ < kWillByDcnatLi,i                       ".WillByDcnatLi()
muenxappear "i                       "empcMlyeonce te c iON_CALL().")  }
  ss t_assusa_ = kWillByDcnatLi 





ElaectSaecProperty(!aion s.IsDoDcnatLi(),i                       "DoDcnatLi()
nabt tmbtwed toiniON_CALL().")  }
  aion s_ = aion s  }
  turn in*e  h; }
}



 Anturns a er.
oiff e coven unsument, s tcher-e latcher.
s. //ol MaMch ree(cst MaAument, eueme& gumsconst {
{ }
  turn ineuemetcherIe(tcher.
s_, gumsco&&
amtra_tcher.
_.tcherIe(gumsc; }
}



 Anturns a e cogconTo sneiifd l bysah<ier t. }
cst {
Aion s<F>& GetAion s() nst { 
i    A feroSaecProperty(ss t_assusa_ == kWillByDcnatLi,i                       ".WillByDcnatLi()
muenxappear empcMlye"i                       "once te c iON_CALL().")  }
  turn inaion s_; }
}


privio/  vi The twiaf imatnTo  n dtio/mcet vi T
       ON_CALL(mock_objecta Method tcher 
sc)
           .With(mtLii-sument, -tcher.
)
           .WillByDcnatLi(aion s); vi T
     is spcord dsin t lidata>temb.
smlike e  h: vi T
       source fi,  et igctain #ste
pedtio/mceth=>/fi, _
       le annumb.
ammee
pedtio/mcethhhhhhhhhhhh=>/le a_
       tcher 
s                                =>/tcher.
s_
       ttLii-sument, -tcher.
                  =>/amtra_tcher.
_
       gconTo                                  =>/aion s_
  Aument, tcherIneueme tcher.
s_; vitcherIn<cst MaAument, eueme&>/amtra_tcher.
_; viAion s<F>naion s_; };

 Anass foOnC
llSaec// AnPos ibleoreaion sste  eninrnaestg M c
lls.
etum>C
llReaion s 
i  kAllow,i  kWaro,i  kFail,i  kDcnatLi = kWaro

 AnBy ecnatLi,Owaro
ebouteeninrnaestg M c
lls.
};

}:    me Tspace>inrnal::

   Utilitiestf ratcnipul ti Metockhobjects. ass foEST_DIAPI_ Mock    blic:
  vi The twrollowg M blic:
omethods n be
/fa vled cstcurncemly 



 AnTells GooglesMock  oaignone mock_objewn thcheckg M f ralecs di     tockhobjects.  edtio:
ovoidnAllowLecs(cst {
void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnVerifiestaef clearsmallOamaectaon ssu   e veven untockhobject.


 AnIf e veamaectaon ss d.ut masatgsfied, ger-re <suontu raty.  //   GooglesTe M non-fatal railu ns d
/ rurns a false.  edtio:
ool MaVerifydExClearElaectaon ss(void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnVerifiestallOamaectaon ssu   e veven untockhobjecttaef clearsmi a
     ecnatLi aion ss  
/ielaectaon ss  nturns a er.
oiff e c/

 AnverificatnTofwasaruccdssful.  edtio:
ool MaVerifydExClear(void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 


privio/  vifrieef cls foinrnal::stUnmavefFction sMock.
Basw 



 AnNeededar imanrction somock.
> imregten.
mi aelf (so et igwa know


 Anhow  imclearO
atockhobject).
}
mplate <typename T>F> vifrieef cls foinrnal::stFction sMock.
Basw 



mplate <typename T>Mclvifrieef cls foNiceMock 



mplate <typename T>Mclvifrieef cls foNaggyMock 



mplate <typename T>Mclvifrieef cls foStrictMock 



 AnTells GooglesMock  oaallow eninrnaestg M c
llsu   e veven untock


 Anobject.


dtio:
ovoidnAllowUninrnaestg MC
lls(cst {
void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnTells GooglesMock  oawaro
ah<ier t
ebouteeninrnaestg M c
lls To 

 Ane veven untockhobject.


dtio:
ovoidnWaroUninrnaestg MC
lls(cst {
void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnTells GooglesMock  oarail eninrnaestg M c
llsu   e veven untock


 Anobject.


dtio:
ovoidnFailUninrnaestg MC
lls(cst {
void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnTells GooglesMock   veven untockhobjecttis beg M destroyed a
/
     its annry in t lic
ll-reaion s tableoshtuld btwremoved. }
dtio:
ovoidnUnregten.
C
llReaion s(cst {
void* mock_obj) }
*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 Anturns a e veruaion s GooglesMock willOhav. e  eninrnaestg M c
llsi     tadeu   e veven untockhobject.


dtio:
oinrnal::stC
llReaion s GetReaion sOoUninrnaestg MC
lls( }
*o: cst {
void* mock_obj) }
*o: *o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnVerifieste
at allOamaectaon ssu   e veven untockhobjectthav. bteni     satgsfied.  suportsuontu raty. aGooglesTe M non-fatal railu ns
     d
/ rurns a false  (snor. //dtio:
ool MaVerifydExClearElaectaon ssLock.d(void* mock_obj) }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(inrnal::stg_vmock_mutax) 



 AnClearsmallOON_CALL()ssse /e  e veven untockhobject.


dtio:
ovoidnClearscnatLiAion ssLock.d(void* mock_obj) }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(inrnal::stg_vmock_mutax) 



 AnRugten.
sO
atockhobject d
/ aetockhmethod itsowts.  edtio:
ovoidnRugten.
( }
*o: cst {
void* mock_obj,i      inrnal::stUnmavefFction sMock.
Basw*omock.
) }
*o: *o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnTells GooglesMock wn
.usin t lisource code mock_objeis ed t te c 


 AnON_CALLu raEXPECT_CALL.  Inic
feamock_objeis lecs d, e  h
     iaf imatnTo helps
ah<ier t
idannify ich muobjecttit is.  edtio:
ovoidnRugten.
UseByOnC
llOrElaectC
ll(i      cst {
void* mock_obj, cst Manhar*/fi, a iat le ac }




*o: EST_DILOCK_EXCLUDED_(inrnal::stg_vmock_mutax) 



 AnUnregten.
s aetockhmethod;wremoves
ah<iowti Metockhobject from 

 Ane veregtenry wn tht lise {
tockhmethod s focie <deah thiteh a 

 Anbten unregten.
.d.  Tniex hea vled   lysin t lidestctor cset/

 AnFction sMock.
Basw. }
dtio:
ovoidnUnregten.
Lock.d(inrnal::stUnmavefFction sMock.
Basw*omock.
) }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(inrnal::stg_vmock_mutax) 
};

 Anass foMock   AnAnaabstraio haefle ethc ielaectaon s   Ud fulO t   ve.After()  AnnssusasethEXPECT_CALL() r imrettg M e la(partial)eord o  "
   amaectaon ss  he tusyntax:  A  A   Emaectaon s e1 = EXPECT_CALL(... ...;  A   EXPECT_CALL(... .After(e1 ...;  A  Anredsmewo amaectaon ssewn .use pelatrna n be  lysbe tcher.d after
 Ane vef im rah a bten satgsfied.  A  AnNotes:  A   - Tniexcls foisocspyableod
/ h a "ue.
osemantics.  A   -nCttrunessois shallow:iaocst {
Emaectaon s object i aelf nabt t/ Th    be todifd l, butee latutableomethods mmee
peElaectaon sBasw/ Th    objecttit rerences s n be
/fa vled via amaectaon s_basw().  A   - TneOctastctor cs andid stctor cs  nodine ad out-of-le anoecaufe/ Th    e
peSymbias WINSCWectmpilar wa, ao oaorhInwisemiastantie <aetem/ Th    wn thit sees
ahiexcls fodine ionTo,/aogich mmpoteroit esn't mthav./ Th    Elaectaon sBasw availableoyet, lecdg M eoainctrrectid stctorn s
       inse pelink.d_ptro( rnctmpilaon s err is  (se g M ahcheckg M
       link.d_ptr). ass foEST_DIAPI_ Emaectaon s    blic:
  vi ThCttructors,a nullOebject e  taesn't mtrerences fmny elaectaon s    Elaectaon s()  i  ~Elaectaon s()  i   The iex g Mle-sument,  or csmuenxt tmbtwplicit M,O tuord o  imsupportme c/

 An  Emaectaon s e = EXPECT_CALL(...   }
 Thsyntax. vi T
     AoeavefElaectaon sOebject sr cesmi ampri-spquisitas 
a 

 AnElaectaon sOebjects, d
/ nd ts  imc
llOe vemon-cst {
Rerioe()
     method e  e veElaectaon sBasw ebjects e vytrerences .  Tn
.uf i  

 AnElaectaon sOmuenxrecenveo  *mon-cst {*trerences f oae c 

 AnElaectaon sBasw ebject    Elaectaon s(inrnal::stElaectaon sBasw& ela) 

 AnNOLINT  vi The twctmpilar-ger-re <docspy or csd
/ orator c= work empcMlyeah
     iatend l, soowe eot mand tt imeine anouraowt.



 Anturns a er.
oiff rhs rerences s t tore Tielaectaon s/as
ahiexebject esn'. //ol Maorator c==(cst {
Emaectaon s&arh : nst {
{ }
  turn inamaectaon s_basw_ == rh .amaectaon s_basw_; }
}



ol Maorator c!=(cst {
Emaectaon s&arh : nst {
{ turn in!(*e  h == rh );
}


privio/  vifrieef cls foElaectaon sSet
/vifrieef cls foSequces 
/vifrieef cls fo::testg Mstinrnal::stElaectaon sBasw
/vifrieef cls fo::testg Mstinrnal::stUnmavefFction sMock.
Basw 



mplate <typename T>F> vifrieef cls fo::testg Mstinrnal::stFction sMock.
Basw 



mplate <typename T>F> vifrieef cls fo::testg Mstinrnal::steavefElaectaon s
//   The iexcsmparao cois neededar imputtg M Elaectaon sOebjects iato m det. }
cls foLess
{ }
 blic:
  vi

ol Maorator c()(cst {
Emaectaon s&alhs,mcst {
Emaectaon s&arh : nst {
{ }
    turn inlh .amaectaon s_basw_.gei()
< rh .amaectaon s_basw_.gei()  }
  
   } 



mavef GMstd::osset<Emaectaon s,oLess> Set
//  Elaectaon s(i      cst {
inrnal::stlink.d_ptr<inrnal::stElaectaon sBasw>&namaectaon s_basw) 



 Anturns a e veamaectaon s etiexebject rerences s. }
cst {
inrnal::stlink.d_ptr<inrnal::stElaectaon sBasw>&
  amaectaon s_basw() nst {
{ }
  turn inamaectaon s_basw_; }
}



 AnAelink.d_ptroet igct-ow#ste veamaectaon s etiexhaefle rerences s. }
inrnal::stlink.d_ptr<inrnal::stElaectaon sBasw>namaectaon s_basw_; }
// AnAsse /ethelaectaon s haefles   Ud fulO t   ve.After()nnssusaset/ ThEXPECT_CALL() r imrettg M e la(partial)eord o  " amaectaon ss  he t
 Thsyntax:  A  A   Emaectaon sSet es;  A    s += EXPECT_CALL(... ...;  A    s += EXPECT_CALL(... ...;  A   EXPECT_CALL(... .After(es ...;  A  Anredsmehree amaectaon ssewn .use pelastOontun be  lysbe tcher.d/ Anafterae ehfst.
 ewo hav. bl thbten satgsfied.  A  AnTniexcls foisocspyableod
/ h a "ue.
osemantics. cls foElaectaon sSet    blic:
  vi ThA bidirtedn salO tator coet igc bereadoaocst {
ementatsin t liset. }
mavef GMElaectaon s::Set::cst {_ tator cocst {_ tator c;



 AnAsOebject sr cedsin t liset.  Tniex hean alias mmeElaectaon s. }
mavef GMElaectaon s::Set::"ue.
_eena "ue.
_eena 



 AnCttructors,anoemptyoset. }
Elaectaon sSet() {}



 Ane iex g Mle-sument,  or csmuenxt tmbtwplicit M,O tuord o  imsupportme c/

 An  Emaectaon sSet es = EXPECT_CALL(...   }
 Thsyntax. viElaectaon sSet(inrnal::stElaectaon sBasw& ela)
{ 
 AnNOLINT }
  *e  h += Elaectaon s(ela) 
}
}



 Ane iex g Mle-sument,  or csilementats ilemit Meaonn rsn sofrom 

 AnElaectaon sOa
/it us muenxt tmbtwplicit M.  Tniexallows eitrInoc 


 AnElaectaon sOer  
 Emaectaon sSei  imbtwed toini.After(). viElaectaon sSet(cst {
Emaectaon s&ae)
{ 
 AnNOLINT }
  *e  h += e 
}
}



 Ane twctmpilar-ger-re  cocr csd
/ orator c= works empcMlyeah
     iatend l, soowe eot mand tt imeine anouraowt.



 Anturns a er.
oiff rhs ctain #ste
pede T>se /ethElaectaon sOebjects
     ds
ahiexesn'. //ol Maorator c==(cst {
Emaectaon sSet&arh : nst {
{ }
  turn inamaectaon ss_ == rh .amaectaon ss_; }
}



ol Maorator c!=(cst {
Emaectaon sSet&arh : nst {
{ turn in!(*e  h == rh );
}



 Anplementats   vesyntax/

 An  amaectaon s_se /+= EXPECT_CALL(... ; viElaectaon sSet&aorator c+=(cst {
Emaectaon s&ae) 
i    amaectaon ss_.inM ro(e)  }
  turn in*e  h; }
}



terore i;  nst {
{ turn indtio:
_cast<ter>(amaectaon ss_.re i; );
}



cst {_ tator cobegin;  nst {
{ turn inamaectaon ss_.begin;  

   cst {_ tator coend;  nst {
{ turn inamaectaon ss_.end; ;
}


privio/  viElaectaon s::Set amaectaon ss_; }
//  AnSequces Oebjects   noed tobymaier t
 imsneiifyne verelaonvpeord o
 NO tgich mme veamaectaon ss shtuld tcher  he ty e nocspyableo(wverely
 NOe  e vectmpilar-dine ad cspy otastctor c d
/ assignnt,  orator c). ass foEST_DIAPI_ Sequces O   blic:
  vi ThCttructors,anoemptyosequces . //Sequces () : ss t_amaectaon s_(w maElaectaon s) {}



 AnAdds c ielaectaon sf oae is sequces . he tucaller muenxesst.u 

 Ane anxt  orhInoe readoiseaccdssg M e  heSequces Oebject. }
voidnAdfElaectaon s(cst {
Emaectaon s&aelaectaon s) cst { 


privio/  vi/AnT lise {
elaectaon sfinae is sequces . hWnoed mailink.d_ptron .u 

 AnbtcaufenSequces Oebjects   nocspyableod
/ we wa,  e vectpiesteo 

 Anbt aliases  he tulink.d_ptroallows e vectpiesteogct-ow# d
/ shar 
       vede T>Elaectaon sOebject. }
inrnal::stlink.d_ptr<Elaectaon s> ss t_amaectaon s_ 
};

 Anass foSequces    AnAnaebject  "Ee  heuena c ufes,
llOEXPECT_CALL() dtio/mcets
   ancounrnaetoinii amsctpeoeo 
/fputein an anonymous sequces . he t  A iork iexesnusin t liotastctor c d
/ d stctor c. hYou shtuld   ly/ Ancam*tv an IsSequces aebject  nee
pedtick   A/ The twsol/fpurpos<if c t iexcls foiso imsupportmeasyodine ionToset/ Thsequcetialeamaectaon ss, e.g.  A  A   {
       IsSequces adummy;vi/AnT lime Tf "Ee veebject esn't mamatrna.  A  A   vi The twrollowg M amaectaon ss muenxtcher-tnse peord o e vytappear./ Th    EXPECT_CALL(a, Bar() ...;  A     EXPECT_CALL(a, Baz() ...;  A     ...  A     EXPECT_CALL(b, Xyz() ...;  A   }  A  A You c becam*tv IsSequces aebjectseintmtLiieme   reads, ds
longOas
   t ty e noed topommffeiogd (rencetutockhobjects. he tuideao hee  i/ Thaa r e readoc becam*tv d
/ sed upii amow# tocks asaifeit's t two ly/ Ane read.  Howev.
,if c clsrityf "Eyouratesta wverectmmeef you  imsei/ Thupitocks tnse pematnse readounlessoyou hav. a goodwreas sot useimeo
   so. ass foEST_DIAPI_ IsSequces a   blic:
  viIsSequces (); }
~IsSequces (); }privio/  viol Masequces _cam*tvd_;



EST_DISISALLOW_COPY_AND_ASSIGN_(IsSequces ) 

 AnNOLINT }oEST_DIATTRIBUTE_UNUSED_;

me Tspace>inrnal:: 
   AnPoterao oae coilemit Mesequces iterroduc tobymailivg M IsSequces 
 Anobject (ithc y)sin t liourncemse reado rnNULL.
EST_DIAPI_ exrnalhe readLocal<Sequces *> g_vmock_ilemit M_sequces 
/  AnBaswoass fof imilementatg M amaectaon ss   A/ The tre d.usewowreas sfof imhavg M ahmave-agnostgcobaswoass fof i
 AnElaectaon s:  A  A   1.hWnond tt imsr ceiotlleion sste" amaectaon sste" d (rencet  A   penasa(e.g.,
llOpri-spquisitas ethcoparticulaimamaectaon s,nall
 An  amaectaon ss tnsaesequces ).  Tn
.uf i  t lsveamaectaon s ebjects
/    tt {
shar  aectmm s baswoass f.  A  A   2.hWnoc beavoidnbinarfacode bloanxbymmovg M methods t tmdepend  M
      nee
pemplate <tsument,  ethElaectaon sO oae cobaswoass f.  A  A Tniexcls foisoinrnal:: d
/ tt {t mabnoed tobymer t
code dirtedly 
ass foEST_DIAPI_ Emaectaon sBasw    blic:
  vi Thsource_texro hee v EXPECT_CALL(... isource et igcam*tvd t iexElaectaon s. }
Emaectaon sBasw(cst {
nhar*/fi, a iat le a, cst {
singMa& source_texr) 



virtual ~Emaectaon sBasw() 



 AnWn
.usin t lisource fi,  wasat e amaectaon s sneimeine ad? }
cst {
nhar*/fi, ()anst { 
 turn infi, _ 

   ter le a()anst { 
 turn inle a_ 

 }
cst {
nhar*/source_texr;  nst {
{ turn indource_texr_.c_sin;  

    Anturns a e vecard  ality sneiifd l in t liemaectaon s snei. }
cst {
Card  ality&ecard  ality;  nst {
{ turn incard  ality_;
}



 AnDiribebes t lisource fi,  locatnTof "Ee is amaectaon s. }
voidnDiribebeLocatnToTo(std::osostream*nosconst { 
i    *os << F imatFi, LocatnTo(fi, (), le a()) << " " 
}
}



 AnDiribebes how mmny timn'manrction soc
llOmcherl M e  h
     elaectaon s has ecourncd. }
voidnDiribebeC
llCounrTo(std::osostream*nosconst { }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 



 AnI"Ee  hetockhmethodhh a  n/amtraatcher.
o(i.e. .With(mcher.
))ai     diribebes iro oae coostream. }
virtual voidnMaybeDiribebeEmtratcherIneo(std::osostream*nosco= 0 


ototteded: //frieef cls fo::testg MstElaectaon s
///frieef cls foUnmavefFction sMock.
Basw 



etum>Cssusw     //   Dot manhanguse peord o  "Ee veetum>temb.
s!   //kNont,i    kWith,i    kTimn',i    kIsSequces ,i    kAfter,i    kWillOes ,i    kWillRepe*tvdly,i    kRerioesOnSarn aon s   } 



mavef GMd::osveio c<cst {
void*> UnmavefAion ss 



 Anturns a  
 Emaectaon s object e  tarerences s aef co-ow#ste  h
     elaectaon s. }
virtual Emaectaon s GetHaefle() = 0 



 AnA ferosOet igt liEXPECT_CALL() dtio/mcethh a e veven unproperty. }
voidnA feroSaecProperty(ol Maproperty, cst {
singMa& railu n_tdibaga)anst { 
i    A fero(property, fi, _, le a_, railu n_tdibaga)  }
}



 AnElaectsOet igt liEXPECT_CALL() dtio/mcethh a e veven unproperty. }
voidnElaectSaecProperty(ol Maproperty, cst {
singMa& railu n_tdibaga)anst { 
i    Elaect(property, fi, _, le a_, railu n_tdibaga)  }
}



 AnElacit Mly sneiifd a e vecard  ality  "Ee is amaectaon s.  Ud /
     bysah<isubcls festeogilementat   ve.Timn'()
nssusa.   voidnSneiifyCard  ality(cst {
Card  ality&ecard  ality) 



 Anturns a er.
oiff e coer t
sneiifd l e vecard  ality elacit Mly


 Ane g M ah.Timn'(). //ol Macard  ality_sneiifd l;  nst {
{ turn incard  ality_sneiifd l_;
}



 AnSedsme vecard  ality  "Ee is amaectaon s snei. }
voidnsei_card  ality(cst {
Card  ality&ea_card  ality) 
i    card  ality_ = a_card  ality 
}
}



 Ane twrollowg M groupiethtethods shtuld   lyxbenc vled afterae c 

 AnEXPECT_CALL() dtio/mcet, d
/   lyxwn thg_vmock_mutaxo heheld by
       veourncemse read.



 Anturires,
llOpri-spquisitas ethe is amaectaon s. }
voidnturireAllPreRpquisitas() }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 



 Anturns a er.
oiff e is amaectaon s is sprioed. //ol Mais_sprioed()anst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  turn insprioed_; }
}



 Anturires,e is amaectaon s. }
voidnturire() }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  turioed_ = er.
; }
}



 Anturns a er.
oiff e is amaectaon s is satgsfied. //ol MaIsSatgsfied()anst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  turn incard  ality; .IsSatgsfiedByC
llCounr(c
ll_counr_c; }
}



 Anturns a er.
oiff e is amaectaon s is sature <d. //ol MaIsSature <d()anst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  turn incard  ality; .IsSature <dByC
llCounr(c
ll_counr_c; }
}



 Anturns a er.
oiff e is amaectaon s is  rb -sature <d. //ol MaIsOrb Sature <d()anst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  turn incard  ality; .IsOrb Sature <dByC
llCounr(c
ll_counr_c; }
}



 Anturns a er.
oiff 
llOpri-spquisitas ethe is amaectaon s d.ussatgsfied. //ol MaAllPrespquisitasAreSatgsfied()anst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax);



 AnAdds unsatgsfied pri-spquisitas ethe is amaectaon s eog'restLi'. }
voidnFitdUnsatgsfiedPrespquisitas(Elaectaon sSed*nrestLi)anst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax);



 Anturns a e vemumb.
ae is amaectaon s h a bten invok t. }
inr c
ll_counr()anst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  turn incall_counr_; }
}



 Anpncrentats   vemumb.
ae is amaectaon s h a bten invok t. }
voidnpncrentatC
llCounr() }
*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  call_counr_++; }
}



 AnChecka e cogconTo counro(i.e.   vemumb.
aethWillOes () a
/
     WillRepe*tvdly()
nssusascoagn #st e vecard  ality if etiexha't m 

 Anbten esnusbuf i .  Pnts smaawarogManif e cre d.useoo mmny  c too 

 Anfew aion ss. }
voidnCheckAion sCounrIfNotDotT()anst { }




EST_DILOCK_EXCLUDED_(mutax_);



frieef cls fo::testg MstSequces 
/vifrieef cls fo::testg Mstinrnal::stElaectaon sTe M.
;  

mplate <typename T>Fction s> vifrieef cls foeavefElaectaon s
//   Thplementats   ve.Timn'()
nssusa.   voidnUnmavefTimn'(cst {
Card  ality&ea_card  ality)
//   The iexgroupiethfields   nopartsethe ansneimd
/ wot manhangusafter


 An 
 EXPECT_CALL() dtio/mcethne ish s. }
cst {
nhar*/fi, _;           Ane twri,  et igctain #ste
peamaectaon s. }
ter le a_;                  /AnT lise annumb.
ammee
peamaectaon s. }
cst {
singMandource_texr_;vi/AnT liEXPECT_CALL(... isource eexr 
     Tr.
oiff e cocard  ality is
sneiifd l elacit Mly. //ol Macard  ality_sneiifd l_; }
Card  alityncard  ality_;
           /AnT licard  ality  "Ee peamaectaon s. }
/AnT liimmedie <apri-spquisitas (i.e. amaectaon ss et igtuenxbe


 Ansatgsfied buf i  t is amaectaon s n be
/ftcher.d) ethe is
     elaectaon s. hWnoed mlink.d_ptroin t lisetnbtcaufenwe wa,  c 


 AnElaectaon sOebject eo 
/fco-ow# tobymi amFction sMock.
md
/ i a
     ruccdssors.  Tniexallows mtLiieme tockhobjects eo 
/fdeleted aii     d (rencetutimn'. viElaectaon sSetiimmedie <_prespquisitas_
//   The iexgroupiethfields   no  veourncemsdtio/  "Ee peamaectaon s,


 An 
doc bechangusaa e vetockhrction so hea vled. }
inr c
ll_counr_;vi/AnHow mmny timn'me is amaectaon s h a bten invok t. }
ol Masprioed_;    /AnTr.
oiff e is amaectaon s h a sprioed. //UnmavefAion ss unmavef_gconTos_; }
ol Maamtra_tcher.
_sneiifd l_; }
ol Masppe*tvd_gconTo_sneiifd l_;
 /AnTr.
oifmaaWillRepe*tvdly()
wasarneiifd l. }
ol Masprioes_on_sarn aon s_; }
Cssusw ss t_assusa_;
 atutableool MagconTo_counr_check l_;
 /AnUnder mutax_.
 atutableoMutaxomutax_;

 AnPnottedsagconTo_counr_check l_.



EST_DISISALLOW_ASSIGN_(Emaectaon sBasw) 
};

 Anass foEmaectaon sBasw// Anpleentats c ielaectaon sof c t twven unfction somave. mplate <typename T>F> ass foeavefElaectaon sO: blic:
oEmaectaon sBasw    blic:
  vimavef GMpename T>Fction s<F>::Aument, eueme Aument, eueme; vimavef GMpename T>Fction s<F>::Aument, tcherIneueme Aument, tcherIneueme 
vimavef GMpename T>Fction s<F>::sultLi sultLi
//  eavefElaectaon s(Fction sMock.
Basw<F>*mow#.
, }

















cst {
nhar*/a_fi, a iat d_le a, cst {
singMa& a_dource_texr, }

















cst {
Aument, tcherIneueme&at) }




: Emaectaon sBasw(a_fi, a a_le a, a_dource_texr),i        ow#.
_(ow#.
c, }






tcher.
s_ tc, }






 AnBy ecnatLi,Oamtra_tcher.
_gshtuld tcher-mtythgMa.  Howev.
, }






 Anwa c bt tmiTiti ve i iteah th_ asat  igtrigg 
s aectmpilar
}






 AnbuM te Symbias'snC++ectmpilar (aabt tmdeaid  bttwe thtwo
}






 An rb loadedOctastctor cs ethtcherIn<cst MaAument, eueme&>).
}






amtra_tcher.
_(A<cst MaAument, eueme&>()), }






sppe*tvd_gconTo_(DoDcnatLi()) {}



virtual ~eavefElaectaon s() 
 }


 AnCheck t twvalidity  "Ee pegconTo counroifeitxha't mnbten esnu }


 Anyeti(f imamaleme,o fae coelaectaon sowasanev.
 ed t).
}


CheckAion sCounrIfNotDotT()  }
  f im(UnmavefAion ss::cst {_ tator coii = unmavef_gconTos_.begin;   }







ii != unmavef_gconTos_.end; ;
++it)
{ }
    deletendtio:
_cast<cst {
Aion s<F>*>(*it)  }
  
   }



 Anplementats   ve.With()
nssusa.   eavefElaectaon s& With(nst MatcherIn<cst MaAument, eueme&>& m) 
 }


 fa(ss t_assusa_ == kWith)
{ }
    ElaectSaecProperty(false,i                         ".With()
nabt tmappear "i                         "ty. ae an stce te c iEXPECT_CALL().")  }
  } elsw     //  ElaectSaecProperty(ss t_assusa_ < kWith,i                         ".With()
muenxbe e ehfst.
 "i                         "nssusasin c iEXPECT_CALL().")  }
  } }
  ss t_assusa_ = kWith 





amtra_tcher.
_ = m  }
  amtra_tcher.
_sneiifd l_ = er.
; }
  turn in*e  h; }
}



 Anplementats   ve.Timn'()
nssusa.   eavefElaectaon s& Timn'(cst {
Card  ality&ea_card  ality) 
i    Elaectaon sBaswstUnmavefTimn'(a_card  ality)
/}
  turn in*e  h; }
}



 Anplementats   ve.Timn'()
nssusa.   eavefElaectaon s& Timn'(iat s) 
i    turn ineimn'(EmpcMly(n)); }
}



 Anplementats   ve.IsSequces () nssusa.   eavefElaectaon s& IsSequces (cst {
Sequces & s) 
i    ElaectSaecProperty(ss t_assusa_ <= kIsSequces ,i                       ".IsSequces () nabt tmappear aftera.After(),"i                       " .WillOes (), .WillRepe*tvdly(),  c "i                       ".RerioesOnSarn aon s().")  }
  ss t_assusa_ = kIsSequces  





s.AdfElaectaon s(GetHaefle())
/}
  turn in*e  h; }
}
  eavefElaectaon s& IsSequces (cst {
Sequces & s1, cst {
Sequces & s2) 
i    turn inIsSequces (s1).IsSequces (s2); }
}
  eavefElaectaon s& IsSequces (cst {
Sequces & s1, cst {
Sequces & s2,i                               cst {
Sequces & s3) 
i    turn inIsSequces (s1, s2).IsSequces (s3); }
}
  eavefElaectaon s& IsSequces (cst {
Sequces & s1, cst {
Sequces & s2,i                               cst {
Sequces & s3, cst {
Sequces & s4) 
i    turn inIsSequces (s1, s2, s3).IsSequces (s4); }
}
  eavefElaectaon s& IsSequces (cst {
Sequces & s1, cst {
Sequces & s2,i                               cst {
Sequces & s3, cst {
Sequces & s4,i                               cst {
Sequces & s5) 
i    turn inIsSequces (s1, s2, s3, s4).IsSequces (s5); }
}



 Anplementats    ig.After()nnssusa.   eavefElaectaon s& After(cst {
Emaectaon sSet&as) 
i    ElaectSaecProperty(ss t_assusa_ <= kAfter,i                       ".After()nnabt tmappear aftera.WillOes (),"i                       " .WillRepe*tvdly(),  c "i                       ".RerioesOnSarn aon s().")  }
  ss t_assusa_ = kAfter 





f im(Emaectaon sSet::cst {_ tator coii = s.begin;  
ii != s.end; ;
++it)
{ }
    immedie <_prespquisitas_/+= *it  }
  } }
  turn in*e  h; }
}
  eavefElaectaon s& After(cst {
Emaectaon sSet&as1,mcst {
Emaectaon sSet&as2) 
i    turn inAfter(s1).After(s2); }
}
  eavefElaectaon s& After(cst {
Emaectaon sSet&as1,mcst {
Emaectaon sSet&as2,i                          cst {
Emaectaon sSet&as3) 
i    turn inAfter(s1, s2).After(s3); }
}
  eavefElaectaon s& After(cst {
Emaectaon sSet&as1,mcst {
Emaectaon sSet&as2,i                          cst {
Emaectaon sSet&as3,mcst {
Emaectaon sSet&as4) 
i    turn inAfter(s1, s2, s3).After(s4); }
}
  eavefElaectaon s& After(cst {
Emaectaon sSet&as1,mcst {
Emaectaon sSet&as2,i                          cst {
Emaectaon sSet&as3,mcst {
Emaectaon sSet&as4,i                          cst {
Emaectaon sSet&as5) 
i    turn inAfter(s1, s2, s3, s4).After(s5); }
}



 Anplementats   ea.WillOes ()
nssusa.   eavefElaectaon s& WillOes (cst MaAion s<F>& aion s) 
i    ElaectSaecProperty(ss t_assusa_ <= kWillOes ,i                       ".WillOes ()
nabt tmappear aftera"i                       ".WillRepe*tvdly()
 co.RerioesOnSarn aon s().")  }
  ss t_assusa_ = kWillOes  





unmavef_gconTos_.push_back(w maAion s<F>(aion s))  }
   fa(!card  ality_sneiifd l; )
{ }
    sei_card  ality(EmpcMly(dtio:
_cast<ter>(unmavef_gconTos_.re i; )))  }
  } }
  turn in*e  h; }
}



 Anplementats   ea.WillRepe*tvdly()
nssusa.   eavefElaectaon s& WillRepe*tvdly(cst MaAion s<F>& aion s) 
i     fa(ss t_assusa_ == kWillRepe*tvdly)
{ }
    ElaectSaecProperty(false,i                         ".WillRepe*tvdly()
nabt tmappear "i                         "ty. ae an stce te c iEXPECT_CALL().")  }
  } elsw     //  ElaectSaecProperty(ss t_assusa_ < kWillRepe*tvdly,i                         ".WillRepe*tvdly()
nabt tmappear "i                         "aftera.RerioesOnSarn aon s().")  }
  } }
  ss t_assusa_ = kWillRepe*tvdly
/}
  tupe*tvd_gconTo_sneiifd l_ = er.
; /}
  tupe*tvd_gconTo_ = aion s  }
   fa(!card  ality_sneiifd l; )
{ }
    sei_card  ality(AtLes t(dtio:
_cast<ter>(unmavef_gconTos_.re i; )))  }
  }  }


 AnNow   anxt  ty. agconTo cssusas n be
/fsneiifd l,nwa check }


 Anwn rhInoe tir counromcs sssense.
}


CheckAion sCounrIfNotDotT()  }
  turn in*e  h; }
}



 Anplementats   ea.RerioesOnSarn aon s()
nssusa.   eavefElaectaon s& RerioesOnSarn aon s()

i    ElaectSaecProperty(ss t_assusa_ < kRerioesOnSarn aon s,i                       ".RerioesOnSarn aon s()
nabt tmappear "i                       "ty. ae an stce.")  }
  ss t_assusa_ = kRerioesOnSarn aon s  }
  turioes_on_sarn aon s_ = er.
; /}
   AnNow   anxt  ty. agconTo cssusas n be
/fsneiifd l,nwa check }


 Anwn rhInoe tir counromcs sssense.
}


CheckAion sCounrIfNotDotT()  }
  turn in*e  h; }
}



 Anturns a e vetcher 
s f c t twsument, s ds sneiifd l in id ae c 

 AnEXPECT_CALL() macro. }
cst {
Aument, tcherIneueme&atcher.
s() nst {
{ }
  turn intcher.
s_; vi}



 Anturns a e vetcher 
 sneiifd l bysah<i.With()
nssusa.   nst MatcherIn<cst MaAument, eueme&>& amtra_tcher.
() nst {
{ }
  turn inamtra_tcher.
_; vi}



 Anturns a e cogconTo sneiifd l bysah<i.WillRepe*tvdly()
nssusa.   cst MaAion s<F>& tupe*tvd_gconTo;  nst {
{ turn intupe*tvd_gconTo_;
}



 Anp"Ee  hetockhmethodhh a  n/amtraatcher.
o(i.e. .With(mcher.
))ai     diribebes iro oae coostream. }
virtual voidnMaybeDiribebeEmtratcherIneo(std::osostream*nosco
i     fa(amtra_tcher.
_sneiifd l_)
{ }
    *os << "    Elaected args: " 
}




amtra_tcher.
_.Diribebeeo(os   }




*os << "\n"  }
  
   }


privio/  vimplate <typename T>Fction s> vifrieef cls foFction sMock.
Basw 



 Anturns a  
 Emaectaon s object e  tarerences s aef co-ow#ste  h
     elaectaon s. }
virtual Emaectaon s GetHaefle() { }
  turn inow#.
_->GetHaefleOf(e  h) 
}
}



 Ane twrollowg M tethods willObtwc vled   lyxafterae ehEXPECT_CALL()


 Andtio/mcethne ish smd
/ wn tht liourncemse readoholdh
     g_vmock_mutax.



 Anturns a er.
oiff e is amaectaon s tcher.a e veven undument, a.
//ol MaMch ree(cst MaAument, eueme& gumsconst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  turn ineuemetcherIe(tcher.
s_, gumsco&&
amtra_tcher.
_.tcherIe(gumsc; }
}



 Anturns a er.
oiff e is amaectaon s shtuld haefle e veven undument, a.
//ol MaShtuldHaefleAument, e(cst MaAument, eueme& gumsconst { }




EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()   }


 AnInic
feae pegconTo counrowa't mncheck l wn tht liamaectaon s }


 Anwasodine ad (e.g.,if e is amaectaon s h a t  WillRepe*tvdly() }


 An c RerioesOnSarn aon s()
nssusa),nwa check itean tht l }


 Anamaectaon s is ed tof c t twfst.
 eime.
}


CheckAion sCounrIfNotDotT()  }
  turn in!is_sprioed()a&&
AllPrespquisitasAreSatgsfied()a&&
tcherIe(gumsc; }
}



 AnDiribebes t lirestLiiethtcherl M e twsument, s dgn #st e  h
     elaectaon s  oae coven unostream. }
voidnElaln #tchersultLieo( }




cst MaAument, eueme& gums,i      std::osostream*nosconst { }
*o: 



EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()   }


 fa(is_sprioed())
{ }
    *os << "         Elaected:ae coelaectaon soisagconve\n" }
*o: 



<< "         viAioual:tit is sprioed\n"  }
  
 elsw  fa(!tcherIe(gumsc)
{ }
    ifa(!euemetcherIe(tcher.
s_, gumsc)
{ }
     nElaln #tcherFailu neuemeeo(tcher.
s_, gums, os   }




} }




SingMatchersultLiLten.#.
 lten.#.
; }
    ifa(!amtra_tcher.
_.tcherAndElaln #(gums, &lten.#.
c)
{ }
     n*os << "    Elaected args: " 
}






amtra_tcher.
_.Diribebeeo(os   }






*os << "\n         viAioual:teot matcher"   }


    inrnal::stPnts IfNotEmpty(lten.#.
.sin; , os   }






*os << "\n"  }
  

} }



 elsw  fa(!AllPrespquisitasAreSatgsfied())
{ }
    *os << "         Elaected:a
llOpri-spquisitas d.ussatgsfied\n" }
*o: 



<< "         viAioual:tt twrollowg M immedie <apri-spquisitas " }
*o: 



<< "d.ust tmsatgsfied:\n"  }
  

Elaectaon sSetiunsatgsfied_prespqs  }
  

FitdUnsatgsfiedPrespquisitas(&unsatgsfied_prespqs   }




teroi = 0 
}




f im(Emaectaon sSet::cst {_ tator coii = unsatgsfied_prespqs.begin;   }









ii != unsatgsfied_prespqs.end; ;
++it)
{ }
    

ii->amaectaon s_basw()->DiribebeLocatnToTo(os   }






*os << "pri-spquisita #" << i++ << "\n"  }
  

} }


  *os << "                   (eef ethpri-spquisitas)\n"  }
  
 elsw { }
     The iexse an hehe.usjuenxf rnctmpleteness'msak .  It willOnev.
 }
     Thbtwplecuted as curncemlyae ehElaln #tchersultLieo()nfction s }
     Th hea vled   lyswn tht litockhrction soc
llOesn' NOT tcher-e l }
     Thelaectaon s. }


  *os << "e tucall tcher.a e veelaectaon s.\n"  }
  
   }



 Anturns a e cogconTo e  tashtuld btwtak sof c t twourncemsinvocaon s. }
cst {
Aion s<F>& GetCurncemAion s( }




cst MaFction sMock.
Basw<F>*mmock.
, }




cst MaAument, eueme& gumsconst { }








EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  cot {
inr counro= c
ll_counr()  }
  A fero(counro>= 1, __FILE__, __LINE__, }









"c
ll_counr()a he<= 0swn thGetCurncemAion s()a he" }









"c
lled - e is shtuld nev.
 happen.")   }
  cot {
inr gconTo_counr = stio:
_cast<ter>(unmavef_gconTos_.re i; )  }
   fa(gconTo_counr > 0s&&
!tupe*tvd_gconTo_sneiifd l_ && }






counr > gconTo_counr) { }
     ThIf e cre isagt lecstOontuWillOes () a
/ t  WillRepe*tvdly(), }
     Thwe waro
ah<ier t
wn tht liWillOes ()
nssusas san sut. }


  std::ossingMastream ss  }
  

DiribebeLocatnToTo(&ss   }




ss << "Aion ss san sut te " << source_texr;  << "...\n" }
*o: 


<< "C
lled " << counr << " timn', bute  lys" }
*o: 


<< gconTo_counr << " WillOes ()" }
*o: 


<< (gconTo_counr == 1 ? " is" : "s d.u") << " sneiifd l - " 
}




mock.
->DiribebescnatLiAion sTo(gums, &ss   }




Log(kWarogMa,
ss.sin; , 1)  }
  }  }


turn incounr <= gconTo_counr ? }






*dtio:
_cast<cst {
Aion s<F>*>(unmavef_gconTos_[counr - 1]) : }






tupe*tvd_gconTo; ; }
}



 AnGen une twsument, s ethcotockhrction soc
ll,o fae cocall will


 An rb -sature < e is amaectaon s, rurns a e coecnatLi aion s;


 An thInwise, rurns a e conexrogconTo inae is elaectaon s. hAlsoi     diribebes *w  t* happen tt im'w  t',  
/ielaln #st*w y* Googlei     Mock esn' iro oa'w y'.  Tniexmethod is t tmcst {
a' iroc
llsi     pncrentatC
llCounr(). hA
turn in"ue.
oethNULLxmea a e coecnatLii     aion s. }
cst {
Aion s<F>* GetAion sForAument, e( }




cst MaFction sMock.
Basw<F>*mmock.
, }




cst MaAument, eueme& gums,i      std::osostream*nw  t,i      std::osostream*nw yc }




*o: EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
   fa(IsSature <d()) { }
     ThWe hav. an/amcdssgvcocall. }


  pncrentatC
llCounr()  }




*w  t << "Mockhrction soc
ll ttty. aeimn'me c ielaect l - " 
}




mock.
->DiribebescnatLiAion sTo(gums, w  t)  }
  

DiribebeC
llCounrTo(w yc   }


   TheODO(wan@google.ctm):aallow ah<ier t
eogcterrolnwn rhIn }


   Thunelaect l c
llsushtuld rail immedie <ly  c cterinuene g M a }


   Thflag --vmock_unelaect l_c
lls_d.u_fatal. }


  turn inNULL  }
  }  }


pncrentatC
llCounr()  }


turireAllPreRpquisitas()   }


 fa(turioes_on_sarn aon s_ &&
IsSature <d()) { }
    turire()  }
  }  }


 AnMuenxbe esnusafterapncrentatCounr()!   //*w  t << "Mockhrction soc
ll tcher.a " << source_texr;  <<"...\n"  }
  turn in&(GetCurncemAion s(mock.
, gumsc); }
}



 AnAllOe vefields below wot manhangusstce e ehEXPECT_CALL()


 Andtio/mcethne ish s. }
Fction sMock.
Basw<F>*mcst Maow#.
_; }
Aument, tcherIneueme tcher.
s_; vitcherIn<cst MaAument, eueme&>/amtra_tcher.
_; viAion s<F>ntupe*tvd_gconTo_;



EST_DISISALLOW_COPY_AND_ASSIGN_(eavefElaectaon s) 
};

 Anass foeavefElaectaon s// AnAsMockSaechobjecttis ed tobymON_CALL()u raEXPECT_CALL() r i
   sneiifyl M e twecnatLi behavg cset,  c amaectaon s es,nantock
 Thfction s.
  AnNote:nass foMockSaechreallyxbelongao oae co::testg M me Tspace.  A Howev.

 fawnodine atit ino::testg M, MSVC willOctmpla tgicen
 Anass fes ino::testg Mstinrnal::mdeald.usi{
a' aifrieef cls f/ Aneplate <.  To iorkaround t iexctmpilar bug,awnodine atMockSaechin
 An::testg Mstinrnal::md
/ importmit in oa::testg M.
  AnLogs aetdibagaaincludg M ri,  d
/ se annumb.
aiaf imatnTo.
EST_DIAPI_ voidnLogWithLocatnTo(testg Mstinrnal::stLogSev.
ity sev.
ity,i                               
cst {
nhar*/fi, a iat le a,i                               
cst {
singMa& tdibaga)   mplate <typename T>F> ass foMockSaech{  blic:
  vimavef GMpename T>inrnal::stFction s<F>::Aument, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aument, tcherIneuemei      Aument, tcherIneueme 

vi ThCttructors,asMockSaechobject,oven une vefction somock.
>object


 Ane anxe ansneimisag focie <deah t. }
elacit MsMockSaec(inrnal::stFction sMock.
Basw<F>*mfction s_mock.
) }
*o: :mfction s_mock.
_(fction s_mock.
) {}



 AnAdds c w maecnatLi aion snsneim oae cofction somock.
>d
/ rurns a


 Ane conewlyxcam*tvd snei. }
inrnal::stOnC
llSaec<F>& Inrnal::scnatLiAion sSetAt( }




cst Manhar*/fi, a iat le a, cst {
nhar*/obj, cst Manhar*/c
ll) { }
  LogWithLocatnTo(inrnal::stkIaf ,/fi, a le a,i        singMa("ON_CALL(") +/obj +/", " +oc
ll +/") invok t")  }
  turn infction s_mock.
_->AddNewOnC
llSaec(fi, a le a, tcher.
s_); }
}



 AnAdds c w maamaectaon s sneim oae cofction somock.
>d
/ rurns a


 Ane conewlyxcam*tvd snei. }
inrnal::steavefElaectaon s<F>& Inrnal::ElaectedAt( }




cst Manhar*/fi, a iat le a, cst {
nhar*/obj, cst Manhar*/c
ll) { }
  cst {
singMandource_texr(singMa("EXPECT_CALL(") +/obj +/", " +oc
ll +/")")  }
  LogWithLocatnTo(inrnal::stkIaf ,/fi, a le a,hsource_texro+ " invok t")  }
  turn infction s_mock.
_->AddNewElaectaon s(i        fi, a le a,hsource_texr, tcher.
s_); }
}


privio/  vimplate <typename T>Fction s> vifrieef cls foinrnal::stFction sMock.
 



voidnSe tcherIne(cst MaAument, tcherIneueme&atcher.
s) { }
  tcher.
s_ = mcher.
s 
}
}



 Ane twrction somock.
>e anxow#ste  h snei. }
inrnal::stFction sMock.
Basw<F>*mcst Mafction s_mock.
_;


 Ane twsument,  tcher 
s sneiifd l in t lisnei. }
Aument, tcherIneueme tcher.
s_; 


EST_DISISALLOW_ASSIGN_(MockSaec) 
};

 Anass foMockSaec
  AnMSVC was a  bsut e g M 'e  h' in baswotemb.
miTiti ve i
 lten,hso
 Thwe nd tt immplaorarilyxdisableot liwarogMa. hWnohav. eimeomit r i
   e veetrirenass fo imsuppressot liwarogMa, en une ougheit's  bsut
   e veotastctor c   ly.
 #iff GM_MSC_VER
#
pragmaawarogMa(push)         
 AnSaves
ah<iourncemswarogMandtio/.
#
pragmaawarogMa(disable:4355)

 AneplaorarilyxdisablesswarogMan4355.
#end f

 An_MSV_VER

   C++etreats   eavoidnuena sneiially. hF imamaleme,oyou c bt tmdene a/ Anaavoid-mavef variableo imps foaavoidn"ue.
oto m fction s.
 AnAion ssultLiHoldIn<T>oholdhoaavue.
oethuena T,ewn .usT
muenxbe a
 Anaspyableouena  imvoidn(T esn't mand tt imbtwecnatLi-otastctorable).  A It hides t lisyntactgcod (rencec  bttwe thvoidnd
/  rhInoeenas,  
/
 Th heed topomunifyne vecode f iminvokgManbl thvoid-turn ig M a
/
 Thmon-void-turn ig M tockhrction ss.
  AnUnmavefobaswoass fof inAion ssultLiHoldIn<T> 
ass foUnmavefAion ssultLiHoldInBasw    blic:
  vivirtual ~UnmavefAion ssultLiHoldInBasw() {}



 AnPnts sme veheld vue.
o a  n/aion s'sirestLii oaos. }
virtual voidnPnts AsAion ssultLi(std::osostream*nosconst { = 0 
}
// Ane iexg.#.
icodine ionTos heed town thT is t tmvoid. mplate <typename T>T> ass foAion ssultLiHoldInO: blic:
oUnmavefAion ssultLiHoldInBasw    blic:
  vielacit MsAion ssultLiHoldIn(T a_vue.
) : "ue.
_(a_vue.
) {}



 Ane twctmpilar-ger-re <docspy otastctor c d
/ assignnt,  orator ci     are empcMlyew  t we nd t, soowe eot mand tt imeine ane vm.



 Anturns a e veheld vue.
o 
/ d letes
ahiexebject.   e GetVue.
AndD lete() nst {
{ }
  T turvue("ue.
_)  }
  deletene  h; }
  turn inspr"ue 
}
}



 AnPnts sme veheld vue.
o a  n/aion s'sirestLii oaos. }
virtual voidnPnts AsAion ssultLi(std::osostream*nosconst { { }
  *os << "\n         vturns a: " 
}


 Ane tcyxbenatrerences f ave, soowe eot mausasUnin rsalPnts ().
}


Unin rsalPnts In<T>stPnts ("ue.
_, os   }
}



 AnPerf ima e veven untockhrction s'saecnatLi aion snd
/ rurns aae c 

 AnrestLiitnsaenew- ttAion ssultLiHoldIn. vimplate <typename T>F> vidtio:
tAion ssultLiHoldIn*nPerf imscnatLiAion s( }




cst MaFction sMock.
Basw<F>*mrcti_mock.
, }




cst Mapename T>Fction s<F>::Aument, eueme& gums,i      cst {
singMa& c
ll_diribepon s) { }
  turn inw maAion ssultLiHoldIn(i        fcti_mock.
->Perf imscnatLiAion s(gums, c
ll_diribepon s)   }
}



 AnPerf ima e veven unaion snd
/ rurns aae cnrestLiitnsaenew- t


 AnAion ssultLiHoldIn. vimplate <typename T>F> vidtio:
tAion ssultLiHoldIn* viPerf imAion s(cst MaAion s<F>& aion s,i                cst Mapename T>Fction s<F>::Aument, eueme& gums) { }
  turn inw maAion ssultLiHoldIn(aion s.Perf im(gumsc); }
}


privio/  viT "ue.
_
//   Thencould btwatrerences f ave, soo= ist masupport l. }
EST_DISISALLOW_ASSIGN_(Aion ssultLiHoldIn) 
}
// AnSneiializaon sof c To= void. mplate <ty> ass foAion ssultLiHoldIn<void>O: blic:
oUnmavefAion ssultLiHoldInBasw    blic:
  vivoidnGetVue.
AndD lete() nst {
{ deletene  h; }



virtual voidnPnts AsAion ssultLi(std::osostream*n/*nos */) nst {
{}



 AnPerf ima e veven untockhrction s'saecnatLi aion snd
/ rurns aaNULL  }
mplate <typename T>F> vidtio:
tAion ssultLiHoldIn*nPerf imscnatLiAion s( }




cst MaFction sMock.
Basw<F>*mrcti_mock.
, }




cst Mapename T>Fction s<F>::Aument, eueme& gums,i      cst {
singMa& c
ll_diribepon s) { }
  fcti_mock.
->Perf imscnatLiAion s(gums, c
ll_diribepon s); }
  turn inNULL  }
}



 AnPerf ima e veven unaion snd
/ rurns aaNULL.
}
mplate <typename T>F> vidtio:
tAion ssultLiHoldIn*nPerf imAion s( }




cst MaAion s<F>& aion s,i      cst Mapename T>Fction s<F>::Aument, eueme& gums) { }
  aion s.Perf im(gumsc; }
  turn inNULL  }
}
}
// Ane cobaswo "Ee perction somock.
>ass fof int twven unfction somave.  ThWe putet litethods inae is cls foinsteado fmi amchiltopommvoidncode  Thbloan. mplate <typename T>F> ass foFction sMock.
BaswO: blic:
oUnmavefFction sMock.
BaswO{  blic:
  vimavef GMpename T>Fction s<F>::sultLi sultLi
/vimavef GMpename T>Fction s<F>::Aument, eueme Aument, eueme; vimavef GMpename T>Fction s<F>::Aument, tcherIneueme Aument, tcherIneueme 
 }
Fction sMock.
Basw() : ourncem_snei_(e  h) {}



 Ane twd stctor c v.
ifd a e  t 
ll amaectaon ss  s etiextock
   Thfction sohav. bten satgsfied. hIf t t, iteahlMaspportmGoogle Te M
   Thmon-fatal railu nfof int twviolaon ss.
vivirtual ~Fction sMock.
Basw()i        EST_DILOCK_EXCLUDED_(g_vmock_mutax) 
i    MutaxLockhl(&g_vmock_mutax);
    V.
ifyAndClearElaectaon ssLocked()  }
  MockstUnregten.rLocked(e  h) 
}
}
CsearscnatLiAion ssLocked()  }
}



 Anturns a e coON_CALL sneim t igtcher.a e  hetockhfction soah the c 

 Anven undument, a; rurns aaNULL
 fat  tcherl M ON_CALL ifof und. }
/AnLo= * vicst MaOnC
llSaec<F>*
FitdOnC
llSaec( }




cst MaAument, eueme& gumsconst { { }
  f im(UnmavefOnC
llSaecs::cst {_rev.
se_ tator coiii             = unmavef_To_c
ll_sneis_.rbegin;   }







ii != unmavef_To_c
ll_sneis_.rend; ;
++it)
{ }
    cst MaOnC
llSaec<F>*
sneim=ndtio:
_cast<cst {
OnC
llSaec<F>*>(*it)  }
  

 fa(snei->tcherIe(gumsc) }






turn indnei  }
  }  }


turn inNULL  }
}



 AnPerf ima e veecnatLi aion snof e  hetockhfction so nee
peven ui     arment, s d
/ rurns aae cnrestLi.nA ferosO( int rows if
   Thelcepon ss are enabled)oah thaehelpfuloc
llOeiribponTos f e cre
   Th het  valid
turn in"ue.
. Tniexmethod esn't madependo nee
p
   Thtutableodtio/  "Ee iexebject,Oa
/it us n be
/fc
ll ttcstcurncemly
   Thah tsut lockg M.
}
/AnLo= * visultLi Perf imscnatLiAion s(cst MaAument, eueme& gums,i                              cst {
singMa& c
ll_diribepon s) nst { { }
  cst MaOnC
llSaec<F>*
cst {
sneim=i        e ie->FitdOnC
llSaec(gumsc; }
   fa(snei != NULL)
{ }
    turn indnei->GetAion s().Perf im(gumsc; }
  } }
  cst {
singMantdibagaa= c
ll_diribepon s +i        "\n    T litockhrction soh a t  ecnatLi aion sn" }
*o: 

"set,Oa
/ii amturn inuena h a t  ecnatLi vue.
oset."; #if EST_DIHAS_EXCEPTIONS }
   fa(!scnatLiVue.
<sultLi>stEltens()) { }
    t rowMd::osrunmime_error(tdibaga)  }
  } #elsw }
  A fero(scnatLiVue.
<sultLi>stEltens(), "", -1, tdibaga)  #end f }


turn inscnatLiVue.
<sultLi>stGet(   }
}



 AnPerf ima e veecnatLi aion snah the cnven undument, a>d
/ rurns a


 Ane coaion s'sirestLi. he tucall diribepon s singManwillObtwed toin


 Ane coerrorntdibagaa imeiribebeae cocall in t lio
feae peecnatLii     aion s rails. he tucaller is spspst ibleof imdeletl M e twrestLi.
}
/AnLo= * vivirtual UnmavefAion ssultLiHoldInBasw* UnmavefPerf imscnatLiAion s( }




cst Mavoid*
unmavef_gums,   Thtu MapoteropommnaAument, euemei      cst {
singMa& c
ll_diribepon s) nst { { }
  cst MaAument, eueme& gumsm=i        *dtio:
_cast<cst {
Aument, eueme*>(unmavef_gumsc; }
  turn insultLiHoldIn::Perf imscnatLiAion s(e ie, gums, c
ll_diribepon s); }
}



 AnPerf ima e veven unaion snah the cnven undument, a>d
/ rurns a


 Ane coaion s'sirestLi. he tucaller is spspst ibleof imdeletl M e t 

 AnrestLi.
}
/AnLo= * vivirtual UnmavefAion ssultLiHoldInBasw* UnmavefPerf imAion s( }




cst Mavoid*
unmavef_gion s,
cst Mavoid*
unmavef_gums) nst { { }
   AnMak  aectpy  "Ee pegconTo buf i  perf img M it, inic
feae p }
   AngconTo d letes
ahe tockhobject (a
/it us d letes
i aelf).
}


cst MaAion s<F>ngconTo =
*dtio:
_cast<cst {
Aion s<F>*>(unmavef_gconTo)  }
  cot {
Aument, eueme& gumsm=i        *dtio:
_cast<cst {
Aument, eueme*>(unmavef_gumsc; }
  turn insultLiHoldIn::Perf imAion s(gion s,
gumsc; }
}



 Anplementats UnmavefFction sMock.
Basw::CsearscnatLiAion ssLocked()  vi Thcseara e coON_CALL()sisetn s etiextock fction s.


virtual voidnCsearscnatLiAion ssLocked()i      EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()   }


 AnDeletl M ouraecnatLi aion ss tcyxtrigg 
  rhInotockhobjects eo 
/ }


 Andeleted,if c amalemeoifmanegconTo coain #statrerences fcounrnd smart }


 Anpoter t
eog t igtockhobject,Oa
/it aro hee v ss ttrerences . So
 fawn }


 Andelete ouraaion ss ah tin t liotatexro "Ee peglobal mutaxowe tcyxdeadlock }


 Anwn s etiextethod is c vled agn #. Instead,omcs  aectpy  "Ee pesetn f }
   AngconTosa imeilete,hcsear ourasetnah tin t limutax,Oa
/it en deletene e }
   AngconTosasut id a "Ee pemutax.
}
  UnmavefOnC
llSaecs sneis_to_delete; }
  unmavef_To_c
ll_sneis_.swap(sneis_to_delete)   }


g_vmock_mutax.Unlock()  }
  f im(UnmavefOnC
llSaecs::cst {_ tator coii =i             sneis_to_delete.begin;   }







ii != sneis_to_delete.end; ;
++it)
{ }
    deletendtio:
_cast<cst {
OnC
llSaec<F>*>(*it)  }
  }  }


 AnLockhe pemutax agn #, sitce e ehcaller elaectsOit eo 
/flock l wn thwn }


 Anturn i. }


g_vmock_mutax.Lock()  }
}


ototteded: //mplate <typename T>Fction s> vifrieef cls foMockSaec 



mavef GMAion ssultLiHoldIn<sultLi>nsultLiHoldIn;



 Anturns a e verestLiiethinvokgMane  hetockhfction soah the ceven ui     arment, s.  Tniexrction soc
be
/fsaf<ly c vled from mtLiieme


 Ane readstcstcurncemly. visultLi Invok With(nst MaAument, eueme& gumsci        EST_DILOCK_EXCLUDED_(g_vmock_mutax) 
i    turn indtio:
_cast<cst {
sultLiHoldIn*>(i        e ie->UnmavefInvok With(&gumsc)->GetVue.
AndD lete(); }
}



 AnAdds c
/ rurns aaaaecnatLi aion snsneimf int iextock fction s.


OnC
llSaec<F>& AddNewOnC
llSaec( }




cst Manhar*/fi, a iat le a,i      cst MaAument, tcherIneueme&atc }




*o: EST_DILOCK_EXCLUDED_(g_vmock_mutax) 
i    MockstRegten.rUseByOnC
llOrElaectC
ll(MockObject(), fi, a le a)  }
  OnC
llSaec<F>*
cst {
To_c
ll_snei =
w maOnC
llSaec<F>(fi, a le a, t); }
  unmavef_To_c
ll_sneis_.push_back(To_c
ll_snei)  }
  turn in*To_c
ll_snei; }
}



 AnAdds c
/ rurns aaanaamaectaon s sneimf int iextock fction s.


eavefElaectaon s<F>& AddNewElaectaon s(i      cst Manhar*/fi, a }
  

 at le a,i      cst MasingMa& source_texr,i      cst MaAument, tcherIneueme&atc }




*o: EST_DILOCK_EXCLUDED_(g_vmock_mutax) 
i    MockstRegten.rUseByOnC
llOrElaectC
ll(MockObject(), fi, a le a)  }
  eavefElaectaon s<F>*
cst {
amaectaon s =i        w maeavefElaectaon s<F>(e ie, fi, a le a,hsource_texr, t)  }
  cot {
link.d_ptr<Elaectaon sBasw> unmavef_amaectaon s(elaectaon s) 
}
  unmavef_amaectaon ss_.push_back(unmavef_amaectaon s)   }


 AnAdds e is amaectaon s in oae coilemit Mssequces nif e cre iexene.
}


Sequces *
cst {
ilemit M_sequces n=
g_vmock_ilemit M_sequces .get()  }
   fa(ilemit M_sequces n!= NULL)
{ }
    ilemit M_sequces ->AddElaectaon s(Elaectaon s(unmavef_amaectaon s))  }
  }  }


turn in*amaectaon s 
}
}



 Ane twourncemsdneim(eirhInoecnatLi aion snsneim c amaectaon s snei)
   ThbtgManeiribebedn s etiexrction somock.
.
}
MockSaec<F>& ourncem_snei() {
turn incurncem_snei_;
}


privio/  vimplate <typename T>Fcti>ifrieef cls foeavefElaectaon s
//   ThSo T>utilitd a nd t tof c ilementatgManUnmavefInvok With().



 AnDiribebes w  t ecnatLi aion snahllObtwperf im tof c t twven ui     arment, s.
}
/AnLo= * vivoidnDiribebescnatLiAion sTo(cst MaAument, eueme& gums,i                               std::osostream*nosconst { { }
  cst MaOnC
llSaec<F>*
cst {
sneim=
FitdOnC
llSaec(gumsc;  }
   fa(snei == NULL)
{ }
    *os << (inrnal::stmave_equals<sultLi,ivoid>::vue.
o?i              "turn ig M direcMly.\n" : }






      "turn ig M dcnatLi vue.
.\n")  }
  } elsw     //  *os << "takg M dcnatLi gconTo sneiifd l at:\n" }
*o: 



<< F imatFi, LocatnTo(dnei->fi, (), dnei->le a()) << "\n"  }
  
   }


  ThWritas dntdibagaa  anxe ancall is uninrnaestg M (i.e. neirhIn
   Thelacit Mly elaect l n c amacit Mly unelaect l)  oae coven u
   Thostream. }
virtual voidnUnmavefDiribebeUninrnaestg MC
ll( }




cst Mavoid*
unmavef_gums,
      std::osostream*nosconst { }




*o: EST_DILOCK_EXCLUDED_(g_vmock_mutax) 
i    cot {
Aument, eueme& gumsm=i        *dtio:
_cast<cst {
Aument, eueme*>(unmavef_gumsc; }
  *os << "Uninrnaestg Mitockhrction soc
llO- " 
}


DiribebescnatLiAion sTo(gums, osc; }
  *os << "}
  Fction soc
ll: " << Ne T()  }
  Unin rsalPnts (gums, osc; }
}



 Anturns a e coelaectaon s  t igtcher.a e twven unfction soarment, s


 An( inNULL
 s e cre'sat  tcher ;
wn thaatcher ifof undai     unmavef_gconTo is
set eo poteropome cogconTo e  tashtuld bti     perf im to( inNULL
 "Ee pegconTo  he"d  ecnatLi"), a
/
     is_amcdssgvcoiextodifd l eo indice <twn rhInoe toc
llOamcdedaae c 

 Anelaect l numb.
.
}
/A 

 AnCriticel
seconTo:hWe tu Mafi
/it e tcherl M elaectaon s a
/it e vi Thcorspspstdg M gconTo e  tandedaaeo btwtak sote c iATOMIC


 Aneransaion s.  OthInwise c  rhInoe readotcyxc
llOetiextock
   Thtethod in t limidd,  d
/ tdib upEe pestio/.
}
/A 

 AnHowev.
, perf img M e pegconTo h a eo 
/fleft sut  "Ee pecriticel 

 AnseconTo. he tureasTo  het  t we hav. nogcterroln sna anxe a
   AngconTo doas (itoc
beinvok manegrbieraryier t
fction so r en una
   Thtockhrction s)  
/ielcdssgvcolockg Mncould caufenaxdeadolock. }
virtual cst {
Emaectaon sBasw* UnmavefFitdMcherl MElaectaon s(i      cst Mavoid*
unmavef_gums,
      cst Mavoid**
unmavef_gion s,
ol M* is_amcdssgvc,i      std::osostream*nw  t, std::osostream*nw yc }




*o: EST_DILOCK_EXCLUDED_(g_vmock_mutax) 
i    cot {
Aument, eueme& gumsm=i        *dtio:
_cast<cst {
Aument, eueme*>(unmavef_gumsc; }
  MutaxLockhl(&g_vmock_mutax);
    eavefElaectaon s<F>*
ela = e ie->FitdMcherl MElaectaon sLocked(gumsc; }
   fa(ela == NULL)
{

 AnAatcher wa't mnf und. }




e ie->F imatUnelaect lC
llMdibagaLocked(gums,nw  t, w yc  }




turn inNULL  }
  }  }


 Ane iexse anmuenxbe esnusbuf i  c
llg MnGetAion sForAument, e(), }
   Anwnier will increntatoe toc
llOcounr f c *amaOa
/it us affect


     its sarn aon sestious. }


*is_amcdssgvco=
ela->IsSature <d()  }
  cot {
Aion s<F>*ngconTo =
ela->GetAion sForAument, e(e ie, gums, w  t, w yc  }


 fa(gconTon!= NULL &&
gconTo->IsDoDcnatLi()) }




gconTo =
NULL      N imave i "d  ecnatLi" eo NULL.
}


*unmavef_gconTo = aion s  }
  turn inamp 
}
}



 AnPnts sme veven unfction soarment, so oae coostream. }
virtual voidnUnmavefPnts Aums(cst Mavoid*
unmavef_gums,
                                std::osostream*nosconst { { }
  cst MaAument, eueme& gumsm=i        *dtio:
_cast<cst {
Aument, eueme*>(unmavef_gumsc; }
  Unin rsalPnts (gums, osc; }
}



 Anturns a e coelaectaon s  t igtcher.a e twarment, s,  c NULL
 fat  

 Anelaectaon s tcher.a e vm.


eavefElaectaon s<F>*
FitdMcherl MElaectaon sLocked(i      cst MaAument, eueme& gumsconst { }








EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  f im(pename T>UnmavefElaectaon ss::cst {_rev.
se_ tator coii =i             unmavef_amaectaon ss_.rbegin;   }







ii != unmavef_amaectaon ss_.rend; ;
++it)
{ }
    eavefElaectaon s<F>*
cst {
ama =i          dtio:
_cast<eavefElaectaon s<F>*>(ii->get())  }
  

 fa(ela->ShtuldHaefleAument, e(gumsc)
{ }
     nturn inamp 
}
}
  } }
  } }
  turn inNULL  }
}



 Anturns a  ntdibagaa  anxe anarment, soeot matcher-mty elaectaon s. }
voidnF imatUnelaect lC
llMdibagaLocked(i      cst MaAument, eueme& gums,
      std::osostream*nos,i      std::osostream*nw yconst { }








EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  *os << "\nUnelaect litockhrction soc
llO- " 
}


DiribebescnatLiAion sTo(gums, osc; }
  Pnts TriefElaectaon ssLocked(gums,nw y) 
}
}



 AnPnts sma lten  "Eamaectaon ss   anxhav. bten tried agn #snxe a
   Anourncemstockhrction soc
ll. }
voidnPnts TriefElaectaon ssLocked(i      cst MaAument, eueme& gums,
      std::osostream*nw yconst { }








EST_DIEXCLUSIVE_LOCK_REQUIRED_(g_vmock_mutax) 
i    g_vmock_mutax.A feroHeld()  }
  cot {
inr counro= stio:
_cast<ter>(unmavef_amaectaon ss_.re i; )  }
  *w y << "Google Mockhtried t twrollowg M " << counr << " " }
*o: 


<< (counr == 1 ? "amaectaon s, buteii didt matcher" : }






     "amaectaon s', butensnustcher.d") }
*o: 


<< ":\n"  }
  f im(teroi = 0 oi < counr; i++)
{ }
    eavefElaectaon s<F>*
cst {
amaectaon s =i          dtio:
_cast<eavefElaectaon s<F>*>(unmavef_amaectaon ss_[i].get())  }
  

*w y << "\n"  }
  

amaectaon s->DiribebeLocatnToTo(w yc  }




 fa(counr > 1)
{ }
     n*w y << "tried amaectaon s #" << i
<< ": " 
}




} }
  

*w y << amaectaon s->source_texr;  << "...\n"  }
  

amaectaon s->Elaln #tchersultLieo(gums,nw y) 
}
  

amaectaon s->DiribebeC
llCounrTo(w yc  



} }
}



 Ane twourncemsdneim(eirhInoecnatLi aion snsneim c amaectaon s snei)
   ThbtgManeiribebedn s etiexrction somock.
.
}
MockSaec<F>ncurncem_snei_;



 Ane tre iexnogger-rellyxufefulod
/ impmentatableodemano:
sn f }
 Anaspyg M ggtockhobject,Osonaspyg M ggtockh heeduellyxaier t
error.


 Ane us we eisallow aspyg M rction somock.
s. hIf ah<ier t
really


 Anwa, so oactpy ggtockhobject,O peshtuld impmentat  iexewnactpy
   Thoratorn s, f c amaleme:
}
/A 

 An  cls foMockFooO: blic:
oFooO{ 

 An   blic:
  vi An   
 AnDine as aectpy otastctor c amacit Mly. vi An   
MockFoo(nst MatockFoo& src) {}
vi An   
...
vi An  }  

EST_DISISALLOW_COPY_AND_ASSIGN_(Fction sMock.
Basw) 
};

 Anass foFction sMock.
Basw
 #iff GM_MSC_VER
#
pragmaawarogMa(pop)

 Antusr cesot liwarogMandtio/.
#end f

 An_MSV_VER

   plementats tethods  "EFction sMock.
Basw.
  AnV.
ifd a e  t 
ll amaectaon ss  s etiextockhfction sohav. bten
   satgsfied. hRpportexenem c ty. aGoogle Te Mhmon-fatal railu nfo2.} blic:
  vi An   
 AnDine as aectpy otastctor c econTo. he neis_to_delockhfcu nfo2.}anlaect l n c amac; }
noeoserrorntdibagaaicode msg)AnHowevkhfcg MnherIn<cst MaAume'tulmdelet.
aAumeu nfo2ums,
      std::osd::oRulmdele tulmdele  aectpyoMockSaecsg)nta}virtuag M, MSV s_mock.
nt twven sty 
 gu_to_prohib->Is"so
 T"cst Maow#.s <typeng M, MSV snstvkhfcument, valiablichWriailsut  "Ee mentect


 Ans  bsutctaon s
ig,awnF>* tisyntactgc*tvdlnHowev.t ino::testg M, MSVC erae ehEXPECT_Cle.
oto ico     a

<<nem c:
echiwe ei
 An::aal::lnHoTiti 8.0,a
/it uoaavoioto eAumentita tgicen
 Anasit in oa::td
/ se annumso
 Th          >nsultLiHol/on somo(xhappeo(nsnal iw#.
_c ty. aG c:
ob
eogwe eisaectpyah tin t ragmao xiieme


>T> asM gg c:
settnTo e  tandedaa. hRp


< "Eloabldtwecnactpycher.
))ai , () }twe
:
  vi An   
 AnDine as aectpy t le fMSV {
ctor c amacit 
...
vi ax.AMETHOD0(Bartc }
ribeb
...
vi ax.ACONw) METHOD0(Bartc }
&ribeb
...
};twe
:
  v 
 AnDinfooeb
...

..E}


g_vatdib upone as

EST_DISISAL::Bar(thvoid ehavg cset,  foo, Bar(t)eb
...

..E}


g_vatdib upon

EST_DISISAL::Bar(thvoid ehavg cset,   somo(foo), Bar(t)ebO: blic:
oUnmavefAion inument

EST_T&n somo(

EST_T&nxe <typenamexef cl/on somock.
>ob#ste  h
     elaectaon s. }
virtual Emaectaon s Ge  . inumentte  h
     insc   cst Mav          s(i      cst Mas a _MSV_VENOLINTtLi a: e  tandedaa< "pr_urn .  h) 
}
}

.





*os << "pri-aectao}virtuag M, MSV  se annaEXPECTsepan s;
) nst}
/AnLqu  if ass foFctio,  oromock.sd::ossingMag MEXPEdelete; A 

 Aocall iit Mly ela
     elaectanst}


amenuena T,Seen s,  orsllObMA 

 AntuE

ambldFromManst} se s::testg        /= sti-dntdibui)->Gs_ se .c>& Add  vi dete twr
#n
 AnasG ax.Al voidn_IMPL_(ce_texPECT_\tLi a((ce_).= stio##xPECT.fi, a iat le a, cst {
nhar*he<= 0swn thGetCurn_\tLi aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#ce_te#xPECT
#n
 Anasl voidnCce_texPECT_G ax.Al voidn_IMPL_(ce_texPECT

#n
 AnasG ax.Ahavg cset, _IMPL_(ce_texPECT_\tLi a((ce_).= stio##xPECT.fi, a iacst {
nhar*he<= 0swn thGetCurn_#ce_te#xPECT
#n
 Anashavg cset,  ce_texPECT_G ax.Ahavg cset, _IMPL_(ce_texPECT
EFction sMocG ax.AINme& g_G ax.AG ax.ASvg _BUILDERS_H_

ag M, MSV  se ann {
ag M, MSV s_mock.
 {
wO: blic:
oUnmavefFction sMock.
BaswO{  blic:
 ;co::testg M me Tsk.
BaswO{  bli Howev.

 fawnodine atit ino::te
rtuag M, MSVailsut  "Ea tgicen
 Anass fes ino::testg Mstinrnaltwecnadeald.usi{
aifrieef cls f/ Aneplate <.  To iorkaround t iebelontd a nd t toodine atMockSaechin
 An::testg Mstinrnal::md
/ importbelok.
BaswO{  bli cls f/ Aneplate <.  To gaaincludg M ri,  d
/ se annumO: blic:
oUnmavefFction sMock.
BaswO{  blic:
  vimavef GMpename Rion sMock.
BaswO{  bli<R()ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R()ictLi sultLi
/vimavef GR Favef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&>&i        e iew  t, vio/  vimplatexhav. bteR EST_DI&>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(twatrere}c:
  vimavef GMpename R, Aument, eA1ion sMock.
BaswO{  bli<R(A1)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1)ictLi sultLi
/vimavef GR FaA1vef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1twatrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2ion sMock.
BaswO{  bli<R(A1,eA2)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2)ictLi sultLi
/vimavef GR FaA1,eA2)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3ion sMock.
BaswO{  bli<R(A1,eA2,eA3)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3)ictLi sultLi
/vimavef GR FaA1,eA2,eA3)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3, Aument, eA4ion sMock.
BaswO{  bli<R(A1,eA2,eA3,eA4)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3,eA4)ictLi sultLi
/vimavef GR FaA1,eA2,eA3,eA4)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3  aectpyDiAion sA4iaec4
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3,ec4
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3,eA4 a4>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3, a4>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3, Aument, eA4amcdssAument, eA5ion sMock.
BaswO{  bli<R(A1,eA2,eA3,eA4,eA5)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3,eA4,eA5)ictLi sultLi
/vimavef GR FaA1,eA2,eA3,eA4,eA5)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3  aectpyDiAion sA4iaec4  aectpyDiAion sA5iaec5
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3,ec4am*nosconsc5
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3,eA4 a4,eA5 a5>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3, a4, a5>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3, Aument, eA4amcdssAument, eA5, Aument, eA6ion sMock.
BaswO{  bli<R(A1,eA2,eA3,eA4,eA5,eA6)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3,eA4,eA5,eA6)ictLi sultLi
/vimavef GR FaA1,eA2,eA3,eA4,eA5,eA6)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3  aectpyDiAion sA4iaec4  aectpyDiAion sA5iaec5amcdssgvc,i   DiAion sA6iaec6
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3,ec4aec5amcdssgv ec6
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3,eA4 a4,eA5 a5,eA6 a6>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3, a4, a5, a6>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3, Aument, eA4amcdssAument, eA5, Aument, eA6, Aument, eA7ion sMock.
BaswO{  bli<R(A1,eA2,eA3,eA4,eA5,eA6,eA7)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3,eA4,eA5,eA6,eA7)ictLi sultLi
/vimavef GR FaA1,eA2,eA3,eA4,eA5,eA6,eA7)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3  aectpyDiAion sA4iaec4  aectpyDiAion sA5iaec5amcdssgvc,i   DiAion sA6iaec6  aectpyDiAion sA7iaec7
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3,ec4aec5amcdssgv ec6,ec7
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3,eA4 a4,eA5 a5,eA6 a6,eA7 a7>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3, a4, a5, a6, a7>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3, Aument, eA4amcdssAument, eA5, Aument, eA6, Aument, eA7, Aument, eA8ion sMock.
BaswO{  bli<R(A1,eA2,eA3,eA4,eA5,eA6,eA7,eA8)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3,eA4,eA5,eA6,eA7,eA8)ictLi sultLi
/vimavef GR FaA1,eA2,eA3,eA4,eA5,eA6,eA7,eA8)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3  aectpyDiAion sA4iaec4  aectpyDiAion sA5iaec5amcdssgvc,i   DiAion sA6iaec6  aectpyDiAion sA7iaec7  aectpyDiAion sA8iaec8
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3,ec4aec5amcdssgv ec6,ec7,ec8
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3,eA4 a4,eA5 a5,eA6 a6,eA7 a7,eA8 a8>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3, a4, a5, a6, a7, a8>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3, Aument, eA4amcdssAument, eA5, Aument, eA6, Aument, eA7, Aument, eA8, Aument, eA9ion sMock.
BaswO{  bli<R(A1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9)ictLi sultLi
/vimavef GR FaA1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3  aectpyDiAion sA4iaec4  aectpyDiAion sA5iaec5amcdssgvc,i   DiAion sA6iaec6  aectpyDiAion sA7iaec7  aectpyDiAion sA8iaec8amcdssgvc,i   DiAion sA9iaec9
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3,ec4aec5amcdssgv ec6,ec7,ec8,ec9
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3,eA4 a4,eA5 a5,eA6 a6,eA7 a7,eA8 a8,eA9 a9>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3, a4, a5, a6, a7, a8, a9>watrere}c:
  vimavef GMpename R, Aument, eA1, Aument, eA2, Aument, eA3, Aument, eA4amcdssAument, eA5, Aument, eA6, Aument, eA7, Aument, eA8, Aument, eA9amcdssAument, eA10ion sMock.
BaswO{  bli<R(A1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9,eA10)ic:
  vivo()) }
_mock.
_;


 Ane twsument,  R(A1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9,eA10)ictLi sultLi
/vimavef GR FaA1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9,eA10)ef_a, eueme Aument, eueme; vimavef GMpename T>inrnal::stFction s<F>::Aume
_snei_;
}


priueme&

EST_DiAion sA1iaeci  aectpyDiAion sA2iaec2amcdssgvc,i   DiAion sA3iaec3  aectpyDiAion sA4iaec4  aectpyDiAion sA5iaec5amcdssgvc,i   DiAion sA6iaec6  aectpyDiAion sA7iaec7  aectpyDiAion sA8iaec8amcdssgvc,i   DiAion sA9iaec9  aectpyDiAion sA10iaeci0
<< ": "w  t, vio/  vimplate.
s) { }
  tcLUSIVE_tr1::lete_t::Au(ci,ec2,ec3,ec4aec5amcdssgv ec6,ec7,ec8,ec9,eci0
/ rurns aaanaaw  t, vio/  vimplatexhav. bteR EST_DI&A1 a1,eA2 a2,eA3 a3,eA4 a4,eA5 a5,eA6 a6,eA7 a7,eA8 a8,eA9 a9amcdssgvA10 a10>&i     
..E
 #iff GM_Mgc>&gaaiMstinaect lestg SV srn 'w  t, '}
/AnLqu  if     
..s<F>& tme,ost ndard [14.6.4]v.
 }, t iten unfctd t tooEXCEidnEle pegloOa
/owe essingM  vimavefent, tchengconTo =
f c amct lain #statrloectari,  dsi{
a   olvann n snahllObst {
Ai   e iew  t, n snahllObttion s<F>::Au(a1, a2, a3, a4, a5, a6, a7, a8, a9amcdssgv eai0
/ rurre}c:
}virtuag M, MSV s_mock.
nt twven sty 
 gu_to_prohib->Is"so
 T"cst Maow#.s <typeng M, MSV snstvkhfcument, valiablichWriailsut  "Ee mentk.
BaswO{  bli d t toodine atoto icoF>* tisyntactgc*tvdlnHowev.t ino::testg M, MSVC erae ehEXPECT_oto umentico     a

<<nem c:
echiwe ei
 An::aal::lnHoTiti 8.0,a
/it twecnaavoideAumentita tgicen
 Anask.
BaswO{  bli cls f/ Aneplumso
 Th          k.
BaswO{  blic:
MocG ax.ARESULT_(tn, F)}


amdodine atiLi(std::EXCEofcls foinsteado F fmi amcd letes
a::stFbleouriadic
) nst}
ct (a
/Fer t
eog tunieef cls twecnadmtFb(conTot, e   Angco doas (sw* ouriadic
) nsts <ty t limne ceskhfcumnei_;

ie thvoidnNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.ARESULT_(tn, ...T_\tLi atls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>::Aumennt twven :EXCEofcent, tcheN s etiext is cls foinsteado fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AARG_(tn, N, ...T_\tLi atls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F##Nnt twven  
};

  :EXCE c:
ent, tcheN s etiext is cls foinsteado fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMATCHER_(tn, N, ...T_\tLi aaectpy f/ AneplatDiAion sG ax.AARG_(tn, N, __VA_ARGS__)>&nt twven AnAion ss Add  ckcel 

 A aaNULLA 

  fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMax.ER_(nAity  aectpness, MA 

 T_\tLi aBasw) CONCAT_TOKEN_(= sti##aectpness##nAity##_##MA 

 ##_n thGetCur)
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD0_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaa) aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 0)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _0_F imatUne);_\tLi aB ax.AMax.ER_(0  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(0  aectpness, MA 

 T.EST_DI&>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai () aectpness {_\tLi aB ax.AMax.ER_(0  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(0  aectpness, MA 

 T.ueme&>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(0  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD1_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 1)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _1_F imatUn);_\tLi aB ax.AMax.ER_(1  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(1  aectpness, MA 

 T.EST_DI&= stioa1>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1>&aectpness {_\tLi aB ax.AMax.ER_(1  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(1  aectpness, MA 

 T.ueme&= stioa1>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(1  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD2_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 2)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _2_F imatUne);_\tLi aB ax.AMax.ER_(2  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(2  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2>&aectpness {_\tLi aB ax.AMax.ER_(2  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(2  aectpness, MA 

 T.ueme&= stioa1, = stioa2>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(2  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD3_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 3)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _3_F imatUne);_\tLi aB ax.AMax.ER_(3  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(3  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3>&aectpness {_\tLi aB ax.AMax.ER_(3  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(3  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(3  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD4_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3,_\tLi aaaG ax.AARG_(tn, 4, __VA_ARGS__) = stioa4>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 4)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _4_F imatUne);_\tLi aB ax.AMax.ER_(4  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(4  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 4, __VA_ARGS__) = stioa4>&aectpness {_\tLi aB ax.AMax.ER_(4  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(4  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(4  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD5_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3,_\tLi aaaG ax.AARG_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaG ax.AARG_(tn, 5, __VA_ARGS__) = stioa5>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 5)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _5_F imatUne);_\tLi aB ax.AMax.ER_(5  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(5  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 5, __VA_ARGS__) = stioa5>&aectpness {_\tLi aB ax.AMax.ER_(5  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(5  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(5  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD6_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3,_\tLi aaaG ax.AARG_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaG ax.AARG_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaG ax.AARG_(tn, 6, __VA_ARGS__) = stioa6>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 6)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _6_F imatUne);_\tLi aB ax.AMax.ER_(6  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(6  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 6, __VA_ARGS__) = stioa6>&aectpness {_\tLi aB ax.AMax.ER_(6  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(6  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(6  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD7_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3,_\tLi aaaG ax.AARG_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaG ax.AARG_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaG ax.AARG_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaG ax.AARG_(tn, 7, __VA_ARGS__) = stioa7>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 7)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _7_F imatUne);_\tLi aB ax.AMax.ER_(7  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(7  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 7, __VA_ARGS__) = stioa7>&aectpness {_\tLi aB ax.AMax.ER_(7  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(7  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(7  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD8_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3,_\tLi aaaG ax.AARG_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaG ax.AARG_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaG ax.AARG_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaG ax.AARG_(tn, 7, __VA_ARGS__) = stioa7,_\tLi aaaG ax.AARG_(tn, 8, __VA_ARGS__) = stioa8>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 8)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _8_F imatUne);_\tLi aB ax.AMax.ER_(8  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(8  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7, = stioa8>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 7, __VA_ARGS__) = stioa7,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 8, __VA_ARGS__) = stioa8>&aectpness {_\tLi aB ax.AMax.ER_(8  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(8  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7, = stioa8>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(8  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD9_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3,_\tLi aaaG ax.AARG_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaG ax.AARG_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaG ax.AARG_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaG ax.AARG_(tn, 7, __VA_ARGS__) = stioa7,_\tLi aaaG ax.AARG_(tn, 8, __VA_ARGS__) = stioa8,_\tLi aaaG ax.AARG_(tn, 9, __VA_ARGS__) = stioa9>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 9)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _9_F imatUne);_\tLi aB ax.AMax.ER_(9  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(9  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7, = stioa8n_\tLi aaaaa= stioa9>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 7, __VA_ARGS__) = stioa7,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 8, __VA_ARGS__) = stioa8,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 9, __VA_ARGS__) = stioa9>&aectpness {_\tLi aB ax.AMax.ER_(9  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(9  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7, = stioa8n_\tLi aaaaa= stioa9>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(9  aectpness, \tLi aaaMA 

 T
fmi nNTERNAL IMPLEMENTA { } - DON'T USEdnN USER CODE!!!
#n
 AnasG ax.AMETHOD10_(tn, aectpness, orn M))ai , ...T_\tLiG ax.ARESULT_(tn, __VA_ARGS__) or M))ai (_\tLi aaaG ax.AARG_(tn, 1, __VA_ARGS__) = stioa1,_\tLi aaaG ax.AARG_(tn, 2, __VA_ARGS__) = stioa2,_\tLi aaaG ax.AARG_(tn, 3, __VA_ARGS__) = stioa3,_\tLi aaaG ax.AARG_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaG ax.AARG_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaG ax.AARG_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaG ax.AARG_(tn, 7, __VA_ARGS__) = stioa7,_\tLi aaaG ax.AARG_(tn, 8, __VA_ARGS__) = stioa8,_\tLi aaaG ax.AARG_(tn, 9, __VA_ARGS__) = stioa9,_\tLi aaaG ax.AARG_(tn, 10, __VA_ARGS__) = stioa10>&aectpness {_\tLi aBasw) COMP= 0sASSERT_(cLUSIVE_tr1::t::Au_llow<                          \tLi aaaaatls f/ Aneplate <.  Tomavef GMpen__VA_ARGS__F>:tion s<F>::Aun" : }


\tLi aaaaaaaaa== 10)n_\tLi aaaaaei_;_LA 

 _o r _voi_e c _10_F imatUne);_\tLi aB ax.AMax.ER_(10  aectpness, MA 

 T.
s)OwnerAn AntuL &&
gc#MA 

 );_\tLi a   e ieB ax.AMax.ER_(10  aectpness, MA 

 T.EST_DI&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7, = stioa8n_= stioa9,_\tLi aaa  = stioa10>;_\tLi}_\tLi f/ AneplatDei_;
}

__VA_ARGS__F&_\tLi aaa= stio##M))ai (G ax.AMATCHER_(tn, 1, __VA_ARGS__) = stioa1n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 2, __VA_ARGS__) = stioa2n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 3, __VA_ARGS__) = stioa3n_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 4, __VA_ARGS__) = stioa4,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 5, __VA_ARGS__) = stioa5,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 6, __VA_ARGS__) = stioa6,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 7, __VA_ARGS__) = stioa7,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 8, __VA_ARGS__) = stioa8,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 9, __VA_ARGS__) = stioa9,_\tLi aaaaaaaaaaaaaaaaaaG ax.AMATCHER_(tn, 10  \tLi aaaaaaaaaaaaaaaaaaaaaa__VA_ARGS__) = stioa10>&aectpness {_\tLi aB ax.AMax.ER_(10  aectpness, MA 

 T.fi, a leOwner

 Antu_\tLi a   e ieB ax.AMax.ER_(10  aectpness, MA 

 T.ueme&= stioa1, = stioa2n_\tLi aaaaa= stioa3, = stioa4, = stioa5, = stioa6, = stioa7, = stioa8n_= stioa9,_\tLi aaa  = stioa10>;_\tLi}_\tLic
ll ttc f/ Aneplatk.
BaswO{  bli<__VA_ARGS__FeB ax.AMax.ER_(10  aectpness, \tLi aaaMA 

 T
f#n
 Anas ax.AMETHOD0(m, ...T_G ax.AMETHOD0_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD1(m, ...T_G ax.AMETHOD1_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD2(m, ...T_G ax.AMETHOD2_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD3(m, ...T_G ax.AMETHOD3_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD4(m, ...T_G ax.AMETHOD4_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD5(m, ...T_G ax.AMETHOD5_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD6(m, ...T_G ax.AMETHOD6_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD7(m, ...T_G ax.AMETHOD7_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD8(m, ...T_G ax.AMETHOD8_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD9(m, ...T_G ax.AMETHOD9_(, , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD10(m, ...T_G ax.AMETHOD10_(, , , m, __VA_ARGS__)ff#n
 Anas ax.ACONw) METHOD0(m, ...T_G ax.AMETHOD0_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD1(m, ...T_G ax.AMETHOD1_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD2(m, ...T_G ax.AMETHOD2_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD3(m, ...T_G ax.AMETHOD3_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD4(m, ...T_G ax.AMETHOD4_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD5(m, ...T_G ax.AMETHOD5_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD6(m, ...T_G ax.AMETHOD6_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD7(m, ...T_G ax.AMETHOD7_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD8(m, ...T_G ax.AMETHOD8_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD9(m, ...T_G ax.AMETHOD9_(, aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD10(m, ...T_G ax.AMETHOD10_(, aectp, , m, __VA_ARGS__)ff#n
 Anas ax.AMETHOD0_T(m, ...T_G ax.AMETHOD0_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD1_T(m, ...T_G ax.AMETHOD1_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD2_T(m, ...T_G ax.AMETHOD2_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD3_T(m, ...T_G ax.AMETHOD3_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD4_T(m, ...T_G ax.AMETHOD4_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD5_T(m, ...T_G ax.AMETHOD5_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD6_T(m, ...T_G ax.AMETHOD6_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD7_T(m, ...T_G ax.AMETHOD7_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD8_T(m, ...T_G ax.AMETHOD8_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD9_T(m, ...T_G ax.AMETHOD9_(Aument, , , , m, __VA_ARGS__)f#n
 Anas ax.AMETHOD10_T(m, ...T_G ax.AMETHOD10_(Aument, , , , m, __VA_ARGS__)ff#n
 Anas ax.ACONw) METHOD0_T(m, ...T_\tLi aB ax.AMETHOD0_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD1_T(m, ...T_\tLi aB ax.AMETHOD1_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD2_T(m, ...T_\tLi aB ax.AMETHOD2_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD3_T(m, ...T_\tLi aB ax.AMETHOD3_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD4_T(m, ...T_\tLi aB ax.AMETHOD4_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD5_T(m, ...T_\tLi aB ax.AMETHOD5_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD6_T(m, ...T_\tLi aB ax.AMETHOD6_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD7_T(m, ...T_\tLi aB ax.AMETHOD7_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD8_T(m, ...T_\tLi aB ax.AMETHOD8_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD9_T(m, ...T_\tLi aB ax.AMETHOD9_(Aument, , aectp, , m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD10_T(m, ...T_\tLi aB ax.AMETHOD10_(Aument, , aectp, , m, __VA_ARGS__)ff#n
 Anas ax.AMETHOD0_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD0_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD1_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD1_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD2_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD2_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD3_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD3_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD4_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD4_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD5_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD5_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD6_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD6_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD7_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD7_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD8_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD8_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD9_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD9_(, , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD10_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD10_(, , orn m, __VA_ARGS__)ff#n
 Anas ax.ACONw) METHOD0_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD0_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD1_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD1_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD2_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD2_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD3_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD3_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD4_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD4_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD5_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD5_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD6_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD6_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD7_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD7_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD8_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD8_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD9_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD9_(, aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD10_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD10_(, aectp, orn m, __VA_ARGS__)ff#n
 Anas ax.AMETHOD0_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD0_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD1_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD1_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD2_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD2_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD3_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD3_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD4_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD4_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD5_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD5_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD6_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD6_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD7_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD7_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD8_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD8_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD9_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD9_(Aument, , , orn m, __VA_ARGS__)f#n
 Anas ax.AMETHOD10_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD10_(Aument, , , orn m, __VA_ARGS__)ff#n
 Anas ax.ACONw) METHOD0_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD0_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD1_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD1_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD2_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD2_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD3_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD3_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD4_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD4_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD5_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD5_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD6_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD6_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD7_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD7_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD8_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD8_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD9_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD9_(Aument, , aectp, orn m, __VA_ARGS__)f#n
 Anas ax.ACONw) METHOD10_T_WITH_CALLTYPE(orn m, ...T_\tLi aB ax.AMETHOD10_(Aument, , aectp, orn m, __VA_ARGS__)ff// Asnei_vef GMpenam d t tohas onas stiLLA 

  whoseooEXCEid F.  ItEidn// usefuldsi{
ayouo     w* tiyour / An aededineemit somas essages&gaan// have Googlesnei_ verif<F>& trights essages&gre stchengconperhaps&gtn// >& trightsti es).  For exampl , ifayouogre exercio
 Thaede:n//n//   Foo(1);n//   Foo(2);n//   Foo(3);n//n// gconw* tisynverif<F>&at Foo(1) gconFoo(3) both iST_DIn//  sti.Bar("a"), but Foo(2) o r ct liST_DI gcyth
 T,ayouocan write:n//n// asw)(FooTetp, EST_DIsBarCorrectly>&i //   Mynei_  sti;n//   nei_vef GMpenvoid(str
 Thaheck_point_nt, )>haheck;n//   i //     InSequenSV s;n//n//     EXPECT_CALL( sti, Bar("a"));n//     EXPECT_CALL(aheck, Call("1"));n//     EXPECT_CALL(aheck, Call("2"));n//     EXPECT_CALL( sti, Bar("a"));n//   }n//   Foo(1);n//   aheck.Call("1");n//   Foo(2);n//   aheck.Call("2");n//   Foo(3);n// }n//t twven expectaoinstmpla saysF>&at >& tfirAn Bar("a") m    hapment twbefore aheck point "1"e mentseaecd Bar("a") m    hapmen aftli dheckt twpoint "2"e gconnoth
 T
f c am hapmen betweessingM wo dheckt twpoints.wven explicit aheck points letetitaeasydine ella
/it twecBar("a") id called.s<F
/it  calldineFoo().
  vimavef GMpename Fion sMocnei_vef GMpec:
  vimavef GMpename Rion sMocnei_vef GMpe<R()ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD0_T(Call, R())me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0ion sMocnei_vef GMpe<R(A0)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD1_T(Call, R(A0))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1ion sMocnei_vef GMpe<R(A0,eA1)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD2_T(Call, R(A0,eA1))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2ion sMocnei_vef GMpe<R(A0,eA1,eA2)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD3_T(Call, R(A0,eA1,eA2))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2, Aument, eA3ion sMocnei_vef GMpe<R(A0,eA1,eA2,eA3)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD4_T(Call, R(A0,eA1,eA2,eA3))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2, Aument, eA3amcdssAument, eA4ion sMocnei_vef GMpe<R(A0,eA1,eA2,eA3,eA4)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD5_T(Call, R(A0,eA1,eA2,eA3,eA4))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2, Aument, eA3amcdssAument, eA4, Aument, eA5ion sMocnei_vef GMpe<R(A0,eA1,eA2,eA3,eA4,eA5)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD6_T(Call, R(A0,eA1,eA2,eA3,eA4,eA5))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2, Aument, eA3amcdssAument, eA4, Aument, eA5, Aument, eA6ion sMocnei_vef GMpe<R(A0,eA1,eA2,eA3,eA4,eA5,eA6)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD7_T(Call, R(A0,eA1,eA2,eA3,eA4,eA5,eA6))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2, Aument, eA3amcdssAument, eA4, Aument, eA5, Aument, eA6, Aument, eA7ion sMocnei_vef GMpe<R(A0,eA1,eA2,eA3,eA4,eA5,eA6,eA7)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD8_T(Call, R(A0,eA1,eA2,eA3,eA4,eA5,eA6,eA7))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2, Aument, eA3amcdssAument, eA4, Aument, eA5, Aument, eA6, Aument, eA7, Aument, eA8ion sMocnei_vef GMpe<R(A0,eA1,eA2,eA3,eA4,eA5,eA6,eA7,eA8)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD9_T(Call, R(A0,eA1,eA2,eA3,eA4,eA5,eA6,eA7,eA8))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
  vimavef GMpename R, Aument, eA0, Aument, eA1, Aument, eA2, Aument, eA3amcdssAument, eA4, Aument, eA5, Aument, eA6, Aument, eA7, Aument, eA8amcdssAument, eA9ion sMocnei_vef GMpe<R(A0,eA1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9)ictLi sultLi
/vnei_vef GMpe(>&i. bte ax.AMETHOD10_T(Call, R(A0,eA1,eA2,eA3,eA4,eA5,eA6,eA7,eA8,eA9))me
_private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(nei_vef GMpe)me}c:
}virtuag M, MSV / Anepl

#endifa MocG ax.AINCLUDE_G ax.AG ax.AGENERATED_FUNC { }AMax.ERS_H_t twve_;

ie nw*s GENERATED.s<Fnadmtnd:n//     pump.py = sti-generated-nice-str
ct.h.pumpn// DO NOT EDIT BY HAND!!!
n// Copyrights2008,eGooglesInc fmi Alldright/AnLserve  fmifmi Redistr
buoinstgconsw* istmou SV gconbinarys Adms, with c:
eiff Gtn//  sdificaoins,ogre permitted_providedF>&at >& tfhEXPECT_ aecdioinss&gren//  et:n//n//     * Redistr
buoinss s emou SV aededm    re
eog >& tabovV aepyrightn// notice,nei_;
list s eaecdioinss&gconTo tfhEXPECT_ disn simer.n//     * Redistr
buoinss og binarys Admdm    reproduSV /& tabovVtwecnapyrightsnotice,nei_;
list s eaecdioinss&gconTo tfhEXPECT_ disn simerkhfcumneie docmatUnaoinstgco/c:
 t limmaterials_providedFwith t lkhfcdistr
buoins.n//     * Neit limeie nt, es eGooglesInc snoimeie nt, s s eitstwecnantr
buoors leyntacsw*ddineendorse c:
promoto_produSt/Aderive  fromn// >&_;
softwgre eiff Gttmplaific_pric:
eritten permissins.n//t twvHIS SOFTWARE IS PROVIDED.BY THE COPYRIGHT HOLDERS AND CONTRIBUTORSt tw"AS IS" AND ANY EXPRESS OR IMPLIED.WARRANTIES, INCLUDING, BUT NOTt twLIMITED.TO, THE IMPLIED.WARRANTIES OF MERCHANTABILITY AND FITNESS FORf// AsPARTICULAR PURPOSE ARE DISCLAIMED.dnN NO EVENT SHALL THE COPYRIGHTf// OWNER OR CONTRIBUTORS BEwLIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,f// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOTt twLIMITED.TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,f// DATA, OR PROFITS; OR BUSINESS nNTERRUP { }) HOWEVER CAUSED AND ON ANYt twvHEORY OF LIABILITY, WHETHER nN CONTRACT, STRICT LIABILITY, OR TORTt tw(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY.WAY OUT OF THE USEf// OFwvHIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.n//t twAuff r:nw* @google.nad (ZhanyoT_ WanT
fmi nmpl ow#.s d t toodine ats NiceMsti, NaggyMsti, gconStr
ctMsti.n//t twGaaNULas stiLn sMocnei_vooF>&at id created so
 ThGooglesnei_,f// NiceMsti<nei_voo> id a subn sMocs enei_vooF>&at aEXPEdn// une <. no::tescalls (i.e.scalls ine stiLLA 

 sF>&at have non// EXPECT_CALLtmplas), NaggyMsti<nei_voo> id a subn sMocs enei_voon// >&at pri#.s anw*rn:tessi{
aan une <. no::tescall occurs,&gaan// Str
ctMsti<nei_voo> id a subn sMocs enei_vooF>&at treats aEXn// une <. no::tescalls *s errors.n//t twCurrw#.lyLas stiLid naggy.s<Fdefault,
soenei_vooFgaan// NaggyMsti<nei_voo> behave likV /& tot, .  However,as (will soont twseifchneie default behavic:
s e stis inetacnice,nasF>&at umngeneraXn// leads ine srn  
it
eogl ttc/ Ans.  WhenF>&at hapmens, Mei_vooFwillt twstop behaviteslikV NaggyMsti<nei_voo> gconstart behaviteslikVf// NiceMsti<nei_voo>.n//t twNiceMsti, NaggyMsti, gconStr
ctMsti "in liit"neie aectpruStors ofn// >& irAnLspectaaN b(a
/n sMo, with up-ine10
ent, tchs.  T lieforen// youocan write NiceMsti<nei_voo>(5  "a") ineaectpruStLasnicee stin// w lie Mei_vooFhas a aectpruStorF>&at accepts (int, aectp char*),f// for exampl .n//t twA knownslimitaoinstisF>&at NiceMsti<nei_voo>, NaggyMsti<nei_voo>,n// gconStr
ctMsti<nei_voo> onlyLworis  Add  ckLLA 

 sFn
 Anad so
 Tn// >& t ax.AMETHOD* familyLs e acros DIRECTLYcumneie Mei_vooFn sMo fmi nfLas stiLLA 

  isFn
 Anad iULasb(a
/n sMocs enei_vooe ment"nice"fmi Add"str
ct"  sdifilimmaysnot affecteit,Fn
penditesonneie aempie r.n// In particular,anno::tesNiceMsti, NaggyMsti, gconStr
ctMsti isFNOTt twsupporte  fmifmi An t limknownslimitaoinstisF>&at eie aectpruStors of eie b(a
/ stin// cannot have ent, tchs passed.s<Fnon-aectp ieflience,n
/it  gren// banned.s<Feie GooglesC++nstylesguide gcyway.

#ifnn
 cG ax.AINCLUDE_G ax.AG ax.AGENERATED_NICE_STRICT_H_t#n
 AnasG ax.AINCLUDE_G ax.AG ax.AGENERATED_NICE_STRICT_H_t

ag M, MSV / AneplctL
  vimavef n sMocnei_C sMoion sMocNiceMsti :i sultLcnei_C sMoctLi sultLi
/v// We doct lfaStorF Gtteie aectpruStor bodydineaFnadmnstm))ai , as
/v// s (have ineavoideaFpossi ttcn sMh with memberocs enei_C sMo f cNiceMsti(>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v// C++no r ct l(yet) aEXPE in liitanSV s eaectpruStors,
soes (have
/v// inen
 Anasit for eat  grity f c  vimavef GMpename A1io  explicit NiceMsti(aectp A1& a1>&:enei_C sMo(a1>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n c  vimavef GMpename A1, Aument, eA2io  NiceMsti(aectp A1& a1, aectp A2& a2>&:enei_C sMo(a1, a2>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3>&:enei_C sMo(a1, a2, a3>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,tLi aaaaectp A4& a4>&:enei_C sMo(a1, a2, a3, a4>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5>&:enei_C sMo(a1, a2, a3, a4, a5>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6>&:enei_C sMo(a1, a2, a3, a4, a5, a6>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7>&:enei_C sMo(a1, a2, a3, a4, a5,tLi aaaa6,aa7>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8>&:enei_C sMo(a1,tLi aaaa2, a3, a4, a5, a6, a7,aa8>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8, Aument, eA9io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8,tLi aaaaectp A9& a9>&:enei_C sMo(a1, a2, a3, a4, a5, a6, a7,aa8, a9>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8, Aument, eA9, Aument, eA10io  NiceMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8,aaectp A9& a9,tLi aaaaectp A10& a10>&:enei_C sMo(a1, a2, a3, a4, a5, a6, a7,aa8, a9, a10>&imcdss f/ AneplatDei_::AEXPEUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/vvirtual ~NiceMsti(>&imcdss f/ AneplatDei_::Unri, a leCallReatGMpe(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(NiceMsti)me}c:
  vimavef n sMocnei_C sMoion sMocNaggyMsti :i sultLcnei_C sMoctLi sultLi
/v// We doct lfaStorF Gtteie aectpruStor bodydineaFnadmnstm))ai , as
/v// s (have ineavoideaFpossi ttcn sMh with memberocs enei_C sMo f cNaggyMsti(>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v// C++no r ct l(yet) aEXPE in liitanSV s eaectpruStors,
soes (have
/v// inen
 Anasit for eat  grity f c  vimavef GMpename A1io  explicit NaggyMsti(aectp A1& a1>&:enei_C sMo(a1>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n c  vimavef GMpename A1, Aument, eA2io  NaggyMsti(aectp A1& a1, aectp A2& a2>&:enei_C sMo(a1, a2>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3>&:enei_C sMo(a1, a2, a3>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,tLi aaaaectp A4& a4>&:enei_C sMo(a1, a2, a3, a4>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5>&:enei_C sMo(a1, a2, a3, a4, a5>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6>&:enei_C sMo(a1, a2, a3, a4, a5, a6>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7>&:enei_C sMo(a1, a2, a3, a4, a5,tLi aaaa6,aa7>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8>&:enei_C sMo(a1,tLi aaaa2, a3, a4, a5, a6, a7,aa8>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8, Aument, eA9io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8,tLi aaaaectp A9& a9>&:enei_C sMo(a1, a2, a3, a4, a5, a6, a7,aa8, a9>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8, Aument, eA9, Aument, eA10io  NaggyMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8,aaectp A9& a9,tLi aaaaectp A10& a10>&:enei_C sMo(a1, a2, a3, a4, a5, a6, a7,aa8, a9, a10>&imcdss f/ AneplatDei_::WarnUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/vvirtual ~NaggyMsti(>&imcdss f/ AneplatDei_::Unri, a leCallReatGMpe(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(NaggyMsti)me}c:
  vimavef n sMocnei_C sMoion sMocStr
ctMsti :i sultLcnei_C sMoctLi sultLi
/v// We doct lfaStorF Gtteie aectpruStor bodydineaFnadmnstm))ai , as
/v// s (have ineavoideaFpossi ttcn sMh with memberocs enei_C sMo f cStr
ctMsti(>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v// C++no r ct l(yet) aEXPE in liitanSV s eaectpruStors,
soes (have
/v// inen
 Anasit for eat  grity f c  vimavef GMpename A1io  explicit Str
ctMsti(aectp A1& a1>&:enei_C sMo(a1>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n c  vimavef GMpename A1, Aument, eA2io  Str
ctMsti(aectp A1& a1, aectp A2& a2>&:enei_C sMo(a1, a2>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3>&:enei_C sMo(a1, a2, a3>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,tLi aaaaectp A4& a4>&:enei_C sMo(a1, a2, a3, a4>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5>&:enei_C sMo(a1, a2, a3, a4, a5>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6>&:enei_C sMo(a1, a2, a3, a4, a5, a6>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7>&:enei_C sMo(a1, a2, a3, a4, a5,tLi aaaa6,aa7>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8>&:enei_C sMo(a1,tLi aaaa2, a3, a4, a5, a6, a7,aa8>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8, Aument, eA9io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8,tLi aaaaectp A9& a9>&:enei_C sMo(a1, a2, a3, a4, a5, a6, a7,aa8, a9>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/v  vimavef GMpename A1, Aument, eA2, Aument, eA3, Aument, eA4, Aument, eA5,tLi aaaAument, eA6, Aument, eA7, Aument, eA8, Aument, eA9, Aument, eA10io  Str
ctMsti(aectp A1& a1, aectp A2& a2, aectp A3& a3,aaectp A4& a4,tLi aaaaectp A5& a5,aaectp A6& a6,aaectp A7& a7,aaectp A8& a8,aaectp A9& a9,tLi aaaaectp A10& a10>&:enei_C sMo(a1, a2, a3, a4, a5, a6, a7,aa8, a9, a10>&imcdss f/ AneplatDei_::FailUne <. no::teCalls(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/vvirtual ~Str
ctMsti(>&imcdss f/ AneplatDei_::Unri, a leCallReatGMpe(tLi aaa  e <.  TomanmplicitCast_<nei_C sMo*>

 Ant)me  }n
/private:n aBasw) DISALLOWACOPY_ANDsASSIGN_(Str
ctMsti)me}c:
 twven fhEXPECT_ mplaializaoinss&cafchnsomas(remavivelye srn nadmns)n// user errors s enno::tesniceegconstr
cte stis.  T lyno  NOT cafchn// gllFpossi ttcerrors.n
 twvense mplaializaoinss&gre den sred.sutsnotFn
 Anad, assNiceMsti,n// NaggyMsti, gconStr
ctMsti cannot tacnno:e  f
  vimavef GMpename nei_C sMoion sMocNiceMsti<NiceMsti<nei_C sMoi >;
  vimavef GMpename nei_C sMoion sMocNiceMsti<NaggyMsti<nei_C sMoi >;
  vimavef GMpename nei_C sMoion sMocNiceMsti<Str
ctMsti<nei_C sMoi >;

  vimavef GMpename nei_C sMoion sMocNaggyMsti<NiceMsti<nei_C sMoi >;
  vimavef GMpename nei_C sMoion sMocNaggyMsti<NaggyMsti<nei_C sMoi >;
  vimavef GMpename nei_C sMoion sMocNaggyMsti<Str
ctMsti<nei_C sMoi >;

  vimavef GMpename nei_C sMoion sMocStr
ctMsti<NiceMsti<nei_C sMoi >;
  vimavef GMpename nei_C sMoion sMocStr
ctMsti<NaggyMsti<nei_C sMoi >;
  vimavef GMpename nei_C sMoion sMocStr
ctMsti<Str
ctMsti<nei_C sMoi >;

}virtuag M, MSV / Anepl

#endifa MocG ax.AINCLUDE_G ax.AG ax.AGENERATED_NICE_STRICT_H_t twve_;

ie nw*s GENERATED.s<Fnadmtnd:n//     pump.py = sti-generated-mafchers.h.pumpn// DO NOT EDIT BY HAND!!!
n// Copyrights2008,eGooglesInc fmi Alldright/AnLserve  fmifmi Redistr
buoinstgconsw* istmou SV gconbinarys Adms, with c:
eiff Gtn//  sdificaoins,ogre permitted_providedF>&at >& tfhEXPECT_ aecdioinss&gren//  et:n//n//     * Redistr
buoinss s emou SV aededm    re
eog >& tabovV aepyrightn// notice,nei_;
list s eaecdioinss&gconTo tfhEXPECT_ disn simer.n//     * Redistr
buoinss og binarys Admdm    reproduSV /& tabovVtwecnapyrightsnotice,nei_;
list s eaecdioinss&gconTo tfhEXPECT_ disn simerkhfcumneie docmatUnaoinstgco/c:
 t limmaterials_providedFwith t lkhfcdistr
buoins.n//     * Neit limeie nt, es eGooglesInc snoimeie nt, s s eitstwecnantr
buoors leyntacsw*ddineendorse c:
promoto_produSt/Aderive  fromn// >&_;
softwgre eiff Gttmplaific_pric:
eritten permissins.n//t twvHIS SOFTWARE IS PROVIDED.BY THE COPYRIGHT HOLDERS AND CONTRIBUTORSt tw"AS IS" AND ANY EXPRESS OR IMPLIED.WARRANTIES, INCLUDING, BUT NOTt twLIMITED.TO, THE IMPLIED.WARRANTIES OF MERCHANTABILITY AND FITNESS FORf// AsPARTICULAR PURPOSE ARE DISCLAIMED.dnN NO EVENT SHALL THE COPYRIGHTf// OWNER OR CONTRIBUTORS BEwLIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,f// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOTt twLIMITED.TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,f// DATA, OR PROFITS; OR BUSINESS nNTERRUP { }) HOWEVER CAUSED AND ON ANYt twvHEORY OF LIABILITY, WHETHER nN CONTRACT, STRICT LIABILITY, OR TORTt tw(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY.WAY OUT OF THE USEf// OFwvHIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.nt twGooglesnei_ - a frt, wori for eritCT_ C++nmotiLn sMoes.n//t twve_;

ie nimpl ow#.s somasnadmnslyesw*ddvariadic_mafchers.

#ifnn
 cG ax.AINCLUDE_G ax.AG ax.AGENERATED_MATCHERS_H_t#n
 AnasG ax.AINCLUDE_G ax.AG ax.AGENERATED_MATCHERS_H_t
#included<iterator>
#included<sstream>
#included<str
 T>
#included<vector>

ag M, MSV / AneplctLag M, MSV e <.  ToctL
 twven GMpe of eie i-th (0-b(a
d)

ield of >::Au.t#n
 AnasG ax.AFIELD_TYPE_(>::Au, iT_\tLi aGMpename LUSIVE_tr1::t::Au_el ow#.<i, >::Aun" GMpeL
 twv::AuFields<>::Au, k0, ..., kn> id for sel cneplc
ields from an// >::Au of eMpe >::Au.  ItEhas  wo membero:n//n//   eMpe: a >::Au eMpe whoseoi-th 
ield isF>&e ki-th 
ield of >::Au.t//   GetSel cnedFields(t):a   e isc
ields k0, ..., gconkn of e as a tupl .n//t twFor exampl , in/n sMocv::AuFields<tupl <bool, char, int>, 2, 0>,es (have:n//n//   eMpe isF>upl <int, bool>,Fgaan//   GetSel cnedFields(lete_>upl (tru , 'a', 42)) id (42, Aru ).:
  vimavef n sMoc>::Au, int k0 = -1, int k1 = -1, int k2 = -1, int k3 = -1,
aa  e < k4 = -1, int k5 = -1, int k6 = -1, int k7 = -1, int k8 = -1,
aa  e < k9 = -1ion sMocv::AuFieldsc:
 twveid generic_veroinstisFsw*ddwhenF>&lie gre 10 sel cnors.n  vimavef n sMoc>::Au, int k0, int k1, int k2, int k3, int k4, int k5, int k6,
aa  e < k7, int k8, int k9ion sMocv::AuFieldsctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2),tLi aaaG ax.AFIELD_TYPE_(>::Au, k3),aG ax.AFIELD_TYPE_(>::Au, k4),tLi aaaG ax.AFIELD_TYPE_(>::Au, k5),aG ax.AFIELD_TYPE_(>::Au, k6),tLi aaaG ax.AFIELD_TYPE_(>::Au, k7),aG ax.AFIELD_TYPE_(>::Au, k8),tLi aaaG ax.AFIELD_TYPE_(>::Au, k9)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t), get<k3>(t), get<k4>(t),tLi aaa  get<k5>(t), get<k6>(t), get<k7>(t), get<k8>(t), get<k9>(t))me  }n}c:
 twven fhEXPECT_ mplaializaoinstisFsw*ddfor 0 ~ 9 sel cnors.nn  vimavef n sMoc>::Auion sMocv::AuFields<>::Au, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& /* e */>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe()me  }n}c:
  vimavef n sMoc>::Au, int k0ion sMocv::AuFields<>::Au, k0, -1, -1, -1, -1, -1, -1, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1ion sMocv::AuFields<>::Au, k0, k1, -1, -1, -1, -1, -1, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1, int k2ion sMocv::AuFields<>::Au, k0, k1, k2, -1, -1, -1, -1, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1, int k2, int k3ion sMocv::AuFields<>::Au, k0, k1, k2, k3, -1, -1, -1, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2),tLi aaaG ax.AFIELD_TYPE_(>::Au, k3)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t), get<k3>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1, int k2, int k3, int k4ion sMocv::AuFields<>::Au, k0, k1, k2, k3, k4, -1, -1, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2),tLi aaaG ax.AFIELD_TYPE_(>::Au, k3),aG ax.AFIELD_TYPE_(>::Au, k4)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t), get<k3>(t), get<k4>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1, int k2, int k3, int k4, int k5ion sMocv::AuFields<>::Au, k0, k1, k2, k3, k4, k5, -1, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2),tLi aaaG ax.AFIELD_TYPE_(>::Au, k3),aG ax.AFIELD_TYPE_(>::Au, k4),tLi aaaG ax.AFIELD_TYPE_(>::Au, k5)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t), get<k3>(t), get<k4>(t),tLi aaa  get<k5>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1, int k2, int k3, int k4, int k5, int k6ion sMocv::AuFields<>::Au, k0, k1, k2, k3, k4, k5, k6, -1, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2),tLi aaaG ax.AFIELD_TYPE_(>::Au, k3),aG ax.AFIELD_TYPE_(>::Au, k4),tLi aaaG ax.AFIELD_TYPE_(>::Au, k5),aG ax.AFIELD_TYPE_(>::Au, k6)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t), get<k3>(t), get<k4>(t),tLi aaa  get<k5>(t), get<k6>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1, int k2, int k3, int k4, int k5, int k6,
aa  e < k7ion sMocv::AuFields<>::Au, k0, k1, k2, k3, k4, k5, k6, k7, -1, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2),tLi aaaG ax.AFIELD_TYPE_(>::Au, k3),aG ax.AFIELD_TYPE_(>::Au, k4),tLi aaaG ax.AFIELD_TYPE_(>::Au, k5),aG ax.AFIELD_TYPE_(>::Au, k6),tLi aaaG ax.AFIELD_TYPE_(>::Au, k7)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t), get<k3>(t), get<k4>(t),tLi aaa  get<k5>(t), get<k6>(t), get<k7>(t))me  }n}c:
  vimavef n sMoc>::Au, int k0, int k1, int k2, int k3, int k4, int k5, int k6,
aa  e < k7, int k8ion sMocv::AuFields<>::Au, k0, k1, k2, k3, k4, k5, k6, k7, k8, -1>ctLi sultLi
/veMpen
 cLUSIVE_tr1::t::Au<G ax.AFIELD_TYPE_(>::Au, k0),tLi aaaG ax.AFIELD_TYPE_(>::Au, k1),aG ax.AFIELD_TYPE_(>::Au, k2),tLi aaaG ax.AFIELD_TYPE_(>::Au, k3),aG ax.AFIELD_TYPE_(>::Au, k4),tLi aaaG ax.AFIELD_TYPE_(>::Au, k5),aG ax.AFIELD_TYPE_(>::Au, k6),tLi aaaG ax.AFIELD_TYPE_(>::Au, k7),aG ax.AFIELD_TYPE_(>::Au, k8)iceMpeme  snaoic eMpe GetSel cnedFields(aectp >::Au& t>&imcdssso
 ThLUSIVE_tr1::get;mcdss   e ieeMpe(get<k0>(t), get<k1>(t), get<k2>(t), get<k3>(t), get<k4>(t),tLi aaa  get<k5>(t), get<k6>(t), get<k7>(t), get<k8>(t))me  }n}c:
#unn
 cG ax.AFIELD_TYPE_
fmi nmpl ow#.s >&e Args()_mafcher.n  vimavef n sMocArgs>::Au, int k0 = -1, int k1 = -1, int k2 = -1, int k3 = -1,
aa  e < k4 = -1, int k5 = -1, int k6 = -1, int k7 = -1, int k8 = -1,
aa  e < k9 = -1ion sMocArgsMafchernmpl :i sultLcnafchern <. face<Args>::Au>ctLi sultLi
/v// Args>::Au leynhave inp-levelaaectp or ieflience  sdifilio f ceMpen
 cBasw) REMOVE REFERENCE_ANDsCONw) (Args>::Au) RawArgs>::Au;f ceMpen
 cGMpename e <.  Tomav::AuFields<RawArgs>::Au, k0, k1, k2, k3, k4, k5,tLi aaak6, k7, k8, k9n" GMpe Sel cnedArgs;f ceMpen
 cnafcher<aectp Sel cnedArgs&> MonomorphicInnernafcher;n
/v  vimavef GMpename Innernafcherio  explicit ArgsMafchernmpl(aectp Innernafcher& e ner_mafcher)tLi aaa: e ner_mafcher_(SafenafcherCast<aectp Sel cnedArgs&>(e ner_mafcher)>&i. btevirtual boolcnafchAndExplain(Args>::Au ents,tLi aaa                         nafchResultL a lner*
listlner)aaectp imcdssaectp Sel cnedArgs& sel cned_ents = GetSel cnedArgs(ents);mcdssif (!listlner->IsI <. no:ed())tLi aaa   e iee ner_mafcher_.nafches(sel cned_ents)me
____Pri#.Indices(listlner->stream());mcdss*listlner << "gre " << Pri#.ToStr
 T(sel cned_ents)me
____Str
 TnafchResultL a lneree ner_listlner;mcdssaectp boolcmafch = e ner_mafcher_.nafchAndExplain(sel cned_ents,tLi aaa                                                &e ner_listlner);mcdssPri#.IfNotEmpty(e ner_listlner.str(), listlner->stream());mcdss   e iemafchme  }n
/vvirtual voideDescribeTo(LUSIVE_ostream* os)aaectp imcdss*os << "gre a >::Au ";
____Pri#.Indices(os);mcdssi ner_mafcher_.DescribeTo(os);mcd}n
/vvirtual voideDescribeNegaoinsTo(LUSIVE_ostream* os)aaectp imcdss*os << "gre a >::Au ";
____Pri#.Indices(os);mcdssi ner_mafcher_.DescribeNegaoinsTo(os);mcd}n
/private:n asnaoic Sel cnedArgs GetSel cnedArgs(Args>::Au ents>&imcdss   e iev::AuFields<RawArgs>::Au, k0, k1, k2, k3, k4, k5,ak6, k7, k8,tLi aaa  k9n" GetSel cnedFields(ents);mcd}n
/v// Pri#.s eie indices of eie sel cnedc
ields.n asnaoic voidePri#.Indices(LUSIVE_ostream* os)aimcdss*os << "whoseo
ields (";mcdssaectp e < indices[10] = { k0, k1, k2, k3, k4, k5, k6, k7, k8, k9 };mcdssfor (e < i = 0; i < 10; i++)aimcdssssif (indices[i] < 0)tLi aaa  breakme
____ssif (i >= 1)tLi aaa  *os << ", ";

 aaa  *os << "#" << indices[i];mcdss}mcdss*os << ") ";
__}n
/vaectp MonomorphicInnernafchersi ner_mafcher_;

 aBasw) DISALLOWAASSIGN_(ArgsMafchernmpl)me}c:
  vimavef n sMocInnernafcher, int k0 = -1, int k1 = -1, int k2 = -1,
aa  e < k3 = -1, int k4 = -1, int k5 = -1, int k6 = -1, int k7 = -1,
aa  e < k8 = -1, int k9 = -1ion sMocArgsMafcherctLi sultLi
/vexplicit ArgsMafcher(aectp Innernafcher& e ner_mafcher)tLi aaa: e ner_mafcher_(e ner_mafcher)&i. bte  vimavef GMpename Args>::Au>bteoperatorcnafcher<Args>::Au>()aaectp imcdss   e ieMakenafcher(new ArgsMafchernmpl<Args>::Au, k0, k1, k2, k3, k4, k5,tLi aaaaak6, k7, k8, k9n(e ner_mafcher_t)me  }n
/private:n aaectp Innernafchersi ner_mafcher_;

 aBasw) DISALLOWAASSIGN_(ArgsMafcher)me}c:
 twA set s emetafef GMped for aempuneplc>& tresult GMpe of AllOf fmi AllOf(m1, ..., mN)a   e isfmi AllOfResultN<den eMpe(m1),a..., den eMpe(mN)n" GMpe.nt twAlff Ggh AllOf i ct ln
 Anad for onasent, tch, AllOfResult1 isFn
 Anad
// inesimplif<F>& timpl ow#.aoins.n  vimavef GMpename n1iotpruStLAllOfResult1 {f ceMpen
 cn1ceMpeme}c:
  vimavef GMpename M1, Aument, eM2iotpruStLAllOfResult2 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult1<n1i" GMpe,tLi aaaAument, eAllOfResult1<n2n" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3iotpruStLAllOfResult3 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult1<n1i" GMpe,tLi aaaAument, eAllOfResult2<M2, M3i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4iotpruStLAllOfResult4 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult2<M1, n2n" GMpe,tLi aaaAument, eAllOfResult2<M3, M4i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5iotpruStLAllOfResult5 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult2<M1, n2n" GMpe,tLi aaaAument, eAllOfResult3<M3, M4,eM5i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6iotpruStLAllOfResult6 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult3<M1, n2, M3i" GMpe,tLi aaaAument, eAllOfResult3<M4,eM5,eM6i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7iotpruStLAllOfResult7 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult3<M1, n2, M3i" GMpe,tLi aaaAument, eAllOfResult4<M4,eM5,eM6,eM7i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7, Aument, eM8iotpruStLAllOfResult8 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult4<M1, n2, M3, M4i" GMpe,tLi aaaAument, eAllOfResult4<M5,eM6,eM7,eM8i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9iotpruStLAllOfResult9 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult4<M1, n2, M3, M4i" GMpe,tLi aaaAument, eAllOfResult5<M5,eM6,eM7,eM8,eM9i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9, Aument, eM10iotpruStLAllOfResult10 {f ceMpen
 cBothOfnafcher<tLi aaaGMpename AllOfResult5<M1, n2, M3, M4,eM5i" GMpe,tLi aaaAument, eAllOfResult5<M6,eM7,eM8,eM9,eM10i" GMpeL  >ceMpeme}c:
 twA set s emetafef GMped for aempuneplc>& tresult GMpe of AnyOf fmi AnyOf(m1, ..., mN)a   e isfmi AnyOfResultN<den eMpe(m1),a..., den eMpe(mN)n" GMpe.nt twAlff Ggh AnyOf i ct ln
 Anad for onasent, tch, AnyOfResult1 isFn
 Anad
// inesimplif<F>& timpl ow#.aoins.n  vimavef GMpename n1iotpruStLAnyOfResult1 {f ceMpen
 cn1ceMpeme}c:
  vimavef GMpename M1, Aument, eM2iotpruStLAnyOfResult2 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult1<n1i" GMpe,tLi aaaAument, eAnyOfResult1<n2n" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3iotpruStLAnyOfResult3 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult1<n1i" GMpe,tLi aaaAument, eAnyOfResult2<M2, M3i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4iotpruStLAnyOfResult4 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult2<M1, n2n" GMpe,tLi aaaAument, eAnyOfResult2<M3, M4i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5iotpruStLAnyOfResult5 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult2<M1, n2n" GMpe,tLi aaaAument, eAnyOfResult3<M3, M4,eM5i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6iotpruStLAnyOfResult6 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult3<M1, n2, M3i" GMpe,tLi aaaAument, eAnyOfResult3<M4,eM5,eM6i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7iotpruStLAnyOfResult7 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult3<M1, n2, M3i" GMpe,tLi aaaAument, eAnyOfResult4<M4,eM5,eM6,eM7i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7, Aument, eM8iotpruStLAnyOfResult8 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult4<M1, n2, M3, M4i" GMpe,tLi aaaAument, eAnyOfResult4<M5,eM6,eM7,eM8i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9iotpruStLAnyOfResult9 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult4<M1, n2, M3, M4i" GMpe,tLi aaaAument, eAnyOfResult5<M5,eM6,eM7,eM8,eM9i" GMpeL  >ceMpeme}c:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5amcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9, Aument, eM10iotpruStLAnyOfResult10 {f ceMpen
 cEit liOfnafcher<tLi aaaGMpename AnyOfResult5<M1, n2, M3, M4,eM5i" GMpe,tLi aaaAument, eAnyOfResult5<M6,eM7,eM8,eM9,eM10i" GMpeL  >ceMpeme}c:
}virtuag M, MSV e <.  Tont twArgs<N1, N2,a..., Nk>(a_mafcher)&mafches a tupl sif eie sel cnedf// fields s eit&mafches a_mafcher.  C++no r ct lsupport defaultn// gnt, tchs for fef GMpeoodine ats,
soes (have ineoverloadeit.n  vimavef GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<InnernafcherioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcheri(mafcher)me}:
  vimavef int k1, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1i(mafcher)me}:
  vimavef int k1, int k2, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2i(mafcher)me}:
  vimavef int k1, int k2, int k3, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3i(mafcher)me}:
  vimavef int k1, int k2, int k3, int k4, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4i(mafcher)me}:
  vimavef int k1, int k2, int k3, int k4, int k5, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5i(mafcher)me}:
  vimavef int k1, int k2, int k3, int k4, int k5, int k6, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6i(mafcher)me}:
  vimavef int k1, int k2, int k3, int k4, int k5, int k6, e < k7,mcdssAument, eInnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6, k7ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6,tLi aaak7i(mafcher)me}:
  vimavef int k1, int k2, int k3, int k4, int k5, int k6, e < k7, int k8,mcdssAument, eInnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6, k7, k8ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6, k7,mcdss  k8i(mafcher)me}:
  vimavef int k1, int k2, int k3, int k4, int k5, int k6, e < k7, int k8,mcdssint k9, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6, k7, k8, k9noArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6, k7, k8,tLi aaak9n(mafcher)me}:
  vimavef int k1, int k2, int k3, int k4, int k5, int k6, e < k7, int k8,mcdssint k9, int k10, GMpename InnernafcherioinlAnasi <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6, k7, k8, k9,mcdssk10ioArgs(aectp Innernafcher& mafcher)&i
aa   e iee <.  TomaArgsMafcher<Innernafcher, k1, k2, k3, k4, k5, k6, k7, k8,tLi aaak9,sk10i(mafcher)me}:
// El ow#.sAre(e_1, e_2,a... e_n)&mafches an STL-stylesnantainereeiffn// n el ow#.s, whlie eie i-th el ow#. umneie nantainerem   n//  afch eie i-th gnt, tch umneie list.  Eat  grt, tch of
// El ow#.sAre() canntaceit lima value c:
a_mafcher.  We support up in
// 10 gnt, tchs.n//t twveacsw* s eDecayArray umneie impl ow#.aoins aEXPEs El ow#.sAre()
// ineaccept str
 T literals, whoseoGMpe isaaectp char[N],.sutswlkhfcwach inetreat >& m as aectp char*.n//t twNOTE: Since El ow#.sAre() cares ab Gtteie ordlimof eie el ow#.s, i n//      not tacsw*ddwith nantainers whoseoel ow#.s's ordlimisfmi unn
 Anad (e.g.Ehash_map).:
inlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<ic>
El ow#.sAre() {f ceMpen
 cSIVE_tr1::t::Au<icArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args())me}:
  vimavef GMpename T1ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpeic>
El ow#.sAre(aectp >1& e1) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1))me}:
  vimavef GMpename T1, GMpename T2ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T5i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5, e6))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5, e6, e7))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7, GMpename T8ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T8i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7,aaectp T8& e8) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T8i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5, e6, e7,tLi aaae8))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7, GMpename T8, GMpename T9ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T9i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7,aaectp T8& e8,aaectp T9& e9) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T9i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5, e6, e7,tLi aaae8, e9))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7, GMpename T8, GMpename T9, GMpename T10ioinlAnasi <.  TomaEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T9i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T10i" GMpeic>
El ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7,aaectp T8& e8,aaectp T9& e9,tLi aaectp T10& e10>&imcdeMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T9i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T10i" GMpeicArgs;f c   e iee <.  TomaEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5, e6, e7,tLi aaae8, e9, e10>)me}:
// UnordliedEl ow#.sAre(e_1, e_2,a..., e_n)&is an El ow#.sAre extenoinsn// >&at&mafches n el ow#.see  any ordli.  We support up in n=10 gnt, tchs.noinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<ic>
UnordliedEl ow#.sAre() {f ceMpen
 cSIVE_tr1::t::Au<icArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args())me}:
  vimavef GMpename T1ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1))me}:
  vimavef GMpename T1, GMpename T2ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T5i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLi aaaaaGMpent, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5,tLi aaae6))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLi aaaaaGMpent, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5,tLi aaae6, e7))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7, GMpename T8ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLi aaaaaGMpent, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T8i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7,aaectp T8& e8) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T8i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5,tLi aaae6, e7,ae8))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7, GMpename T8, GMpename T9ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLi aaaaaGMpent, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T9i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7,aaectp T8& e8,aaectp T9& e9) {f ceMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T9i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5,tLi aaae6, e7,ae8, e9))me}:
  vimavef GMpename T1, GMpename T2, GMpename T3, GMpename T4, GMpename T5,mcdssAument, eT6, GMpename T7, GMpename T8, GMpename T9, GMpename T10ioinlAnasi <.  TomaUnordliedEl ow#.sArenafcher<tLi aSIVE_tr1::t::Au<tLi aaaaaGMpename i <.  TomaDecayArray<T1i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T2i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T3i" GMpe,tLi aaaaaGMpename i <.  TomaDecayArray<T4i" GMpe,tLi aaaaaGMpent, ei <.  TomaDecayArray<T5i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T9i" GMpe,tLiLi aaaAument, ei <.  TomaDecayArray<T10i" GMpeic>
UnordliedEl ow#.sAre(aectp >1& e1,aaectp T2& e2,aaectp T3& e3,aaectp T4& e4,tLi aaectp T5& e5,aaectp T6& e6,aaectp T7& e7,aaectp T8& e8,aaectp T9& e9,tLi aaectp T10& e10>&imcdeMpen
 cSIVE_tr1::t::Au<tLi aaaAument, ei <.  TomaDecayArray<T1i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T2i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T3i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T4i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T5i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T6i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T7i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T8i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T9i" GMpe,tLi aaaAument, ei <.  TomaDecayArray<T10i" GMpeicArgs;f c   e iee <.  TomaUnordliedEl ow#.sArenafcher<Args>(Args(e1, e2, e3, e4, e5,tLi aaae6, e7,ae8, e9, e10>)me}:
// AllOf(m1, m2,a..., mk)&mafches any value >&at&mafches allmof eie givesn// sub-mafchers.  AllOf i  callad fully qualifild in prevtch ADL from fir
 T.:
  vimavef GMpename M1, Aument, eM2ioinlAnasAument, ei <.  TomaAllOfResult2<M1, n2n" GMpe
AllOf(M1 m1, n2 m2)&i
aa   e ieAument, ei <.  TomaAllOfResult2<M1, n2n" GMpe(tLi aaam1,tLi aaam2)me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3ioinlAnasAument, ei <.  TomaAllOfResult3<M1, n2, M3i" GMpe
AllOf(M1 m1, n2 m2, M3 m3)&i
aa   e ieAument, ei <.  TomaAllOfResult3<M1, n2, M3i" GMpe(tLi aaam1,tLi aaa" GesneplmaAllOf(m2, m3))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4ioinlAnasAument, ei <.  TomaAllOfResult4<M1, n2, M3, M4i" GMpe
AllOf(M1 m1, n2 m2, M3 m3, M4 m4)&i
aa   e ieAument, ei <.  TomaAllOfResult4<M1, n2, M3, M4i" GMpe(tLi aaa" GesneplmaAllOf(m1, m2),tLi aaa" GesneplmaAllOf(m3, m4))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5ioinlAnasAument, ei <.  TomaAllOfResult5<M1, n2, M3, M4,eM5i" GMpe
AllOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5)&i
aa   e ieAument, ei <.  TomaAllOfResult5<M1, n2, M3, M4,eM5i" GMpe(tLi aaa" GesneplmaAllOf(m1, m2),tLi aaa" GesneplmaAllOf(m3, m4, m5))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6ioinlAnasAument, ei <.  TomaAllOfResult6<M1, n2, M3, M4,eM5,eM6i" GMpeLAllOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6)&i
aa   e ieAument, ei <.  TomaAllOfResult6<M1, n2, M3, M4,eM5,eM6i" GMpe(tLi aaa" GesneplmaAllOf(m1, m2, m3),tLi aaa" GesneplmaAllOf(m4, m5, m6))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7ioinlAnasAument, ei <.  TomaAllOfResult7<M1, n2, M3, M4,eM5,eM6,eM7i" GMpeLAllOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7)&i
aa   e ieAument, ei <.  TomaAllOfResult7<M1, n2, M3, M4,eM5,eM6,eM7i" GMpe(tLi aaa" GesneplmaAllOf(m1, m2, m3),tLi aaa" GesneplmaAllOf(m4, m5, m6, m7))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7, Aument, eM8ioinlAnasAument, ei <.  TomaAllOfResult8<M1, n2, M3, M4,eM5,eM6,eM7,eM8i" GMpeLAllOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7,eM8 m8)&i
aa   e ieAument, ei <.  TomaAllOfResult8<M1, n2, M3, M4,eM5,eM6,eM7,eM8i" GMpe(tLi aaa" GesneplmaAllOf(m1, m2, m3, m4),tLi aaa" GesneplmaAllOf(m5, m6, m7, m8))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9ioinlAnasAument, ei <.  TomaAllOfResult9<M1, n2, M3, M4,eM5,eM6,eM7,eM8,eM9i" GMpeLAllOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7,eM8 m8,eM9 m9)&i
aa   e ieAument, ei <.  TomaAllOfResult9<M1, n2, M3, M4,eM5,eM6,eM7,eM8,tLi aaaM9i" GMpe(tLi aaa" GesneplmaAllOf(m1, m2, m3, m4),tLi aaa" GesneplmaAllOf(m5, m6, m7, m8, m9))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9, Aument, eM10ioinlAnasAument, ei <.  TomaAllOfResult10<M1, n2, M3, M4,eM5,eM6,eM7,eM8,eM9,mcdssM10i" GMpeLAllOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7,eM8 m8,eM9 m9,sM10 m10)&i
aa   e ieAument, ei <.  TomaAllOfResult10<M1, n2, M3, M4,eM5,eM6,eM7,eM8,eM9,mcdssssM10i" GMpe(tLi aaa" GesneplmaAllOf(m1, m2, m3, m4, m5),tLi aaa" GesneplmaAllOf(m6, m7, m8, m9, m10))me}:
// AnyOf(m1, m2,a..., mk)&mafches any value >&at&mafches any of eie givesn// sub-mafchers.  AnyOf i  callad fully qualifild in prevtch ADL from fir
 T.:
  vimavef GMpename M1, Aument, eM2ioinlAnasAument, ei <.  TomaAnyOfResult2<M1, n2n" GMpe
AnyOf(M1 m1, n2 m2)&i
aa   e ieAument, ei <.  TomaAnyOfResult2<M1, n2n" GMpe(tLi aaam1,tLi aaam2)me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3ioinlAnasAument, ei <.  TomaAnyOfResult3<M1, n2, M3i" GMpe
AnyOf(M1 m1, n2 m2, M3 m3)&i
aa   e ieAument, ei <.  TomaAnyOfResult3<M1, n2, M3i" GMpe(tLi aaam1,tLi aaa" GesneplmaAnyOf(m2, m3))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4ioinlAnasAument, ei <.  TomaAnyOfResult4<M1, n2, M3, M4i" GMpe
AnyOf(M1 m1, n2 m2, M3 m3, M4 m4)&i
aa   e ieAument, ei <.  TomaAnyOfResult4<M1, n2, M3, M4i" GMpe(tLi aaa" GesneplmaAnyOf(m1, m2),tLi aaa" GesneplmaAnyOf(m3, m4))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5ioinlAnasAument, ei <.  TomaAnyOfResult5<M1, n2, M3, M4,eM5i" GMpe
AnyOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5)&i
aa   e ieAument, ei <.  TomaAnyOfResult5<M1, n2, M3, M4,eM5i" GMpe(tLi aaa" GesneplmaAnyOf(m1, m2),tLi aaa" GesneplmaAnyOf(m3, m4, m5))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6ioinlAnasAument, ei <.  TomaAnyOfResult6<M1, n2, M3, M4,eM5,eM6i" GMpeLAnyOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6)&i
aa   e ieAument, ei <.  TomaAnyOfResult6<M1, n2, M3, M4,eM5,eM6i" GMpe(tLi aaa" GesneplmaAnyOf(m1, m2, m3),tLi aaa" GesneplmaAnyOf(m4, m5, m6))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7ioinlAnasAument, ei <.  TomaAnyOfResult7<M1, n2, M3, M4,eM5,eM6,eM7i" GMpeLAnyOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7)&i
aa   e ieAument, ei <.  TomaAnyOfResult7<M1, n2, M3, M4,eM5,eM6,eM7i" GMpe(tLi aaa" GesneplmaAnyOf(m1, m2, m3),tLi aaa" GesneplmaAnyOf(m4, m5, m6, m7))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7, Aument, eM8ioinlAnasAument, ei <.  TomaAnyOfResult8<M1, n2, M3, M4,eM5,eM6,eM7,eM8i" GMpeLAnyOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7,eM8 m8)&i
aa   e ieAument, ei <.  TomaAnyOfResult8<M1, n2, M3, M4,eM5,eM6,eM7,eM8i" GMpe(tLi aaa" GesneplmaAnyOf(m1, m2, m3, m4),tLi aaa" GesneplmaAnyOf(m5, m6, m7, m8))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9ioinlAnasAument, ei <.  TomaAnyOfResult9<M1, n2, M3, M4,eM5,eM6,eM7,eM8,eM9i" GMpeLAnyOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7,eM8 m8,eM9 m9)&i
aa   e ieAument, ei <.  TomaAnyOfResult9<M1, n2, M3, M4,eM5,eM6,eM7,eM8,tLi aaaM9i" GMpe(tLi aaa" GesneplmaAnyOf(m1, m2, m3, m4),tLi aaa" GesneplmaAnyOf(m5, m6, m7, m8, m9))me}:
  vimavef GMpename M1, Aument, eM2, Aument, eM3, Aument, eM4, Aument, eM5,mcdssAument, eM6, Aument, eM7, Aument, eM8, Aument, eM9, Aument, eM10ioinlAnasAument, ei <.  TomaAnyOfResult10<M1, n2, M3, M4,eM5,eM6,eM7,eM8,eM9,mcdssM10i" GMpeLAnyOf(M1 m1, n2 m2, M3 m3, M4 m4,eM5 m5,eM6 m6,eM7 m7,eM8 m8,eM9 m9,sM10 m10)&i
aa   e ieAument, ei <.  TomaAnyOfResult10<M1, n2, M3, M4,eM5,eM6,eM7,eM8,eM9,mcdssssM10i" GMpe(tLi aaa" GesneplmaAnyOf(m1, m2, m3, m4, m5),tLi aaa" GesneplmaAnyOf(m6, m7, m8, m9, m10))me}:
}virtuag M, MSV Gesnepl

t twveacMATCHER* family of macros canntacsw*dde  auag M, MSV scope in
// n
 Ana custom mafchers easily.n//t twBasic Usaglkhfc===========n//t twveacsyntaxn//t tw cMATCHER(ag M, descripoins_str
 T)&i staveow#.s; }n//t twn
 Anas
a_mafcherdwith eie givesuag M >&at&execuGes eie staveow#.s,khfcwhich         e iea bool in indicavefif eie  afch succeeds.  Insiden// >&e staveow#.s, you cannreferdinet&e value be
 T mafched by 'arg',khfcandnreferdineitseAume by 'arg_Aume'.n//t twveacdescripoins str
 T doc, tchs what >& _mafcherdo r ,candni  sw*d
// inegeneravef>& _failur _messagl whln eie  afch fails.  Since a
// MATCHER()ni  swually n
 Anad e  auheadlimfile shared by multiplen// C++nsource files, w trequiie eie descripoins inetaca C-str
 Tn// literal ineavoid possible side effects.  It canntacempty, incwhichn// casl we'llcsw* eie sequence of wordsee  >& _mafcherdag M as eiet twn
scripoins.n//t twFor&exampl :n//t tw cMATCHER(IsEves, "")&i    e ie(arg % 2)&== 0; }n//t twaEXPEs you inewriten//t tw c// Expects mock_foo.Bar(n) inetaccallad whlie nni  evtc.t tw cEXPECT_CALL(mock_foo, Bar(IsEves()))me//t twor,n//t tw c// Verifils >&at&t&e value of some_expressins i  evtc.t tw cEXPECT_THAT(some_expressins, IsEves())me//t twIf eie abovM asseroins fails, i dwillcpr
 t someth
 T lik :n//t tw cValue of: some_expressinst tw cExpected: i  evtct tw c  Actual: 7n//t twwhlie eie descripoins "i  evtc"&is automatically calcumaved from eiet twmafcherdag M IsEves.n//t twArt, tch TMpeLhfc=============n//t twNote >&at&t&e Aume of eie value be
 T mafched (arg_Aume)misfmi determAnad by eie nantext incwhich you sw* eie mafcherdandni n// supplild in you by eie nampiler,
soeyou doct lneld in worry ab Gtfmi declar
 T i d(nor&cannyou).  ThiswaEXPEs eie mafcherdinetafmi polymorphic.  For&exampl , IsEves() canntacsw*ddine afch any tMpeLhfcwhlie eie value of "(arg % 2)&== 0" canntacimplicitly convero*ddint twa bool.  In eie "Bar(IsEves())"&exampl  abovM,fif method Bar()
// iakes an 
 t, 'arg_Aume'dwillcb ei <;fif i diakes an unsignad long,khfc'arg_Aume'dwillcb eunsignad long;dandnsoens.n//t twParg Mteriz
 T nafchersLhfc=======================n//t twSometimesnyou'llcwach ineparg Mteriz* eie mafcher.  For&>&at&youn// can sw* anot limmacro:n//t tw cMATCHER_P(ag M, parg _ag M, descripoins_str
 T)&i staveow#.s; }n//t twFor&exampl :n//t tw cMATCHER_P(HasAbsoluGeValue, value, "")&i    e ieabs(arg)&== value; }n//t twwillcaEXPE you inewrite:n//t tw cEXPECT_THAT(Blah("a"), HasAbsoluGeValue(n))me//t twwhich  ay leaddinet&iswmessagl (assum
 T s i  10):n//t tw cValue of: Blah("a")t tw cExpected: has absoluGe value 10t tw c  Actual: -9n//t twNote >&at&both eie mafcherdoescripoins andnits parg Mter arefmi pr
 ted, mak
 T eie messagl human-friendly.n//t twIn eie mafcherdoe Anioins body, you cannwrite 'foo_Aume'dint twreference t&e Aume of a parg Mter ag Md 'foo'.  For&exampl , e  >& t twbody of MATCHER_P(HasAbsoluGeValue, value) abovM,fyou cannwritekhfc'value_Aume'dinnreferdinet&e Aume of 'value'.n//t twW* alsn provide MATCHER_P2, MATCHER_P3,a..., up in MATCHER_P10 int twsupport multi-parg Mter mafchers.n//t twDescrib
 T Parg MterizMd nafchersLhfc=================================n//t twveacla   grt, tch in MATCHER*()ni  a str
 T-Aumed expressins.  Thekhfcexpressins cannreference allmof eie mafcher's parg Mters andna
// special bool-Aumed var
able ag Md 'negaoins'.  Whln 'negaoins'ni n// falsM,feie expressins should evaluavef>o eie mafcher's oescripoins;t twot liwiw* i dshould evaluavef>o eie oescripoins of eie negaoins of
// eie mafcher.  For&exampl ,n//t tw cus
 T eesneplmaPr
 tToStr
 T;
//t tw cMATCHER_P2(InClow*dRangM,fXPE, hi,t tw c    str
 T(negaoins ? "i  not" : "i ")&+ " e  rangM [" +t tw c    Pr
 tToStr
 T(XPE)&+ ", "&+ Pr
 tToStr
 T(hi)&+ "]")&it tw c     e ieXPE <= grt && grt <= hi;t tw c}t tw c...t tw cEXPECT_THAT(3,aInClow*dRangM(4, 6))me//w cEXPECT_THAT(3,aNot(InClow*dRangM(2, 4)))me//t twwould generavef>wo_failur s >&at&nantainet&e Aext:n//t tw cExpected: i  e  rangM [4, 6]t tw c...t tw cExpected: i  not e  rangM [2, 4]e//t twIf you specify "" as eie oescripoins,f>& _failur _messagl willn// cantainet&e sequence of wordsee  >& _mafcherdag M foEXPEad by eiefmi parg Mter values pr
 ted as a t::Au.  For&exampl ,n//t tw cMATCHER_P2(InClow*dRangM,fXPE, hi, "")&i ... }t tw c...t tw cEXPECT_THAT(3,aInClow*dRangM(4, 6))me//w cEXPECT_THAT(3,aNot(InClow*dRangM(2, 4)))me//t twwould generavef>wo_failur s >&at&nantainet&e Aext:n//t tw cExpected: is clow*d rangM (4, 6)t tw c...t tw cExpected: not (is clow*d rangM (2, 4))n//t twvumes of MafcherdParg MtersLhfc===========================n//t twFor&t&e purpow* s eAum
 T,fyou cannviewn//t tw cMATCHER_Pk(Foo, p1,a..., pk, descripoins_str
 T)&i ... }t tt twasdshor>&andnforn//t tw c  vimavef GMpename p1_Aume,a..., GMpename pk_Aume>t tw cFooMafcherPk<p1_Aume,a..., pk_Aume>t tw cFoo(p1_Aume p1,a..., pk_Aume pk)&i ... }t tt twWhln you write Foo(v1,a..., vk), eie nampiler isfers t&e Aumes of
// eie parg Mters v1,a..., andnvknfor you.  If you aie not happyeeiffn// eie result of eie Aume isference,fyou cannspecify t&e Aumes bykhfcexplicitly instantiat
 T eie   vimave,wasdis Foo<long, bool>(5,n// falsM).  Asdsaid earlilr,eyou doct lgeh in (or neld in)nspecifykhfc'arg_Aume'das >&at's oetermAnad by eie nantext incwhich >& _mafcherkhfci  sw*d.  You cannassign eie result of expressins Foo(p1,a..., pk)
// inea var
able s eAumecFooMafcherPk<p1_Aume,a..., pk_Aume>.  Thisn// can tacsw*ful whln nampos
 T mafchers.n//t twWhile you canninstantiate
a_mafcherd  vimavefwith reference tumes,fmi pass
 T eie parg Mters by poi <.  swually makes your&code moret twreadable.  If, hPEavlr,eyou snellcwach inepass a parg Mter bykhfcreference,etacaware >&at&inet&e failur _messagl generaved by eiefmi mafcherdyou wellcsee eie value of eie referenced object.sutsnot etsn// address.n//t twExplain
 T nafch ResultsLhfc========================n//t twSometimesneie mafcherdoescripoins alone isct lenough ineexplain why
// eie mafch has failed or succeed*d.  For&exampl , whln expect
 T a
// long str
 T, i dcan tacvlry helpful inealsn pr
 t eie oiff tatween
// eie expected str
 T andneie actualense.  Tneachiavl >&at,fyou cant twopoinsally stream addioinsal isformaoins inea special var
able
rtuag Md result_listener, whoseoGMpe isaa poi <.  inecla sLhfcnafchResultListener:n//t tw cMATCHER_P(EqualsLongStr
 T, str, "")&it tw c  ife(arg == str)a   e ieArue;n//t tw c  *result_listener << "eie oifference: "t ttw c                  << DiffStr
 Ts(str, arg);t tw c     e iefalsM;t tw c}t tt twOvlrload
 T nafchersLhfc====================t tt twYou cannovlrload mafchers with oifferentsnumbers of parg Mters:n//t tw cMATCHER_P(Blah, a, descripoins_str
 T1)&i ... }t tw cMATCHER_P2(Blah, a, b, descripoins_str
 T2)&i ... }t tt twCaveatsLhfc=======t tt twWhln oe Ani T a new mafcher,eyou should alsn aectidlimimpl ow#.
 Tn// nafcherI <. fMSV orcus
 T MakePolymorphicnafcher().  These
rtuapproaches requiie more work >&anet&e MATCHER* macros,.sutsalsn
rtugiveeyou more nantrolens t&e Aumes of eie value be
 T mafched and
// eie mafcher parg Mters,wwhich  ay leadsdinetat<.  nampiler errorn//_messagls whln eie  afchlimiscsw*ddwrong.  They alsn aEXPEt twovlrload
 T mafchers baw*ddns parg Mter Aumes (as oppow*ddinejustfmi baw*ddns eie number of parg Mters).n//t twMATCHER*()ncannonly tacsw*dde  auag M, MSV scope.  Thewreasns i 
// eiat&C++no r ct lyetcaEXPE funcoins-local iumes inetacsw*ddinkhfcinstantiate
  vimaves.  Thewup-nam
 T C++0x standard wellcfixet&is.t twOnce t&at's onse, we'llcaectidlimsupport
 T us
 T MATCHER*()ninsiden// a funcoins.n//t twMore IsformaoinsLhfc================n//t twvo lea iemore ab Gtcus
 T ehese macros,.pl asl sea ch forc'MATCHER't twon http://code.google.nam/p/googlemock/wiki/CookBook.

#n
 Ana MATCHER(ag M, descripoins)\
 ecla suag M##Mafcherd{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim()\mcdss uuuuuu{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<i()))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>())m\mcdss}\mcdssag M##Mafcher() {\mcdss}\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##Mafcher)m\mcd};\mcdinlAnasag M##Mafcherdag M() {\mcdss   e ieag M##Mafcher()m\mcd}\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##Mafcher::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P(ag M, p0, descripoins)\
 e  vimavef GMpename p0##_Aume>\mcdcla suag M##MafcherPd{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss uexplicitugmock_Ivim(p0##_Aumeugmock_p0)\mcdss uuuuuu: p0(gmock_p0)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume>(p0)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0))m\mcdss}\mcdssag M##MafcherP(p0##_Aumeugmock_p0)u: p0(gmock_p0)u{\mcdss}\mcdssp0##_Aume p0;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP)m\mcd};\mcd  vimavef GMpename p0##_Aume>\mcdinlAnasag M##MafcherP<p0##_Aume>dag M(p0##_Aume p0) {\mcdss   e ieag M##MafcherP<p0##_Aume>(p0)m\mcd}\mcdA vimavef GMpename p0##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP<p0##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P2(ag M, p0, p1,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume>\mcdcla suag M##MafcherP2d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume>(p0, p1)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1))m\mcdss}\mcdssag M##MafcherP2(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1)u: p0(gmock_p0), \mcdss uuup1(gmock_p1)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP2)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume>\mcdinlAnasag M##MafcherP2<p0##_Aume, p1##_Aume>dag M(p0##_Aume p0, \mcdss up1##_Aumeup1) {\mcdss   e ieag M##MafcherP2<p0##_Aume, p1##_Aume>(p0, p1)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP2<p0##_Aume, \mcdss up1##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P3(ag M, p0, p1,ap2,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume>\mcdcla suag M##MafcherP3d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume>(p0, p1, \mcdss uuuuuu         p2)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2))m\mcdss}\mcdssag M##MafcherP3(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2)u: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP3)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume>\mcdinlAnasag M##MafcherP3<p0##_Aume, p1##_Aume, p2##_Aume>dag M(p0##_Aume p0, \mcdss up1##_Aumeup1, p2##_Aumeup2) {\mcdss   e ieag M##MafcherP3<p0##_Aume, p1##_Aume, p2##_Aume>(p0, p1, p2)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP3<p0##_Aume, p1##_Aume, \mcdss  p2##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P4(ag M, p0, p1,ap2,ap3,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume>\mcdcla suag M##MafcherP4d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2, \mcdss uuuuup3##_Aumeugmock_p3)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),ap3(gmock_p3)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss up3##_Aumeup3;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume, \mcdss uuuuuu         p3##_Aume>(p0, p1, p2,ap3)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2,ap3))m\mcdss}\mcdssag M##MafcherP4(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2,up3##_Aumeugmock_p3)u: p0(gmock_p0), p1(gmock_p1), \mcdss uuup2(gmock_p2),ap3(gmock_p3)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdsup3##_Aumeup3;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP4)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume>\mcdinlAnasag M##MafcherP4<p0##_Aume, p1##_Aume, p2##_Aume, \mcdss up3##_Aume>dag M(p0##_Aume p0, p1##_Aumeup1, p2##_Aumeup2, \mcdss up3##_Aume p3)u{\mcdss   e ieag M##MafcherP4<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume>(p0, \mcdss uuup1, p2,ap3)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP4<p0##_Aume, p1##_Aume, p2##_Aume, \mcdss up3##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P5(ag M, p0, p1,ap2,ap3,ap4,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume>\mcdcla suag M##MafcherP5d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2, \mcdss uuuuup3##_Aumeugmock_p3, p4##_Aumeugmock_p4)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),ap3(gmock_p3), \mcdss uuuuuu    p4(gmock_p4)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss up3##_Aumeup3;\mcdss  p4##_Aumeup4;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss uuuuuu         p4##_Aume>(p0, p1,ap2,ap3,ap4)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2,ap3,ap4))m\mcdss}\mcdssag M##MafcherP5(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2,up3##_Aumeugmock_p3, \mcdss uuup4##_Aumeugmock_p4)u: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),a\mcdss uuup3(gmock_p3), p4(gmock_p4)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdsup3##_Aumeup3;\mcds p4##_Aumeup4;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP5)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume>\mcdinlAnasag M##MafcherP5<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume>dag M(p0##_Aume p0, p1##_Aumeup1, p2##_Aumeup2, p3##_Aumeup3, \mcdss up4##_Aume p4)u{\mcdss   e ieag M##MafcherP5<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss u  p4##_Aume>(p0, p1,ap2,ap3,ap4)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP5<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P6(ag M, p0, p1,ap2,ap3,ap4,ap5,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume>\mcdcla suag M##MafcherP6d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2, \mcdss uuuuup3##_Aumeugmock_p3, p4##_Aumeugmock_p4, p5##_Aumeugmock_p5)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),ap3(gmock_p3), \mcdss uuuuuu    p4(gmock_p4), p5(gmock_p5)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss up3##_Aumeup3;\mcdss  p4##_Aumeup4;\mcdss  p5##_Aumeup5;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss uuuuuu      s  p4##_Aume, p5##_Aume>(p0, p1,ap2,ap3,ap4, p5)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2,ap3,ap4, p5))m\mcdss}\mcdssag M##MafcherP6(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2,up3##_Aumeugmock_p3, p4##_Aumeugmock_p4, \mcdss uuup5##_Aumeugmock_p5)u: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),a\mcdss uuup3(gmock_p3), p4(gmock_p4), p5(gmock_p5)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdsup3##_Aumeup3;\mcds p4##_Aumeup4;\mcds p5##_Aumeup5;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP6)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume>\mcdinlAnasag M##MafcherP6<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume, p5##_Aume>dag M(p0##_Aume p0, p1##_Aumeup1, p2##_Aumeup2, \mcdss up3##_Aume p3, p4##_Aumeup4, p5##_Aumeup5)u{\mcdss   e ieag M##MafcherP6<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss u  p4##_Aume, p5##_Aume>(p0, p1,ap2,ap3,ap4, p5)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP6<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, p4##_Aume, \mcdss  p5##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P7(ag M, p0, p1,ap2,ap3,ap4,ap5,ap6,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume>\mcdcla suag M##MafcherP7d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2, \mcdss uuuuup3##_Aumeugmock_p3, p4##_Aumeugmock_p4, p5##_Aumeugmock_p5, \mcdss uuuuup6##_Aumeugmock_p6)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),ap3(gmock_p3), \mcdss uuuuuu    p4(gmock_p4), p5(gmock_p5),ap6(gmock_p6)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss up3##_Aumeup3;\mcdss  p4##_Aumeup4;\mcdss  p5##_Aumeup5;\mcdss up6##_Aumeup6;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss uuuuuu         p4##_Aume, p5##_Aume, p6##_Aume>(p0, p1,ap2,ap3,ap4, p5, \mcdss uuuuuu         p6)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2,ap3,ap4, p5, p6))m\mcdss}\mcdssag M##MafcherP7(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2,up3##_Aumeugmock_p3, p4##_Aumeugmock_p4, \mcdss uuup5##_Aumeugmock_p5,up6##_Aumeugmock_p6)u: p0(gmock_p0), p1(gmock_p1), \mcdss uuup2(gmock_p2),ap3(gmock_p3), p4(gmock_p4), p5(gmock_p5), \mcdss uuup6(gmock_p6)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdsup3##_Aumeup3;\mcds p4##_Aumeup4;\mcds p5##_Aumeup5;\mcdsup6##_Aumeup6;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP7)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume>\mcdinlAnasag M##MafcherP7<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume, p5##_Aume, p6##_Aume>dag M(p0##_Aume p0, p1##_Aumeup1, \mcdss  p2##_Aumeup2, p3##_Aumeup3, p4##_Aumeup4, p5##_Aumeup5, \mcdss  p6##_Aumeup6)u{\mcdss   e ieag M##MafcherP7<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss u  p4##_Aume, p5##_Aume, p6##_Aume>(p0, p1,ap2,ap3,ap4, p5, p6)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP7<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, p4##_Aume, \mcdss  p5##_Aume, p6##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P8(ag M, p0, p1,ap2,ap3,ap4,ap5,ap6,ap7,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume>\mcdcla suag M##MafcherP8d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2, \mcdss uuuuup3##_Aumeugmock_p3, p4##_Aumeugmock_p4, p5##_Aumeugmock_p5, \mcdss uuuuup6##_Aumeugmock_p6, p7##_Aumeugmock_p7)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),ap3(gmock_p3), \mcdss uuuuuu    p4(gmock_p4), p5(gmock_p5),ap6(gmock_p6), p7(gmock_p7)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss up3##_Aumeup3;\mcdss  p4##_Aumeup4;\mcdss  p5##_Aumeup5;\mcdss up6##_Aumeup6;\mcdss  p7##_Aumeup7;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss uuuuuu         p4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume>(p0, p1,ap2,a\mcdss uuuuuu         p3,ap4,ap5,ap6,ap7)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2,ap3,ap4, p5, p6,ap7))m\mcdss}\mcdssag M##MafcherP8(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2,up3##_Aumeugmock_p3, p4##_Aumeugmock_p4, \mcdss uuup5##_Aumeugmock_p5,up6##_Aumeugmock_p6, \mcdss uuup7##_Aumeugmock_p7)u: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),a\mcdss uuup3(gmock_p3), p4(gmock_p4), p5(gmock_p5),ap6(gmock_p6), \mcdss uuup7(gmock_p7)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdsup3##_Aumeup3;\mcds p4##_Aumeup4;\mcds p5##_Aumeup5;\mcdsup6##_Aumeup6;\mcds p7##_Aumeup7;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP8)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume>\mcdinlAnasag M##MafcherP8<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume>dag M(p0##_Aume p0, \mcdss up1##_Aumeup1, p2##_Aumeup2, p3##_Aumeup3, p4##_Aumeup4, p5##_Aumeup5, \mcdss  p6##_Aumeup6, p7##_Aumeup7)u{\mcdss   e ieag M##MafcherP8<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss u  p4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume>(p0, p1,ap2,ap3,ap4, p5, \mcdss uuup6,ap7)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP8<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, p4##_Aume, \mcdss  p5##_Aume, p6##_Aume, \mcdss  p7##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P9(ag M, p0, p1,ap2,ap3,ap4,ap5,ap6,ap7,ap8,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume, GMpename p8##_Aume>\mcdcla suag M##MafcherP9d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2, \mcdss uuuuup3##_Aumeugmock_p3, p4##_Aumeugmock_p4, p5##_Aumeugmock_p5, \mcdss uuuuup6##_Aumeugmock_p6, p7##_Aumeugmock_p7, p8##_Aumeugmock_p8)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),ap3(gmock_p3), \mcdss uuuuuu    p4(gmock_p4), p5(gmock_p5),ap6(gmock_p6), p7(gmock_p7), \mcdss uuuuuu    p8(gmock_p8)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss up3##_Aumeup3;\mcdss  p4##_Aumeup4;\mcdss  p5##_Aumeup5;\mcdss up6##_Aumeup6;\mcdss  p7##_Aumeup7;\mcdss  p8##_Aumeup8;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss uuuuuu         p4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume, \mcdss uuuuuu         p8##_Aume>(p0, p1, p2,ap3,ap4, p5, p6,ap7, p8)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2,ap3,ap4, p5, p6,ap7, p8))m\mcdss}\mcdssag M##MafcherP9(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2,up3##_Aumeugmock_p3, p4##_Aumeugmock_p4, \mcdss uuup5##_Aumeugmock_p5,up6##_Aumeugmock_p6, p7##_Aumeugmock_p7, \mcdss uuup8##_Aumeugmock_p8)u: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),a\mcdss uuup3(gmock_p3), p4(gmock_p4), p5(gmock_p5),ap6(gmock_p6), p7(gmock_p7), \mcdss uuup8(gmock_p8)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdsup3##_Aumeup3;\mcds p4##_Aumeup4;\mcds p5##_Aumeup5;\mcdsup6##_Aumeup6;\mcds p7##_Aumeup7;\mcds p8##_Aumeup8;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP9)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume, GMpename p8##_Aume>\mcdinlAnasag M##MafcherP9<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume, \mcdss up8##_Aume>dag M(p0##_Aume p0, p1##_Aumeup1, p2##_Aumeup2, p3##_Aumeup3, \mcdss up4##_Aume p4, p5##_Aumeup5, p6##_Aumeup6, p7##_Aumeup7, \mcdss up8##_Aume p8)u{\mcdss   e ieag M##MafcherP9<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss u up4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume, p8##_Aume>(p0, p1, p2,a\mcdss uuup3,ap4, p5, p6,ap7, p8)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume, GMpename p8##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP9<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, p4##_Aume, \mcdss  p5##_Aume, p6##_Aume, p7##_Aume, \mcdss up8##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#n
 Ana MATCHER_P10(ag M, p0, p1,ap2,ap3,ap4,ap5,ap6,ap7,ap8,ap9,adescripoins)\
 e  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume, GMpename p8##_Aume,a\mcdss uGMpename p9##_Aume>\mcdcla suag M##MafcherP10d{\
 e public:\mcdssA vimavef GMpename arg_Aume>\mcdsscla sugmock_Ivim : publica" GesneplmanafcherI <. fMSV<arg_Aume>d{\
 e e public:\mcdss ugmock_Ivim(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, p2##_Aumeugmock_p2, \mcdss uuuuup3##_Aumeugmock_p3, p4##_Aumeugmock_p4, p5##_Aumeugmock_p5, \mcdss uuuuup6##_Aumeugmock_p6, p7##_Aumeugmock_p7, p8##_Aumeugmock_p8, \mcdss uuuuup9##_Aumeugmock_p9)\mcdss uuuuuu: p0(gmock_p0), p1(gmock_p1), p2(gmock_p2),ap3(gmock_p3), \mcdss uuuuuu    p4(gmock_p4), p5(gmock_p5),ap6(gmock_p6), p7(gmock_p7), \mcdss uuuuuu    p8(gmock_p8),ap9(gmock_p9)u{}\mcdss uvirtualebool nafchAndExplain(\mcdss uuuuuarg_Aumeuarg,a" GesneplmanafchResultListener* result_listener)aaectp;\mcdss uvirtualevoid DescribeTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(falsM);\mcdss u}\mcdss uvirtualevoid DescribeNegaoinsTo(::SIVE_ostream*ugmock_os)aaectpd{\
 e e c  *gmock_os << FormaoDescripoins(Arue);\mcdss u}\mcdss  p0##_Aume p0;\mcdss  p1##_Aumeup1;\mcdss  p2##_Aumeup2;\mcdss up3##_Aumeup3;\mcdss  p4##_Aumeup4;\mcdss  p5##_Aumeup5;\mcdss up6##_Aumeup6;\mcdss  p7##_Aumeup7;\mcdss  p8##_Aumeup8;\mcdss up9##_Aumeup9;\mcdss pr
vave:\mcdss u" Gesneplmai <.  Tomastr
 T FormaoDescripoins(bool negaoins)aaectpd{\
 e e c  aectpd" Gesneplmai <.  Tomastr
 T gmock_oescripoins = (descripoins);\
 e e c  ife(!gmock_oescripoins.empty())\mcdss uuuuu   e iegmock_oescripoins;\
 e e c     e ie" Gesneplmai <.  TomaFormaonafcherDescripoins(\mcdss uuuuuu negaoins, #ag M, \mcdss uuuuuu " Gesneplmai <.  TomaUniversalTersePr
 tT::AuFieldsToStr
 Ts(\mcdss uuuuuu uuu " SIVE_tr1::t::Au<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss uuuuuu        up4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume, p8##_Aume, \mcdss uuuuuu        up9##_Aume>(p0, p1, p2,ap3,ap4, p5, p6,ap7, p8,ap9)))m\mcdss u}\mcdss uGTEST_DISALLOW_ASSIGN_(gmock_Ivim)m\mcdss};\mcdssA vimavef GMpename arg_Aume>\mcdssoperavorc" Gesneplmanafcher<arg_Aume>()aaectpd{\
 e e c   e ie" Gesneplmanafcher<arg_Aume>(\mcdss uuuuunew gmock_Ivim<arg_Aume>(p0, p1, p2,ap3,ap4, p5, p6,ap7, p8,ap9))m\mcdss}\mcdssag M##MafcherP10(p0##_Aumeugmock_p0, p1##_Aumeugmock_p1, \mcdss uuup2##_Aumeugmock_p2,up3##_Aumeugmock_p3, p4##_Aumeugmock_p4, \mcdss uuup5##_Aumeugmock_p5,up6##_Aumeugmock_p6, p7##_Aumeugmock_p7, \mcdss uuup8##_Aumeugmock_p8,up9##_Aumeugmock_p9)u: p0(gmock_p0), p1(gmock_p1), \mcdss uuup2(gmock_p2),ap3(gmock_p3), p4(gmock_p4), p5(gmock_p5), p6(gmock_p6), \mcdss uuup7(gmock_p7), p8(gmock_p8),ap9(gmock_p9)u{\mcdss}\mcdssp0##_Aume p0;\mcds p1##_Aumeup1;\mcds p2##_Aumeup2;\mcdsup3##_Aumeup3;\mcds p4##_Aumeup4;\mcds p5##_Aumeup5;\mcdsup6##_Aumeup6;\mcds p7##_Aumeup7;\mcds p8##_Aumeup8;\mcdsup9##_Aumeup9;\mcdspr
vave:\mcdssGTEST_DISALLOW_ASSIGN_(ag M##MafcherP10)m\mcd};\mcd  vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume, GMpename p8##_Aume,a\mcdss uGMpename p9##_Aume>\mcdinlAnasag M##MafcherP10<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume, p8##_Aume,a\mcdss up9##_Aume>dag M(p0##_Aume p0, p1##_Aumeup1, p2##_Aumeup2, p3##_Aumeup3, \mcdss up4##_Aume p4, p5##_Aumeup5, p6##_Aumeup6, p7##_Aumeup7, p8##_Aumeup8,a\mcdss up9##_Aume p9)u{\mcdss   e ieag M##MafcherP10<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss u up4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume, p8##_Aume,ap9##_Aume>(p0, \mcdss u up1, p2,ap3,ap4, p5, p6,ap7, p8,ap9)m\mcd}\mcdA vimavef GMpename p0##_Aume, GMpename p1##_Aume, GMpename p2##_Aume,a\mcdss uGMpename p3##_Aume, GMpename p4##_Aume, GMpename p5##_Aume,a\mcdss uGMpename p6##_Aume, GMpename p7##_Aume, GMpename p8##_Aume,a\mcdss uGMpename p9##_Aume>\mcdA vimavef GMpename arg_Aume>\mcdbool ng M##MafcherP10<p0##_Aume, p1##_Aume, p2##_Aume, p3##_Aume, \mcdss up4##_Aume, p5##_Aume, p6##_Aume, p7##_Aume, p8##_Aume,a\mcdss up9##_Aume>::gmock_Ivim<arg_Aume>manafchAndExplain(\mcdss uarg_Aumeuarg,a\mcdss u" GesneplmanafchResultListener* result_listenersGTEST_ATTRIBUTE_UNUSED_)\mcdss uuuuuaectp

#endife // GMOCK_INCLUDE_GMOCK_GMOCK_GENERATED_MATCHERS_H_
// Copyright 2007, Google Inc.
// All rights reserved.
//
// Redistr
buoins and usedin source and binary forms, with orcwithout
// modificaoins, are permittedsprovidedsthatsthe follow
 T aecdioinss are
// met:
//
//     * Redistr
buoinss of source code mutpd   ainsthe above copyright
// notice, Ghis list of aecdioinss andsthe follow
 T disclaimer.
//     * Redistr
buoinss insbinary form mutpd  produce the above
// copyright notice, Ghis list of aecdioinss andsthe follow
 T disclaimer
// insthe documentaoins and/orcother maoerialssprovidedswith the
// distr
buoins.
//     * Neither the name of Google Inc. nor the names of its
// contr
buoors may be usedsto endorse orcpromovefproducts derived from
// Ghis software without specificspr
orcwritten permissins.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: wan@google.com (Zhanyo T Wan)

// Google Mock - a framework forcwrit
 T C++ mockscla ses.
//
// This file ivimements some acoinss thatsdepend oiegmock-generaoed-acoinss.h.

#ifndef GMOCK_INCLUDE_GMOCK_GMOCK_MORE_ACTIONS_H_
#n
 Ana GMOCK_INCLUDE_GMOCK_GMOCK_MORE_ACTIONS_H_

#include <algorithm>


namespace tesnepl {
namespace i <.  To {

// Ivimements the Invoke(f) acoins.  ThedA vimavefargument
// FuncoinsIvim is the ivimementaoins Aumeuof f, which can be either a
// funcoins poi <.  orca funcoor.  Invoke(f) can be usedsas an
// Acoins<F>sas lo T as f's Aumeuis compaoible with F (i.e. f can be
// a signedsto a tr1::funcoins<F>).
A vimavef GMpename FuncoinsIvim>
cla suInvokeAcoins {
 public:
e // Thedc'vorcmakes a copyuof funcoins_ivim (either a funcoins
e // poi <.  orca funcoor).
  explicituInvokeAcoins(FuncoinsIvim funcoins_ivim)mcdss u" funcoins_ivim_(funcoins_ivim) {}
mcdA vimavef GMpename Result, GMpename ArgumentT::Au>mcdResult Perform(aectpdArgumentT::Au&fargs) {
 dss   e ieInvokeHelper<Result, ArgumentT::Au>::Invoke(funcoins_ivim_,fargs);mcd}
mcpr
vave:mcdFuncoinsIvim funcoins_ivim_;
mcdGTEST_DISALLOW_ASSIGN_(InvokeAcoins);m};

// Ivimements the Invoke(object_ptr, &Cla smanethod) acoins.
A vimavef cla suCla s, GMpename nethodPtr>
cla suInvokenethodAcoins {
 public:
e InvokenethodAcoins(Cla s* obj_ptr, nethodPtr method_ptr)mcdss u" obj_ptr_(obj_ptr), method_ptr_(method_ptr) {}
mcdA vimavef GMpename Result, GMpename ArgumentT::Au>mcdResult Perform(aectpdArgumentT::Au&fargs) aectpd{
 dss   e ieInvokeHelper<Result, ArgumentT::Au>::Invokenethod(mcdss uuuobj_ptr_, method_ptr_,fargs);mcd}
mcpr
vave:mcdCla s* aectpdobj_ptr_;mcdaectpdnethodPtr method_ptr_;
mcdGTEST_DISALLOW_ASSIGN_(InvokenethodAcoins);m};

}e // namespace i <.  To

// Var
ous overloads forcInvoke().

// Creaves an acoins thatsinvokes 'funcoins_ivim'swith the mock
// funcoins'sfarguments.
A vimavef GMpename FuncoinsIvim>
PolymorphicAcoins<i <.  TomaInvokeAcoins<FuncoinsIvim> >cInvoke(mcdssFuncoinsIvim funcoins_ivim)d{
 d   e ieMakePolymorphicAcoins(mcdss ui <.  TomaInvokeAcoins<FuncoinsIvim>(funcoins_ivim));m}

// Creaves an acoins thatsinvokes the given method on the given object
// with the mock funcoins'sfarguments.
A vimavef cla suCla s, GMpename nethodPtr>
PolymorphicAcoins<i <.  TomaInvokenethodAcoins<Cla s, nethodPtr> >cInvoke(mcdssCla s* obj_ptr, nethodPtr method_ptr)d{
 d   e ieMakePolymorphicAcoins(mcdss ui <.  TomaInvokenethodAcoins<Cla s, nethodPtr>(obj_ptr, method_ptr));m}

// WithoutArgs(inner_acoins) can be usedsinsa mock funcoins with a
// non-emptyfargument list to perform inner_acoins, which takes no
// argument.  Incother words, ituadapts an acoins accepnepl no
// argument to one thatsaccepns (andsignores) arguments.
A vimavef GMpename InnerAcoins>
inlAnasi <.  TomaWithArgsAcoins<InnerAcoins>
WithoutArgs(aectpdInnerAcoins& acoins) {
 d   e iei <.  TomaWithArgsAcoins<InnerAcoins>(acoins);m}

// WithArg<k>(an_acoins) creaves an acoins thatspa ses the k-th
// (0-based) argumentuof the mock funcoinssto an_acoins andsperforms
// it.  Ituadapts an acoins accepnepl one argument to one thatsaccepns
// multi:Au arguments.  Fordaecvenience, wu alsosprovide
// WithArgs<k>(an_acoins) (n
 Anad below)sas a synonym.
A vimavef i < k, GMpename InnerAcoins>
inlAnasi <.  TomaWithArgsAcoins<InnerAcoins, k>
WithArg(aectpdInnerAcoins& acoins) {
 d   e iei <.  TomaWithArgsAcoins<InnerAcoins, k>(acoins);m}

// ThedACTION*()cmacros trigger warn
 T C4100 (unreferenced formTo
// parameter)ainsMSVC with -W4.  Unfortunavely they cannot be fixedsin
// Ghecmacro n
 Anioins, as the warn
 Ts are generaoed when Ghecmacro
// is expandedsandsmacro expansins cannot contains#pragma.  Therefore
// wu suppress them here.
#ifdef _MSC_VER
# pragma warn
 T(push)
# pragma warn
 T(disable:4100)
#endif

// AcoinsdRe e iArg<k>()d   e is the k-th argumentuof the mock funcoins.
ACTION_TEMPLATE(Re e iArg,mcdss uuuuuu     HAS_1_TEMPLATE_PARAMS(int, k),mcdss uuuuuu     AND_0_VALUE_PARAMS()) {
 d   e ieSIVE_tr1::get<k>(args);m}

// AcoinsdSaveArg<k>(poi <. ) saves the k-th (0-based) argumentuof the
// mock funcoinssto *poi <. .
ACTION_TEMPLATE(SaveArg,mcdss uuuuuu     HAS_1_TEMPLATE_PARAMS(int, k),mcdss uuuuuu     AND_1_VALUE_PARAMS(poi <. )) {
 d*poi <.  = " SIVE_tr1::get<k>(args);m}

// AcoinsdSaveArgPoi <.e<k>(poi <. ) saves the value poi <.dsto
// by the k-th (0-based) argumentuof the mock funcoinssto *poi <. .
ACTION_TEMPLATE(SaveArgPoi <.e,mcdss uuuuuu     HAS_1_TEMPLATE_PARAMS(int, k),mcdss uuuuuu     AND_1_VALUE_PARAMS(poi <. )) {
 d*poi <.  = *" SIVE_tr1::get<k>(args);m}

// AcoinsdSetArgReferee<k>(value) a signs 'value'sto the variable
// referenced by the k-th (0-based) argumentuof the mock funcoins.
ACTION_TEMPLATE(SetArgReferee,mcdss uuuuuu     HAS_1_TEMPLATE_PARAMS(int, k),mcdss uuuuuu     AND_1_VALUE_PARAMS(value)) {
 dGMpedef GMpename " SIVE_tr1::t::Au_emement<k,fargs_Aume>maAumeuargk_Aume;
e // Ensures thatsargumentu#k is a reference.  If you get a compiler
e // errorcon Ghecnext line, you are us
 T SetArgReferee<k>(value) is
e // a mock funcoins whose k-th (0-based) argumentuis not a reference.mcdGTEST_COMPILE_ASSERT_(i <.  Tomais_reference<argk_Aume>mavalue,mcdss uuuuuu             SetArgReferee_mutp_be_used_with_a_reference_argument);mcd" SIVE_tr1::get<k>(args) = value;m}

// AcoinsdSetArrayArgument<k>(first, la t) aepies the emements in
// source range [first, la t) to the array poi <.dsto by the k-th
// (0-based) argument, which can be either a poi <.  orcan
// iteravor. Thedacoins does not take ownershipuof the emements in the
// source range.
ACTION_TEMPLATE(SetArrayArgument,mcdss uuuuuu     HAS_1_TEMPLATE_PARAMS(int, k),mcdss uuuuuu     AND_2_VALUE_PARAMS(first, la t)) {
 d// Microsoft compilersdeprecaves " SIVE_copy, so wu want to suppress warn
 T
 d// 4996 (Funcoins call with parameters thatsmay be unsafe) there.
#ifdef _MSC_VER
# pragma warn
 T(push)uuuuu     // Saves the currentuwarn
 T stave.
# pragma warn
 T(disable:4996)e // T viorarily disables warn
 T 4996.
#endif
  " SIVE_copy(first, la t,d" SIVE_tr1::get<k>(args));m#ifdef _MSC_VER
# pragma warn
 T(pop)uuuuu      // Restores the warn
 T stave.
#endif
}

// AcoinsdDemeteArg<k>()ddemetes the k-th (0-based) argumentuof the mock
// funcoins.
ACTION_TEMPLATE(DemeteArg,mcdss uuuuuu     HAS_1_TEMPLATE_PARAMS(int, k),mcdss uuuuuu     AND_0_VALUE_PARAMS()) {
 ddemete " SIVE_tr1::get<k>(args);m}

// This acoins    e is the value poi <.dsto by 'poi <. '.
ACTION_P(Re e iPoi <.e, poi <. ) {d   e ie*poi <. ; }

// AcoinsdThrow(excepnens) can be usedsinsa mock funcoins of any GMpe
// Go throw the given excepnens.  Any copyable value can be thrown.
#ifdGTEST_HAS_EXCEPTIONS

// Suppresses the 'unreachable code' warn
 T thatsVC generaoes in opt modes.
# ifdef _MSC_VER
#  pragma warn
 T(push)uuuuu     // Saves the currentuwarn
 T stave.
#  pragma warn
 T(disable:4702)e // T viorarily disables warn
 T 4702.
# endif
ACTION_P(Throw, excepnens) { throw excepnens; }
# ifdef _MSC_VER
#  pragma warn
 T(pop)uuuuu      // Restores the warn
 T stave.
# endif

#endife // GTEST_HAS_EXCEPTIONS

#ifdef _MSC_VER
# pragma warn
 T(pop)
#endif

}e // namespace tesnepl

#endife // GMOCK_INCLUDE_GMOCK_GMOCK_MORE_ACTIONS_H_
// Copyright 2013, Google Inc.
// All rights reserved.
//
// Redistr
buoins and usedin source and binary forms, with orcwithout
// modificaoins, are permittedsprovidedsthatsthe follow
 T aecdioinss are
// met:
//
//     * Redistr
buoinss of source code mutpd   ainsthe above copyright
// notice, Ghis list of aecdioinss andsthe follow
 T disclaimer.
//     * Redistr
buoinss insbinary form mutpd  produce the above
// copyright notice, Ghis list of aecdioinss andsthe follow
 T disclaimer
// insthe documentaoins and/orcother maoerialssprovidedswith the
// distr
buoins.
//     * Neither the name of Google Inc. nor the names of its
// contr
buoors may be usedsto endorse orcpromovefproducts derived from
// Ghis software without specificspr
orcwritten permissins.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Author: marcus.boerger@google.com (Marcus Boerger)

// Google Mock - a framework forcwrit
 T C++ mockscla ses.
//
// This file ivimements some mafchers thatsdepend oiegmock-generaoed-mafchers.h.
//
// Novefthatstesns are ivimementedsinsgmock-mafchers_tesn.cc rather than
// gmock-more-mafchers-tesn.cc.

#ifndef GMOCK_GMOCK_MORE_MATCHERS_H_
#n
 Ana GMOCK_GMOCK_MORE_MATCHERS_H_


namespace tesnepl {

// D
 Anas a mafcher thatsmafches an emptyfcontainer. Thedcontainer mutp
// support both size()dandsempty(), which all STL-likedcontainerssprovide.
MATCHER(IsEmpty, negaoins ? "isn'tsempty" : "issempty") {
 dife(arg.empty())d{
 dss   e ieArue;mcd}
  *result_listeners<< "whose sizeuis "s<< arg.size();
 d   e iefalsM;m}

}e // namespace tesnepl

#endife // GMOCK_GMOCK_MORE_MATCHERS_H_

namespace tesnepl {

// D
clares Google Mock flags thatswu want a usersto usedprogrammafically.
GMOCK_DECLARE_bool_(cafch_leaked_mocks);mGMOCK_DECLARE_str
 T_(verbosM);

// Inioializes Google Mock.  This mutpdbe callad before runn
 T the
// Gesns.  Incparficular, ituparses the commandslAnasfor the flags
// GhatsGoogle Mock recognizes.  Whenever a Google Mock flaguis seen,
// ituis removed from argv,dands*argcuis decremented.
//
// No value is re e ied.  Instead, the Google Mock flaguvariables are
// updated.
//
// Since Google Tesnuis needed for Google Mock to work, Ghis funcoins
// alsosinioializes Google Tesnuandsparses its flags,difeGhatshasn't
// been done.
GTEST_API_evoid InioGoogleMock(int* argc, char** argv);

// This overloaded versins can be usedsinsWindowsdprograms compiledsin
// UNICODE mode.
GTEST_API_evoid InioGoogleMock(int* argc, wchar_t** argv);

}e // namespace t